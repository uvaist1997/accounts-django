import React, { useState } from "react";
import styled from "styled-components/macro";

import { IconButton, Menu, MenuItem, TableSortLabel } from "@mui/material";

import MoreVertIcon from "@mui/icons-material/MoreVert";
import Pagination from "@mui/material/Pagination";
function BussinessTypeTable() {
  const options = ["Edit", "Delete"];
  const [anchorEl, setAnchorEl] = useState(null);
  const open = Boolean(anchorEl);
  const [currentIndex, setCurrentIndex] = useState();
  const handleClick = (index) => (event) => {
    setAnchorEl(event.currentTarget);
    setCurrentIndex(index);
  };
  const handleClose = () => {
    setAnchorEl(null);
  };
  const ITEM_HEIGHT = 48;

  const [bussinessList, setBussinessList] = useState({
    data: [
      { id: "1", bussinesstype: "Abcd", description: "Not me but you" },
      { id: "2", bussinesstype: "Efgh", description: "Aaaaaaaaaaaaaaa" },
      { id: "3", bussinesstype: "Ijkl", description: "Eeeeeeeeeeee" },
      { id: "4", bussinesstype: "Abcd", description: "Not me but you" },
      { id: "5", bussinesstype: "Efgh", description: "Aaaaaaaaaaaaaaa" },
      { id: "6", bussinesstype: "Ijkl", description: "Eeeeeeeeeeee" },
      { id: "7", bussinesstype: "Abcd", description: "Not me but you" },
      { id: "8", bussinesstype: "Efgh", description: "Aaaaaaaaaaaaaaa" },
      { id: "9", bussinesstype: "Ijkl", description: "Eeeeeeeeeeee" },
      { id: "10", bussinesstype: "Abcd", description: "Not me but you" },
      { id: "11", bussinesstype: "Efgh", description: "Aaaaaaaaaaaaaaa" },
      { id: "12", bussinesstype: "Ijkl", description: "Eeeeeeeeeeee" },
      { id: "13", bussinesstype: "Abcd", description: "Not me but you" },
      { id: "14", bussinesstype: "Efgh", description: "Aaaaaaaaaaaaaaa" },
      { id: "15", bussinesstype: "Ijkl", description: "Eeeeeeeeeeee" },
      { id: "16", bussinesstype: "Abcd", description: "Not me but you" },
      { id: "17", bussinesstype: "Efgh", description: "Aaaaaaaaaaaaaaa" },
      { id: "18", bussinesstype: "Ijkl", description: "Eeeeeeeeeeee" },
      { id: "19", bussinesstype: "Abcd", description: "Not me but you" },
      { id: "20", bussinesstype: "Efgh", description: "Aaaaaaaaaaaaaaa" },
      { id: "21", bussinesstype: "Ijkl", description: "Eeeeeeeeeeee" },
      { id: "22", bussinesstype: "Abcd", description: "Not me but you" },
      { id: "23", bussinesstype: "Efgh", description: "Aaaaaaaaaaaaaaa" },
      { id: "24", bussinesstype: "Ijkl", description: "Eeeeeeeeeeee" },
      { id: "25", bussinesstype: "Abcd", description: "Not me but you" },
      { id: "26", bussinesstype: "Efgh", description: "Aaaaaaaaaaaaaaa" },
      { id: "27", bussinesstype: "Ijkl", description: "Eeeeeeeeeeee" },
      { id: "28", bussinesstype: "Abcd", description: "Not me but you" },
      { id: "29", bussinesstype: "Efgh", description: "Aaaaaaaaaaaaaaa" },
      { id: "30", bussinesstype: "Ijkl", description: "Eeeeeeeeeeee" },
    ],
  });

  //pagination=======================================

  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage, setItemsPerPage] = useState(22);

  const IndexofLastItem = currentPage * itemsPerPage;
  const indexOfFirstDish = IndexofLastItem - itemsPerPage;
  let PaginatedData = bussinessList.data.slice(
    indexOfFirstDish,
    IndexofLastItem
  );

  const ChangePage = (event, value) => {
    setCurrentPage(value);
  };

  const NumOfpages = Math.ceil(bussinessList.data.length / itemsPerPage);

  return (
    <TableContainer>
      <Table>
        <THead>
          <TableHeadRow>
            <TH> ID </TH>
            <TH> Bussiness Type </TH>
            <TH> Description </TH>

            <TH></TH>
          </TableHeadRow>
        </THead>
        <TBody>
          {PaginatedData.map((i, index) => (
            <TableBodyRow>
              <TD> {i.id} </TD>
              <TD> {i.bussinesstype} </TD>
              <TD> {i.description} </TD>

              <TD style={{ textAlign: "right" }}>
                <RightSide>
                  <IconButton
                    aria-label="more"
                    // id={index}
                    aria-controls={open ? "long-menu" : undefined}
                    aria-expanded={open ? "true" : undefined}
                    aria-haspopup="true"
                    onClick={handleClick(index)}
                  >
                    <MoreVertIcon />
                  </IconButton>
                  {currentIndex === index ? (
                    <Menus
                      disableScrollLock={true}
                      // id="long-menu"
                      MenuListProps={
                        {
                          // "aria-labelledby": ` ${index}`,
                        }
                      }
                      anchorEl={anchorEl}
                      open={open}
                      onClose={handleClose}
                      PaperProps={{
                        style: {
                          maxHeight: ITEM_HEIGHT * 4.5,
                          width: "20ch",
                        },
                      }}
                    >
                      {options.map((option) => (
                        <MenuItem
                          key={option}
                          selected={option === "Pyxis"}
                          onClick={handleClose}
                        >
                          {option}
                        </MenuItem>
                      ))}
                    </Menus>
                  ) : null}
                </RightSide>
              </TD>
            </TableBodyRow>
          ))}
        </TBody>
      </Table>
      <PaginationContainer>
        <Pagination count={NumOfpages} onChange={ChangePage} />
      </PaginationContainer>
    </TableContainer>
  );
}

export default BussinessTypeTable;

const PaginationContainer = styled.div`
  width: 100%;
  display: flex;
  margin-top: 10px;
  justify-content: center;
`;
const Menus = styled(Menu)`
  .css-1poimk-MuiPaper-root-MuiMenu-paper-MuiPaper-root-MuiPopover-paper {
    ::-webkit-scrollbar {
      display: none !important;
    }
  }
`;
const RightSide = styled.div`
  height: 100%;
  svg {
    font-size: 1.1rem !important ;
    color: black !important;
  }
  .css-78trlr-MuiButtonBase-root-MuiIconButton-root {
    padding: unset !important;
  }
  .MuiPaper-root {
    box-shadow: none !important;
  }
`;

const TableContainer = styled.div`
  margin-top: 15px;
`;
const TD = styled.td`
  padding: 5px 15px !important;
  font-size: 12px;
  text-align: left;

  border-bottom: 1px solid #ababab;
  vertical-align: middle;

  &.cursor {
    cursor: pointer;
  }
`;
const TableBodyRow = styled.tr`
  :hover {
    background-color: rgba(0, 0, 0, 0.04);
  }
`;
const Table = styled.table`
  border-radius: 15px;
  width: 100%;
  background: #fff;
  border-spacing: unset;
`;

const THead = styled.thead`
  box-shadow: 0 0 0 1px #c6c6c6;
  border-radius: 3px;
  background-color: black;
  color: white;
`;
const TableHeadRow = styled.tr``;
const TBody = styled.tbody``;
const TH = styled.th`
  padding: 5px 15px;
  font-weight: normal;
  text-align: left;
  font-size: 14px;
`;
