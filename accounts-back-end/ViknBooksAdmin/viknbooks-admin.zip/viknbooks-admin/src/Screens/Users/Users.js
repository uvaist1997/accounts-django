import React from "react";
import CreateButton from "../../Components/CreateButton";
import { useState } from "react";
import styled from "styled-components/macro";

import AddUser from "./AddUser";
import UsersList from "./UsersList";

function Users() {
  const [addPopup, setAddPopup] = useState(false);
  return (
    <Container>
      <Heading>
        <LeftContainer>
          <UsersTxt>Users</UsersTxt>
        </LeftContainer>

        <CreateButtonContainer onClick={(e) => setAddPopup(!addPopup)}>
          <CreateButton label={"Add New"} />
        </CreateButtonContainer>
      </Heading>
      <div>
        <UsersList />
      </div>

      <div>
        <AddUser addPopup={addPopup} setAddPopup={setAddPopup} />
      </div>
    </Container>
  );
}

export default Users;
const Container = styled.div``;
const Heading = styled.div`
  width: 100%;
  display: flex;
  justify-content: space-between;
`;
const LeftContainer = styled.div`
  display: flex;
  gap: 18px;
  align-items: center;
`;
const UsersTxt = styled.h2`
  font-size: 27px;
  letter-spacing: 1px; ;
`;
const CreateButtonContainer = styled.div`
  position: relative;
`;
