import React, { useState } from "react";
import styled from "styled-components/macro";

import { IconButton, Menu, MenuItem, TableSortLabel } from "@mui/material";

import MoreVertIcon from "@mui/icons-material/MoreVert";
import Pagination from "@mui/material/Pagination";
function UsersList({}) {
  const options = ["Edit", "Delete"];
  const [anchorEl, setAnchorEl] = useState(null);
  const open = Boolean(anchorEl);
  const [currentIndex, setCurrentIndex] = useState();
  const handleClick = (index) => (event) => {
    setAnchorEl(event.currentTarget);
    setCurrentIndex(index);
  };
  const handleClose = () => {
    setAnchorEl(null);
  };
  const ITEM_HEIGHT = 48;

  const [userlist, setUserList] = useState({
    data: [
      {
        slno: "1",
        name: "Uvais",
        usertype: "admin",
        emailaddress: "uvais@gmail.com",
        status: "Invitation send",
      },
      {
        slno: "2",
        name: "Jasmal",
        usertype: "admin",
        emailaddress: "jasmal@gmail.com",
        status: "Invitation send",
      },
      {
        slno: "3",
        name: "Abhi",
        usertype: "admin",
        emailaddress: "uvais@gmail.com",
        status: "Invitation send",
      },
      {
        slno: "4",
        name: "Abhi",
        usertype: "admin",
        emailaddress: "uvais@gmail.com",
        status: "Invitation send",
      },
      {
        slno: "5",
        name: "Abhi",
        usertype: "admin",
        emailaddress: "uvais@gmail.com",
        status: "Invitation send",
      },
      {
        slno: "6",
        name: "Abhi",
        usertype: "admin",
        emailaddress: "uvais@gmail.com",
        status: "Invitation send",
      },
      {
        slno: "7",
        name: "Abhi",
        usertype: "admin",
        emailaddress: "uvais@gmail.com",
        status: "Invitation send",
      },
      {
        slno: "8",
        name: "Abhi",
        usertype: "admin",
        emailaddress: "uvais@gmail.com",
        status: "Invitation send",
      },
      {
        slno: "9",
        name: "Abhi",
        usertype: "admin",
        emailaddress: "uvais@gmail.com",
        status: "Invitation send",
      },
      {
        slno: "10",
        name: "Abhi",
        usertype: "admin",
        emailaddress: "uvais@gmail.com",
        status: "Invitation send",
      },
      {
        slno: "11",
        name: "Abhi",
        usertype: "admin",
        emailaddress: "uvais@gmail.com",
        status: "Invitation send",
      },
      {
        slno: "12",
        name: "Abhi",
        usertype: "admin",
        emailaddress: "uvais@gmail.com",
        status: "Invitation send",
      },
      {
        slno: "13",
        name: "Abhi",
        usertype: "admin",
        emailaddress: "uvais@gmail.com",
        status: "Invitation send",
      },
      {
        slno: "14",
        name: "Abhi",
        usertype: "admin",
        emailaddress: "uvais@gmail.com",
        status: "Invitation send",
      },
      {
        slno: "15",
        name: "Abhi",
        usertype: "admin",
        emailaddress: "uvais@gmail.com",
        status: "Invitation send",
      },
      {
        slno: "16",
        name: "Abhi",
        usertype: "admin",
        emailaddress: "uvais@gmail.com",
        status: "Invitation send",
      },
      {
        slno: "17",
        name: "Abhi",
        usertype: "admin",
        emailaddress: "uvais@gmail.com",
        status: "Invitation send",
      },
      {
        slno: "18",
        name: "Abhi",
        usertype: "admin",
        emailaddress: "uvais@gmail.com",
        status: "Invitation send",
      },
      {
        slno: "19",
        name: "Abhi",
        usertype: "admin",
        emailaddress: "uvais@gmail.com",
        status: "Invitation send",
      },
      {
        slno: "20",
        name: "Abhi",
        usertype: "admin",
        emailaddress: "uvais@gmail.com",
        status: "Invitation send",
      },
      {
        slno: "21",
        name: "Abhi",
        usertype: "admin",
        emailaddress: "uvais@gmail.com",
        status: "Invitation send",
      },
      {
        slno: "22",
        name: "Abhi",
        usertype: "admin",
        emailaddress: "uvais@gmail.com",
        status: "Invitation send",
      },
      {
        slno: "23",
        name: "Abhi",
        usertype: "admin",
        emailaddress: "uvais@gmail.com",
        status: "Invitation send",
      },
      {
        slno: "24",
        name: "Abhi",
        usertype: "admin",
        emailaddress: "uvais@gmail.com",
        status: "Invitation send",
      },
    ],
  });

  //pagination=======================================

  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage, setItemsPerPage] = useState(22);

  const IndexofLastItem = currentPage * itemsPerPage;
  const indexOfFirstDish = IndexofLastItem - itemsPerPage;
  let PaginatedData = userlist.data.slice(indexOfFirstDish, IndexofLastItem);

  const ChangePage = (event, value) => {
    setCurrentPage(value);
  };

  const NumOfpages = Math.ceil(userlist.data.length / itemsPerPage);
  return (
    <TableContainer>
      <Table>
        <THead>
          <TableHeadRow>
            <TH> SI No</TH>
            <TH> Name </TH>
            <TH> User Type </TH>
            <TH> Email Address </TH>
            <TH>Status </TH>

            <TH></TH>
          </TableHeadRow>
        </THead>
        <TBody>
          {PaginatedData.map((i, index) => (
            <TableBodyRow>
              <TD> {i.slno} </TD>
              <TD> {i.name} </TD>
              <TD> {i.usertype} </TD>
              <TD> {i.emailaddress} </TD>
              <TD greencolor={i.status}> {i.status} </TD>

              <TD style={{ textAlign: "right" }}>
                <RightSide>
                  <IconButton
                    aria-label="more"
                    // id={index}
                    aria-controls={open ? "long-menu" : undefined}
                    aria-expanded={open ? "true" : undefined}
                    aria-haspopup="true"
                    onClick={handleClick(index)}
                  >
                    <MoreVertIcon />
                  </IconButton>

                  {index === currentIndex ? (
                    <Menus
                      // id="long-menu"
                      MenuListProps={
                        {
                          // "aria-labelledby": ` ${index}`,
                        }
                      }
                      disableScrollLock={true}
                      anchorEl={anchorEl}
                      open={open}
                      onClose={handleClose}
                      PaperProps={{
                        style: {
                          maxHeight: ITEM_HEIGHT * 4.5,
                          width: "20ch",
                        },
                      }}
                    >
                      {options.map((option) => (
                        <MenuItem
                          key={option}
                          selected={option === "Pyxis"}
                          onClick={handleClose}
                        >
                          {option}
                        </MenuItem>
                      ))}
                    </Menus>
                  ) : null}
                </RightSide>
              </TD>
            </TableBodyRow>
          ))}
        </TBody>
      </Table>
      <PaginationContainer>
        <Pagination count={NumOfpages} onChange={ChangePage} />
      </PaginationContainer>
    </TableContainer>
  );
}

export default UsersList;

const PaginationContainer = styled.div`
  width: 100%;
  display: flex;
  margin-top: 10px;
  justify-content: center;
`;
const Menus = styled(Menu)`
  .css-1poimk-MuiPaper-root-MuiMenu-paper-MuiPaper-root-MuiPopover-paper {
    ::-webkit-scrollbar {
      display: none !important;
    }
  }
`;
const RightSide = styled.div`
  height: 100%;
  svg {
    font-size: 1.1rem !important ;
    color: black !important;
  }
  .css-78trlr-MuiButtonBase-root-MuiIconButton-root {
    padding: unset !important;
  }
  .MuiPaper-root {
    box-shadow: none !important;
  }
`;

const TableContainer = styled.div`
  margin-top: 15px;
`;
const TD = styled.td`
  padding: 5px 15px !important;
  font-size: 12px;
  text-align: left;

  border-bottom: 1px solid #ababab;
  vertical-align: middle;
  color: ${({ greencolor }) => (greencolor ? "green" : "black")};
  &.cursor {
    cursor: pointer;
  }
`;
const TableBodyRow = styled.tr`
  :hover {
    background-color: rgba(0, 0, 0, 0.04);
  }
`;
const Table = styled.table`
  border-radius: 15px;
  width: 100%;
  background: #fff;
  border-spacing: unset;
`;

const THead = styled.thead`
  box-shadow: 0 0 0 1px #c6c6c6;
  border-radius: 3px;
  background-color: black;
  color: white;
`;
const TableHeadRow = styled.tr``;
const TBody = styled.tbody``;
const TH = styled.th`
  padding: 5px 15px;
  font-weight: normal;
  text-align: left;
  font-size: 14px;
`;
