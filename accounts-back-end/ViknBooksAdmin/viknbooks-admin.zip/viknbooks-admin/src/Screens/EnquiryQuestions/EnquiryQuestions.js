import React from "react";
import CreateButton from "../../Components/CreateButton";
import { useState } from "react";
import styled from "styled-components/macro";
import AddQuestions from "./AddQuestions";

import EnquiryQuestionsList from "./EnquiryQuestionsList";
function Enquiry() {
  const [addPopup, setAddPopup] = useState(false);
  return (
    <Container>
      <Heading>
        <LeftContainer>
          <EnquiryTxt>Enquiry Questions</EnquiryTxt>
        </LeftContainer>

        <CreateButtonContainer onClick={(e) => setAddPopup(!addPopup)}>
          <CreateButton label={"Add New"} />
        </CreateButtonContainer>
      </Heading>
      <div>
        <EnquiryQuestionsList />
      </div>

      <div>
        <AddQuestions addPopup={addPopup} setAddPopup={setAddPopup} />
      </div>
    </Container>
  );
}

export default Enquiry;
const Container = styled.div``;
const Heading = styled.div`
  width: 100%;
  display: flex;
  justify-content: space-between;
`;
const LeftContainer = styled.div`
  display: flex;
  gap: 18px;
  align-items: center;
`;
const EnquiryTxt = styled.h2`
  font-size: 27px;
  letter-spacing: 1px; ;
`;
const CreateButtonContainer = styled.div`
  position: relative;
`;
