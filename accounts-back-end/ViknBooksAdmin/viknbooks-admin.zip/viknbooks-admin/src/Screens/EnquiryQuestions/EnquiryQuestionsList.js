import React, { useState } from "react";
import styled from "styled-components/macro";

import { IconButton, Menu, MenuItem } from "@mui/material";

import MoreVertIcon from "@mui/icons-material/MoreVert";
import Pagination from "@mui/material/Pagination";
function EnquiryQuestionsList() {
  const options = ["Phobos", "Pyxis", "Sedna", "Titania", "Triton", "Umbriel"];
  const [anchorEl, setAnchorEl] = useState(null);
  const open = Boolean(anchorEl);
  const [currentIndex, setCurrentIndex] = useState();
  const handleClick = (index) => (event) => {
    setAnchorEl(event.currentTarget);
    setCurrentIndex(index);
  };
  const handleClose = () => {
    setAnchorEl(null);
  };
  const ITEM_HEIGHT = 48;

  const [enquiryList, setEnquiryList] = useState({
    data: [
      {
        id: "1",
        questions: "What are you doing",
        description: "Not me but you",
      },
      { id: "2", questions: "What is this", description: "Aaaaaaaaaaaaaaa" },
      {
        id: "3",
        questions: "weefsefsdfdvf",
        description: "Eeeeeeeeeeee",
      },
      {
        id: "4",
        questions: "weefsefsdfdvf",
        description: "Eeeeeeeeeeee",
      },
      {
        id: "5",
        questions: "weefsefsdfdvf",
        description: "Eeeeeeeeeeee",
      },
      {
        id: "6",
        questions: "weefsefsdfdvf",
        description: "Eeeeeeeeeeee",
      },
      {
        id: "7",
        questions: "weefsefsdfdvf",
        description: "Eeeeeeeeeeee",
      },
      {
        id: "8",
        questions: "weefsefsdfdvf",
        description: "Eeeeeeeeeeee",
      },
      {
        id: "9",
        questions: "weefsefsdfdvf",
        description: "Eeeeeeeeeeee",
      },
      {
        id: "10",
        questions: "weefsefsdfdvf",
        description: "Eeeeeeeeeeee",
      },
      {
        id: "11",
        questions: "weefsefsdfdvf",
        description: "Eeeeeeeeeeee",
      },
      {
        id: "12",
        questions: "weefsefsdfdvf",
        description: "Eeeeeeeeeeee",
      },
      {
        id: "13",
        questions: "weefsefsdfdvf",
        description: "Eeeeeeeeeeee",
      },
      {
        id: "14",
        questions: "weefsefsdfdvf",
        description: "Eeeeeeeeeeee",
      },
      {
        id: "15",
        questions: "weefsefsdfdvf",
        description: "Eeeeeeeeeeee",
      },
      {
        id: "16",
        questions: "weefsefsdfdvf",
        description: "Eeeeeeeeeeee",
      },
      {
        id: "17",
        questions: "weefsefsdfdvf",
        description: "Eeeeeeeeeeee",
      },
      {
        id: "18",
        questions: "weefsefsdfdvf",
        description: "Eeeeeeeeeeee",
      },
      {
        id: "19",
        questions: "weefsefsdfdvf",
        description: "Eeeeeeeeeeee",
      },
      {
        id: "20",
        questions: "weefsefsdfdvf",
        description: "Eeeeeeeeeeee",
      },
      {
        id: "21",
        questions: "weefsefsdfdvf",
        description: "Eeeeeeeeeeee",
      },
      {
        id: "22",
        questions: "weefsefsdfdvf",
        description: "Eeeeeeeeeeee",
      },
      {
        id: "23",
        questions: "weefsefsdfdvf",
        description: "Eeeeeeeeeeee",
      },
      {
        id: "24",
        questions: "weefsefsdfdvf",
        description: "Eeeeeeeeeeee",
      },
      {
        id: "25",
        questions: "weefsefsdfdvf",
        description: "Eeeeeeeeeeee",
      },
      {
        id: "26",
        questions: "weefsefsdfdvf",
        description: "Eeeeeeeeeeee",
      },
      {
        id: "27",
        questions: "weefsefsdfdvf",
        description: "Eeeeeeeeeeee",
      },
      {
        id: "28",
        questions: "weefsefsdfdvf",
        description: "Eeeeeeeeeeee",
      },
      {
        id: "29",
        questions: "weefsefsdfdvf",
        description: "Eeeeeeeeeeee",
      },
    ],
  });

  //pagination=======================================

  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage, setItemsPerPage] = useState(22);

  const IndexofLastItem = currentPage * itemsPerPage;
  const indexOfFirstDish = IndexofLastItem - itemsPerPage;
  let PaginatedData = enquiryList.data.slice(indexOfFirstDish, IndexofLastItem);

  const ChangePage = (event, value) => {
    setCurrentPage(value);
  };

  const NumOfpages = Math.ceil(enquiryList.data.length / itemsPerPage);
  return (
    <TableContainer>
      <Table>
        <THead>
          <TableHeadRow>
            <TH> ID </TH>
            <TH> Question </TH>
            <TH> Description </TH>

            <TH></TH>
          </TableHeadRow>
        </THead>
        <TBody>
          {PaginatedData.map((i, index) => (
            <TableBodyRow>
              <TD> {i.id} </TD>
              <TD> {i.questions} </TD>
              <TD> {i.description} </TD>

              <TD style={{ textAlign: "right" }}>
                <RightSide>
                  <IconButton
                    aria-label="more"
                    // id={index}
                    aria-controls={open ? "long-menu" : undefined}
                    aria-expanded={open ? "true" : undefined}
                    aria-haspopup="true"
                    onClick={handleClick(index)}
                  >
                    <MoreVertIcon />
                  </IconButton>
                  {currentIndex === index ? (
                    <Menus
                      // id="long-menu"
                      MenuListProps={
                        {
                          // "aria-labelledby": ` ${index}`,
                        }
                      }
                      anchorEl={anchorEl}
                      open={open}
                      onClose={handleClose}
                      PaperProps={{
                        style: {
                          maxHeight: ITEM_HEIGHT * 4.5,
                          width: "20ch",
                        },
                      }}
                      disableScrollLock={true}
                    >
                      {options.map((option) => (
                        <MenuItem
                          key={option}
                          selected={option === "Pyxis"}
                          onClick={handleClose}
                        >
                          {option}
                        </MenuItem>
                      ))}
                    </Menus>
                  ) : null}
                </RightSide>
              </TD>
            </TableBodyRow>
          ))}
        </TBody>
      </Table>
      <PaginationContainer>
        <Pagination count={NumOfpages} onChange={ChangePage} />
      </PaginationContainer>
    </TableContainer>
  );
}

export default EnquiryQuestionsList;
const PaginationContainer = styled.div`
  width: 100%;
  display: flex;
  margin-top: 10px;
  justify-content: center;
`;
const Menus = styled(Menu)`
  .css-1poimk-MuiPaper-root-MuiMenu-paper-MuiPaper-root-MuiPopover-paper {
    ::-webkit-scrollbar {
      display: none !important;
    }
  }
`;
const RightSide = styled.div`
  height: 100%;
  svg {
    font-size: 1.1rem !important ;
    color: black !important;
  }
  .css-78trlr-MuiButtonBase-root-MuiIconButton-root {
    padding: unset !important;
  }
  .MuiPaper-root {
    box-shadow: none !important;
  }
`;

const TableContainer = styled.div`
  margin-top: 15px;
`;
const TD = styled.td`
  padding: 5px 15px !important;
  text-align: left;
  padding: 0.5em 1em;
  font-size: 12px;
  border-bottom: 1px solid #ababab;
  vertical-align: middle;

  &.cursor {
    cursor: pointer;
  }
`;
const TableBodyRow = styled.tr`
  :hover {
    background-color: rgba(0, 0, 0, 0.04);
  }
`;
const Table = styled.table`
  border-radius: 15px;
  width: 100%;
  background: #fff;
  border-spacing: unset;
`;

const THead = styled.thead`
  box-shadow: 0 0 0 1px #c6c6c6;
  border-radius: 3px;
  background-color: black;
  color: white;
`;
const TableHeadRow = styled.tr``;
const TBody = styled.tbody``;
const TH = styled.th`
  padding: 5px 15px;
  font-weight: normal;
  text-align: left;
  font-size: 14px;
`;
