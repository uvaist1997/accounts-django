import React from "react";
import CreateButton from "../../Components/CreateButton";

import styled from "styled-components/macro";

import Uqctable from "./Uqctable";
function Uqc() {
  return (
    <Container>
      <Heading>
        <LeftContainer>
          <UqcTxt>UQC</UqcTxt>
        </LeftContainer>

        <CreateButtonContainer>
          <CreateButton label={"Add New"} />
        </CreateButtonContainer>
      </Heading>
      <div>
        <Uqctable />
      </div>
    </Container>
  );
}

export default Uqc;
const Container = styled.div``;
const Heading = styled.div`
  width: 100%;
  display: flex;
  justify-content: space-between;
`;
const LeftContainer = styled.div`
  display: flex;
  gap: 18px;
  align-items: center;
`;
const UqcTxt = styled.h2`
  font-size: 27px;
  letter-spacing: 1px; ;
`;
const CreateButtonContainer = styled.div`
  position: relative;
`;
