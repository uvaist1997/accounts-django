import React, { useState } from "react";
import styled from "styled-components/macro";

import { IconButton, Menu, MenuItem, TableSortLabel } from "@mui/material";

import MoreVertIcon from "@mui/icons-material/MoreVert";
import Pagination from "@mui/material/Pagination";
function CountryTable() {
  const [rotate, setRotate] = useState(false);
  const [td, setTd] = useState([1, 2, 3, 4, 5, 6, 7, 8, 9, 8, 7]);
  const options = ["Edit", "Delete"];
  const [anchorEl, setAnchorEl] = useState(null);
  const open = Boolean(anchorEl);

  const [currentIndex, setCurrentIndex] = useState();
  const handleClick = (index) => (event) => {
    setAnchorEl(event.currentTarget);
    setCurrentIndex(index);
  };
  const handleClose = () => {
    setAnchorEl(null);
  };
  const ITEM_HEIGHT = 48;
  const [countryList, setCountryList] = useState({
    data: [
      {
        id: "1",
        countryname: "India",
        countrycode: "10010",
        change: "abcd",
        symbol: "symbol",
        fractionalunits: "0.005",
        currency: "$",
      },
      {
        id: "2",
        countryname: "China",
        countrycode: "10410",
        change: "abcd",
        symbol: "symbol",
        fractionalunits: "0.2305",
        currency: "#",
      },
      {
        id: "3",
        countryname: "Germany",
        countrycode: "10070",
        change: "abcd",
        symbol: "symbol",
        fractionalunits: "0.00545",
        currency: "$$",
      },
      {
        id: "4",
        countryname: "Germany",
        countrycode: "10070",
        change: "abcd",
        symbol: "symbol",
        fractionalunits: "0.00545",
        currency: "$$",
      },
      {
        id: "5",
        countryname: "Germany",
        countrycode: "10070",
        change: "abcd",
        symbol: "symbol",
        fractionalunits: "0.00545",
        currency: "$$",
      },
      {
        id: "6",
        countryname: "Germany",
        countrycode: "10070",
        change: "abcd",
        symbol: "symbol",
        fractionalunits: "0.00545",
        currency: "$$",
      },
      {
        id: "7",
        countryname: "Germany",
        countrycode: "10070",
        change: "abcd",
        symbol: "symbol",
        fractionalunits: "0.00545",
        currency: "$$",
      },
      {
        id: "8",
        countryname: "Germany",
        countrycode: "10070",
        change: "abcd",
        symbol: "symbol",
        fractionalunits: "0.00545",
        currency: "$$",
      },
      {
        id: "9",
        countryname: "Germany",
        countrycode: "10070",
        change: "abcd",
        symbol: "symbol",
        fractionalunits: "0.00545",
        currency: "$$",
      },
      {
        id: "10",
        countryname: "Germany",
        countrycode: "10070",
        change: "abcd",
        symbol: "symbol",
        fractionalunits: "0.00545",
        currency: "$$",
      },
      {
        id: "11",
        countryname: "Germany",
        countrycode: "10070",
        change: "abcd",
        symbol: "symbol",
        fractionalunits: "0.00545",
        currency: "$$",
      },
      {
        id: "12",
        countryname: "Germany",
        countrycode: "10070",
        change: "abcd",
        symbol: "symbol",
        fractionalunits: "0.00545",
        currency: "$$",
      },
      {
        id: "13",
        countryname: "Germany",
        countrycode: "10070",
        change: "abcd",
        symbol: "symbol",
        fractionalunits: "0.00545",
        currency: "$$",
      },
      {
        id: "14",
        countryname: "Germany",
        countrycode: "10070",
        change: "abcd",
        symbol: "symbol",
        fractionalunits: "0.00545",
        currency: "$$",
      },
      {
        id: "19",
        countryname: "Germany",
        countrycode: "10070",
        change: "abcd",
        symbol: "symbol",
        fractionalunits: "0.00545",
        currency: "$$",
      },
      {
        id: "15",
        countryname: "Germany",
        countrycode: "10070",
        change: "abcd",
        symbol: "symbol",
        fractionalunits: "0.00545",
        currency: "$$",
      },
      {
        id: "16",
        countryname: "Germany",
        countrycode: "10070",
        change: "abcd",
        symbol: "symbol",
        fractionalunits: "0.00545",
        currency: "$$",
      },
      {
        id: "17",
        countryname: "Germany",
        countrycode: "10070",
        change: "abcd",
        symbol: "symbol",
        fractionalunits: "0.00545",
        currency: "$$",
      },
      {
        id: "18",
        countryname: "Germany",
        countrycode: "10070",
        change: "abcd",
        symbol: "symbol",
        fractionalunits: "0.00545",
        currency: "$$",
      },
      {
        id: "19",
        countryname: "Germany",
        countrycode: "10070",
        change: "abcd",
        symbol: "symbol",
        fractionalunits: "0.00545",
        currency: "$$",
      },
      {
        id: "20",
        countryname: "Germany",
        countrycode: "10070",
        change: "abcd",
        symbol: "symbol",
        fractionalunits: "0.00545",
        currency: "$$",
      },
      {
        id: "31",
        countryname: "Germany",
        countrycode: "10070",
        change: "abcd",
        symbol: "symbol",
        fractionalunits: "0.00545",
        currency: "$$",
      },
      {
        id: "21",
        countryname: "Germany",
        countrycode: "10070",
        change: "abcd",
        symbol: "symbol",
        fractionalunits: "0.00545",
        currency: "$$",
      },
      {
        id: "22",
        countryname: "Germany",
        countrycode: "10070",
        change: "abcd",
        symbol: "symbol",
        fractionalunits: "0.00545",
        currency: "$$",
      },
      {
        id: "23",
        countryname: "Germany",
        countrycode: "10070",
        change: "abcd",
        symbol: "symbol",
        fractionalunits: "0.00545",
        currency: "$$",
      },
      {
        id: "24",
        countryname: "Germany",
        countrycode: "10070",
        change: "abcd",
        symbol: "symbol",
        fractionalunits: "0.00545",
        currency: "$$",
      },
      {
        id: "25",
        countryname: "Germany",
        countrycode: "10070",
        change: "abcd",
        symbol: "symbol",
        fractionalunits: "0.00545",
        currency: "$$",
      },
      {
        id: "26",
        countryname: "Germany",
        countrycode: "10070",
        change: "abcd",
        symbol: "symbol",
        fractionalunits: "0.00545",
        currency: "$$",
      },
      {
        id: "27",
        countryname: "Germany",
        countrycode: "10070",
        change: "abcd",
        symbol: "symbol",
        fractionalunits: "0.00545",
        currency: "$$",
      },
      {
        id: "28",
        countryname: "Germany",
        countrycode: "10070",
        change: "abcd",
        symbol: "symbol",
        fractionalunits: "0.00545",
        currency: "$$",
      },
      {
        id: "29",
        countryname: "Germany",
        countrycode: "10070",
        change: "abcd",
        symbol: "symbol",
        fractionalunits: "0.00545",
        currency: "$$",
      },
      {
        id: "30",
        countryname: "Germany",
        countrycode: "10070",
        change: "abcd",
        symbol: "symbol",
        fractionalunits: "0.00545",
        currency: "$$",
      },
      {
        id: "31",
        countryname: "Germany",
        countrycode: "10070",
        change: "abcd",
        symbol: "symbol",
        fractionalunits: "0.00545",
        currency: "$$",
      },
      {
        id: "32",
        countryname: "Germany",
        countrycode: "10070",
        change: "abcd",
        symbol: "symbol",
        fractionalunits: "0.00545",
        currency: "$$",
      },
    ],
  });
  //pagination=======================================

  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage, setItemsPerPage] = useState(22);

  const IndexofLastItem = currentPage * itemsPerPage;
  const indexOfFirstDish = IndexofLastItem - itemsPerPage;
  let PaginatedData = countryList.data.slice(indexOfFirstDish, IndexofLastItem);
  console.log("page", PaginatedData);

  const ChangePage = (event, value) => {
    setCurrentPage(value);
  };

  const NumOfpages = Math.ceil(countryList.data.length / itemsPerPage);

  return (
    <TableContainer>
      <Table>
        <THead>
          <TableHeadRow>
            <TH> ID </TH>
            <TH> Country </TH>
            <TH> Country Code </TH>
            <TH> Change </TH>
            <TH> Symbol </TH>
            <TH> Fractional Units </TH>
            <TH> Currency </TH>

            <TH></TH>
          </TableHeadRow>
        </THead>
        <TBody>
          {PaginatedData.map((i, index) => (
            <TableBodyRow>
              <TD>{i.id}</TD>

              <TD>{i.countryname}</TD>
              <TD>{i.countrycode}</TD>
              <TD>{i.change}</TD>
              <TD>{i.symbol}</TD>
              <TD>{i.fractionalunits}</TD>
              <TD>{i.currency}</TD>

              <TD style={{ textAlign: "right" }}>
                <RightSide>
                  <IconButton
                    aria-label="more"
                    id={index}
                    aria-controls={open ? "long-menu" : undefined}
                    aria-expanded={open ? "true" : undefined}
                    aria-haspopup="true"
                    onClick={handleClick(index)}
                  >
                    <MoreVertIcon />
                  </IconButton>
                  {currentIndex === index ? (
                    <Menus
                      disableScrollLock={true}
                      MenuListProps={
                        {
                          // "aria-labelledby": ` ${index}`,
                        }
                      }
                      anchorEl={anchorEl}
                      open={open}
                      onClose={handleClose}
                      PaperProps={{
                        style: {
                          maxHeight: ITEM_HEIGHT * 4.5,
                          width: "20ch",
                        },
                      }}
                    >
                      {options.map((option) => (
                        <MenuItem
                          key={option}
                          selected={option === "Edit"}
                          onClick={handleClose}
                        >
                          {option}
                        </MenuItem>
                      ))}
                    </Menus>
                  ) : null}
                </RightSide>
              </TD>
            </TableBodyRow>
          ))}
        </TBody>
      </Table>
      <PaginationContainer>
        <Pagination count={NumOfpages} onChange={ChangePage} />
      </PaginationContainer>
    </TableContainer>
  );
}

export default CountryTable;

const PaginationContainer = styled.div`
  width: 100%;
  display: flex;
  margin-top: 10px;
  justify-content: center;
`;
const Menus = styled(Menu)`
  .css-1poimk-MuiPaper-root-MuiMenu-paper-MuiPaper-root-MuiPopover-paper {
    ::-webkit-scrollbar {
      display: none !important;
    }
  }
`;
const RightSide = styled.div`
  height: 100%;
  svg {
    font-size: 1.1rem !important ;
    color: black !important;
  }
  .css-78trlr-MuiButtonBase-root-MuiIconButton-root {
    padding: unset !important;
  }
  .MuiPaper-root {
    box-shadow: none !important;
  }
`;

const TableContainer = styled.div`
  margin-top: 15px;
`;
const TD = styled.td`
  font-size: 12px;
  padding: 5px 15px !important;
  text-align: left;

  border-bottom: 1px solid #ababab;
  vertical-align: middle;

  &.cursor {
    cursor: pointer;
  }
`;
const TableBodyRow = styled.tr`
  :hover {
    background-color: rgba(0, 0, 0, 0.04);
  }
`;
const Table = styled.table`
  border-radius: 15px;
  width: 100%;
  background: #fff;
  border-spacing: unset;
`;

const THead = styled.thead`
  box-shadow: 0 0 0 1px #c6c6c6;
  border-radius: 3px;
  background-color: black;
  color: white;
`;
const TableHeadRow = styled.tr``;
const TBody = styled.tbody``;
const TH = styled.th`
  padding: 5px 15px;
  font-weight: normal;
  text-align: left;
  font-size: 14px;
`;
