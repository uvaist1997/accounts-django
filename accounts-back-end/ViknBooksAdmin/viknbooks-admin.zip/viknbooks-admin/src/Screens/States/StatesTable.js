import React, { useState } from "react";
import styled from "styled-components/macro";

import { IconButton, Menu, MenuItem, TableSortLabel } from "@mui/material";

import MoreVertIcon from "@mui/icons-material/MoreVert";
import Pagination from "@mui/material/Pagination";
function StatesTable({}) {
  const options = ["Edit", "Delete"];
  const [anchorEl, setAnchorEl] = useState(null);
  const open = Boolean(anchorEl);

  const [currentIndex, setCurrentIndex] = useState();
  const handleClick = (index) => (event) => {
    setAnchorEl(event.currentTarget);
    setCurrentIndex(index);
  };
  const handleClose = () => {
    setAnchorEl(null);
  };
  const ITEM_HEIGHT = 48;

  const [stateList, setStateList] = useState({
    data: [
      { id: "1", statename: "kerala", country: "india", statecode: "10001" },
      {
        id: "2",
        statename: "tamilnadu",
        country: "india",
        statecode: "15601",
      },
      {
        id: "3",
        statename: "Goa",
        country: "india",
        statecode: "15671",
      },
      {
        id: "3",
        statename: "Goa",
        country: "india",
        statecode: "15671",
      },
      {
        id: "4",
        statename: "Goa",
        country: "india",
        statecode: "15671",
      },
      {
        id: "5",
        statename: "Goa",
        country: "india",
        statecode: "15671",
      },
      {
        id: "6",
        statename: "Goa",
        country: "india",
        statecode: "15671",
      },
      {
        id: "7",
        statename: "Goa",
        country: "india",
        statecode: "15671",
      },
      {
        id: "8",
        statename: "Goa",
        country: "india",
        statecode: "15671",
      },
      {
        id: "9",
        statename: "Goa",
        country: "india",
        statecode: "15671",
      },
      {
        id: "10",
        statename: "Goa",
        country: "india",
        statecode: "15671",
      },
      {
        id: "11",
        statename: "Goa",
        country: "india",
        statecode: "15671",
      },
      {
        id: "12",
        statename: "Goa",
        country: "india",
        statecode: "15671",
      },
      {
        id: "13",
        statename: "Goa",
        country: "india",
        statecode: "15671",
      },
      {
        id: "14",
        statename: "Goa",
        country: "india",
        statecode: "15671",
      },
      {
        id: "15",
        statename: "Goa",
        country: "india",
        statecode: "15671",
      },
      {
        id: "16",
        statename: "Goa",
        country: "india",
        statecode: "15671",
      },
      {
        id: "17",
        statename: "Goa",
        country: "india",
        statecode: "15671",
      },
      {
        id: "18",
        statename: "Goa",
        country: "india",
        statecode: "15671",
      },
      {
        id: "19",
        statename: "Goa",
        country: "india",
        statecode: "15671",
      },
      {
        id: "20",
        statename: "Goa",
        country: "india",
        statecode: "15671",
      },
      {
        id: "21",
        statename: "Goa",
        country: "india",
        statecode: "15671",
      },
      {
        id: "22",
        statename: "Goa",
        country: "india",
        statecode: "15671",
      },
      {
        id: "23",
        statename: "Goa",
        country: "india",
        statecode: "15671",
      },
      {
        id: "24",
        statename: "Goa",
        country: "india",
        statecode: "15671",
      },
      {
        id: "25",
        statename: "Goa",
        country: "india",
        statecode: "15671",
      },
      {
        id: "26",
        statename: "Goa",
        country: "india",
        statecode: "15671",
      },
      {
        id: "27",
        statename: "Goa",
        country: "india",
        statecode: "15671",
      },
      {
        id: "28",
        statename: "Goa",
        country: "india",
        statecode: "15671",
      },
      {
        id: "29",
        statename: "Goa",
        country: "india",
        statecode: "15671",
      },
      {
        id: "30",
        statename: "Goa",
        country: "india",
        statecode: "15671",
      },
      {
        id: "31",
        statename: "Goa",
        country: "india",
        statecode: "15671",
      },
      {
        id: "32",
        statename: "Goa",
        country: "india",
        statecode: "15671",
      },
    ],
  });

  //pagination=======================================

  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage, setItemsPerPage] = useState(22);

  const IndexofLastItem = currentPage * itemsPerPage;
  const indexOfFirstDish = IndexofLastItem - itemsPerPage;
  let PaginatedData = stateList.data.slice(indexOfFirstDish, IndexofLastItem);

  const ChangePage = (event, value) => {
    setCurrentPage(value);
  };

  const NumOfpages = Math.ceil(stateList.data.length / itemsPerPage);
  return (
    <TableContainer>
      <Table>
        <THead>
          <TableHeadRow>
            <TH> ID </TH>
            <TH> State </TH>
            <TH> Country </TH>
            <TH> State Code </TH>

            <TH></TH>
          </TableHeadRow>
        </THead>
        <TBody>
          {PaginatedData.map((i, index) => (
            <TableBodyRow>
              <TD> {i.id} </TD>
              <TD> {i.statename} </TD>
              <TD> {i.country} </TD>
              <TD> {i.statecode} </TD>

              <TD style={{ textAlign: "right" }}>
                <RightSide>
                  <IconButton
                    aria-label="more"
                    id={index}
                    aria-controls={open ? "long-menu" : undefined}
                    aria-expanded={open ? "true" : undefined}
                    aria-haspopup="true"
                    onClick={handleClick(index)}
                  >
                    <MoreVertIcon />
                  </IconButton>

                  {currentIndex === index ? (
                    <Menus
                      // id="long-menu"

                      disableScrollLock={true}
                      MenuListProps={
                        {
                          // "aria-labelledby": ` ${index}`,
                        }
                      }
                      anchorEl={anchorEl}
                      open={open}
                      onClose={handleClose}
                      PaperProps={{
                        style: {
                          maxHeight: ITEM_HEIGHT * 4.5,
                          width: "20ch",
                        },
                      }}
                    >
                      {options.map((option) => (
                        <MenuItem
                          key={option}
                          selected={option === "Edit"}
                          onClick={handleClose}
                        >
                          {option}
                        </MenuItem>
                      ))}
                    </Menus>
                  ) : null}
                </RightSide>
              </TD>
            </TableBodyRow>
          ))}
        </TBody>
      </Table>
      <PaginationContainer>
        <Pagination count={NumOfpages} onChange={ChangePage} />
      </PaginationContainer>
    </TableContainer>
  );
}

export default StatesTable;
const PaginationContainer = styled.div`
  width: 100%;
  display: flex;
  margin-top: 10px;
  justify-content: center;
`;
const Menus = styled(Menu)`
  .css-1poimk-MuiPaper-root-MuiMenu-paper-MuiPaper-root-MuiPopover-paper {
    ::-webkit-scrollbar {
      display: none !important;
    }
  }
`;
const RightSide = styled.div`
  height: 100%;
  svg {
    font-size: 1.1rem !important ;
    color: black !important;
  }
  .css-78trlr-MuiButtonBase-root-MuiIconButton-root {
    padding: unset !important;
  }
  .MuiPaper-root {
    box-shadow: none !important;
  }
`;

const TableContainer = styled.div`
  margin-top: 15px;
`;
const TD = styled.td`
  padding: 5px 15px !important;
  font-size: 12px;
  text-align: left;

  border-bottom: 1px solid #ababab;
  vertical-align: middle;

  &.cursor {
    cursor: pointer;
  }
`;
const TableBodyRow = styled.tr`
  :hover {
    background-color: rgba(0, 0, 0, 0.04);
  }
`;
const Table = styled.table`
  border-radius: 15px;
  width: 100%;
  background: #fff;
  border-spacing: unset;
`;

const THead = styled.thead`
  box-shadow: 0 0 0 1px #c6c6c6;
  border-radius: 3px;
  background-color: black;
  color: white;
`;
const TableHeadRow = styled.tr``;
const TBody = styled.tbody``;
const TH = styled.th`
  padding: 5px 15px;
  font-weight: normal;
  text-align: left;
  font-size: 14px;
`;
