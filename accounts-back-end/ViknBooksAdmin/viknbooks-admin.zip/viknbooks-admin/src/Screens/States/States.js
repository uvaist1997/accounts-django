import React from "react";
import CreateButton from "../../Components/CreateButton";

import styled from "styled-components/macro";

import StatesTable from "./StatesTable";
function States() {
  return (
    <Container>
      <Heading>
        <LeftContainer>
          <StatesTxt>States</StatesTxt>
        </LeftContainer>

        <CreateButtonContainer>
          <CreateButton label={"Add New"} />
        </CreateButtonContainer>
      </Heading>
      <div>
        <StatesTable />
      </div>
    </Container>
  );
}

export default States;
const Container = styled.div``;
const Heading = styled.div`
  width: 100%;
  display: flex;
  justify-content: space-between;
`;
const LeftContainer = styled.div`
  display: flex;
  gap: 18px;
  align-items: center;
`;
const StatesTxt = styled.h2`
  font-size: 27px;
  letter-spacing: 1px; ;
`;
const CreateButtonContainer = styled.div`
  position: relative;
`;
