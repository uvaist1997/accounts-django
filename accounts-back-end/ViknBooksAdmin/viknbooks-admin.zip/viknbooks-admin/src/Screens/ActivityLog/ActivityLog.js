import React, { useState } from "react";
import styled from "styled-components/macro";
import Box from "@mui/material/Box";
import TextField from "@mui/material/TextField";
import MenuItem from "@mui/material/MenuItem";
import { Autocomplete, Button } from "@mui/material";
import FormControl from "@mui/material/FormControl";
import Select from "@mui/material/Select";
import FormGroup from "@mui/material/FormGroup";
import FormControlLabel from "@mui/material/FormControlLabel";
import Checkbox from "@mui/material/Checkbox";
import { style } from "@mui/system";
import ActivityList from "./ActivityList";
function ActivityLog() {
  const [age, setAge] = React.useState("");
  const [state, setState] = useState({
    data: ["uvais", "jasmal", "abhi"],
  });
  const handleSelectChange = () => {
    console.log("select");
  };

  const [card, setCard] = useState([
    1,
    2,
    3,
    4,
    5,
    6,
    7,
    8,
    9,
    10,
    1,
    2,
    3,
    4,
    5,
    3,
    4,
    5,
    6,
    6,
    5,
    4,
    ,
    34,
    3,
    3,
    3,
    3,
    3,
    3,
    3,
    4,
    5,
    6,
    6,
  ]);

  const handleChange = (event) => {
    setAge(event.target.value);
  };
  return (
    <Container>
      <Heading>
        <ActivitylogTxt>Activity Log</ActivitylogTxt>
      </Heading>
      <Header__BoxContaner>
        <AllBoxesContainer>
          <SubContainer>
            <LabelTxt>Customer</LabelTxt>

            <Field1>
              <EditContainer>
                <SelectBox1>
                  <CustomeAutocomplete
                    size="small"
                    id="combo-box-demo"
                    options={state.data}
                    // getOptionLabel={(option) => option.username || ""}
                    onInputChange={(event, value, reason) => {}}
                    onChange={(e, v) => handleSelectChange("ReportUserID", v)}
                    renderInput={(params) => (
                      <TextField size="small" {...params} />
                    )}
                  />
                </SelectBox1>
              </EditContainer>
            </Field1>
          </SubContainer>
          <SubContainer>
            <LabelTxt>Organization</LabelTxt>

            <Field1>
              <EditContainer>
                <SelectBox1>
                  <CustomeAutocomplete
                    size="small"
                    id="combo-box-demo"
                    options={state.data}
                    // getOptionLabel={(option) => option.username || ""}
                    onInputChange={(event, value, reason) => {}}
                    onChange={(e, v) => handleSelectChange("ReportUserID", v)}
                    renderInput={(params) => (
                      <TextField size="small" {...params} />
                    )}
                  />
                </SelectBox1>
              </EditContainer>
            </Field1>
          </SubContainer>
          <SubContainer>
            <LabelTxt>Type</LabelTxt>

            <Field1>
              <EditContainer>
                <SelectBox1>
                  <CustomeAutocomplete
                    size="small"
                    id="combo-box-demo"
                    options={state.data}
                    // getOptionLabel={(option) => option.username || ""}
                    onInputChange={(event, value, reason) => {}}
                    onChange={(e, v) => handleSelectChange("ReportUserID", v)}
                    renderInput={(params) => (
                      <TextField size="small" {...params} />
                    )}
                  />
                </SelectBox1>
              </EditContainer>
            </Field1>
          </SubContainer>
          <SubContainer>
            <LabelTxt>Application</LabelTxt>

            <Field1>
              <EditContainer>
                <SelectBox1>
                  <CustomeAutocomplete
                    size="small"
                    id="combo-box-demo"
                    options={state.data}
                    // getOptionLabel={(option) => option.username || ""}
                    onInputChange={(event, value, reason) => {}}
                    onChange={(e, v) => handleSelectChange("ReportUserID", v)}
                    renderInput={(params) => (
                      <TextField size="small" {...params} />
                    )}
                  />
                </SelectBox1>
              </EditContainer>
            </Field1>
          </SubContainer>
          <FormGroup1>
            <FormControlLabel
              style={{ paddingTop: "23px", paddingLeft: "10px" }}
              control={
                <Checkbox
                  defaultChecked
                  color="default"
                  style={{ color: "black" }}
                />
              }
              label="solved"
            />
          </FormGroup1>
        </AllBoxesContainer>
        <SearchContainer>
          <SearchButton>Search</SearchButton>
        </SearchContainer>
      </Header__BoxContaner>

      <ActivityList />
    </Container>
  );
}

export default ActivityLog;

const SearchContainer = styled.div`
  display: flex;
  /* align-items: flex-start; */
  align-self: self-end;
  margin-bottom: 4px;
`;

const CustomeAutocomplete = styled(Autocomplete)`
  && {
    /* width: 150px; */
    margin-top: unset !important;
  }
  .css-1d3z3hw-MuiOutlinedInput-notchedOutline {
    outline: unset !important ;
    border-color: #d4d4d4 !important;
    border-width: 1px !important;
  }
  margin-top: 3px;
  button {
    padding: 0;
  }
  .css-19qh8xo-MuiInputBase-input-MuiOutlinedInput-input {
    height: 1rem !important;
  }
  &.css-1auycx3-MuiAutocomplete-root
    .MuiOutlinedInput-root.MuiInputBase-sizeSmall {
    padding: 4px !important ;
  }

  width: 201px;
`;

const LabelTxt = styled.label`
  font-size: 15px;
  color: black;
  width: 100%;
  padding-left: 1px;
`;
const FormGroup1 = styled(FormGroup)`
  svg {
    font-size: 1.3rem !important;
  }
  .css-j204z7-MuiFormControlLabel-root .MuiFormControlLabel-label {
    font-size: 13px;
  }
`;
const SubContainer = styled.div``;
const Field1 = styled.div``;

const EditContainer = styled.div`
  display: flex;

  align-items: center;

  height: 41px;
`;
const SearchButton = styled(Button)`
  && {
    background: #009e15;
    color: #fff;
    border-radius: 2px;
    padding: 4px 45px;
    text-transform: capitalize;
    &:hover {
      background: #009e15;
    }
  }
`;

const SeachBoxContainer = styled.div`
  width: 100%;

  .MuiOutlinedInput-notchedOutline {
    border-color: #d4d4d4 !important;
    border-width: 1px !important ;
    outline: unset !important;
  }
`;

const AllBoxesContainer = styled.div`
  display: flex;
  align-items: center;
  width: 100%;
  gap: 10px;
`;
const Header__BoxContaner = styled.div`
  display: flex;
  align-items: center;
  width: 100%;
  justify-content: space-between;
`;
const TextBox = styled(TextField)`
  outline: unset !important;
  .MuiOutlinedInput-input {
    padding: 6px 15px !important;
  }
  &.fieldset {
    border-color: black !important ;
  }
`;
const ActivitylogTxt = styled.h2`
  font-size: 25px;
  letter-spacing: 1px; ;
`;
const Container = styled.div``;
const Heading = styled.div`
  width: 100%;
  display: flex;
  justify-content: space-between;
`;
const SelectBox1 = styled.div``;
