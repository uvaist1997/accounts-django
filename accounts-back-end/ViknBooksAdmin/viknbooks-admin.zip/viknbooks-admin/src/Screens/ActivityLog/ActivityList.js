import { FormControl, MenuItem, Select } from "@mui/material";
import React, { useState } from "react";
import styled from "styled-components/macro";
import Pagination from "@mui/material/Pagination";
function ActivityList() {
  const [activityList, setActivityList] = useState({
    data: [
      {
        id: "1",
        date: "12-12-233",
        time: "10:00 AM",
        organization: "vikncodesLLP",
        application: "viknbooks",
        logtype: "qweerrt",
        message: "Product group deleted failed",

        status: "solved",
      },

      {
        id: "2",
        date: "12-12-233",
        time: "10:00 AM",
        organization: "vikncodes",
        application: "abcd",
        logtype: "warning",
        message: "Product group deleted failed",
        status: "unsolved",
      },
      {
        id: "3",
        date: "12-12-233",
        time: "10:00 AM",
        organization: "vikncodes",
        application: "abcd",
        logtype: "warning",
        message: "Product group deleted failed",
        status: "solved",
      },
      {
        id: "4",
        date: "12-12-233",
        time: "10:00 AM",
        organization: "vikncodes",
        application: "abcd",
        logtype: "warning",
        message: "Product group deleted failed",
        status: "unsolved",
      },
      {
        id: "5",
        date: "12-12-233",
        time: "10:00 AM",
        organization: "vikncodes",
        application: "abcd",
        logtype: "warning",
        message: "Product group deleted failed",
        status: "unsolved",
      },
      {
        id: "6",
        date: "12-12-233",
        time: "10:00 AM",
        organization: "vikncodes",
        application: "abcd",
        logtype: "warning",
        message: "Product group deleted failed",
        status: "unsolved",
      },
      {
        id: "7",
        date: "12-12-233",
        time: "10:00 AM",
        organization: "vikncodes",
        application: "abcd",
        logtype: "warning",
        message: "Product group deleted failed",
        status: "unsolved",
      },
      {
        id: "8",
        date: "12-12-233",
        time: "10:00 AM",
        organization: "vikncodes",
        application: "abcd",
        logtype: "warning",
        message: "Product group deleted failed",
        status: "unsolved",
      },
      {
        id: "9",
        date: "12-12-233",
        time: "10:00 AM",
        organization: "vikncodes",
        application: "abcd",
        logtype: "warning",
        message: "Product group deleted failed",
        status: "unsolved",
      },
      {
        id: "10",
        date: "12-12-233",
        time: "10:00 AM",
        organization: "vikncodes",
        application: "abcd",
        logtype: "warning",
        message: "Product group deleted failed",
        status: "unsolved",
      },
      {
        id: "11",
        date: "12-12-233",
        time: "10:00 AM",
        organization: "vikncodes",
        application: "abcd",
        logtype: "warning",
        message: "Product group deleted failed",
        status: "unsolved",
      },
      {
        id: "12",
        date: "12-12-233",
        time: "10:00 AM",
        organization: "vikncodes",
        application: "abcd",
        logtype: "warning",
        message: "Product group deleted failed",
        status: "unsolved",
      },
      {
        id: "13",
        date: "12-12-233",
        time: "10:00 AM",
        organization: "vikncodes",
        application: "abcd",
        logtype: "warning",
        message: "Product group deleted failed",
        status: "unsolved",
      },
      {
        id: "14",
        date: "12-12-233",
        time: "10:00 AM",
        organization: "vikncodes",
        application: "abcd",
        logtype: "warning",
        message: "Product group deleted failed",
        status: "solved",
      },
      {
        id: "15",
        date: "12-12-233",
        time: "10:00 AM",
        organization: "vikncodes",
        application: "abcd",
        logtype: "warning",
        message: "Product group deleted failed",
        status: "solved",
      },
      {
        id: "16",
        date: "12-12-233",
        time: "10:00 AM",
        organization: "vikncodes",
        application: "abcd",
        logtype: "warning",
        message: "Product group deleted failed",
        status: "solved",
      },
      {
        id: "17",
        date: "12-12-233",
        time: "10:00 AM",
        organization: "vikncodes",
        application: "abcd",
        logtype: "warning",
        message: "Product group deleted failed",
        status: "solved",
      },
      {
        id: "18",
        date: "12-12-233",
        time: "10:00 AM",
        organization: "vikncodes",
        application: "abcd",
        logtype: "warning",
        message: "Product group deleted failed",
        status: "solved",
      },
      {
        id: "19",
        date: "12-12-233",
        time: "10:00 AM",
        organization: "vikncodes",
        application: "abcd",
        logtype: "warning",
        message: "Product group deleted failed",
        status: "solved",
      },
      {
        id: "20",
        date: "12-12-233",
        time: "10:00 AM",
        organization: "vikncodes",
        application: "abcd",
        logtype: "warning",
        message: "Product group deleted failed",
        status: "solved",
      },
      {
        id: "21",
        date: "12-12-233",
        time: "10:00 AM",
        organization: "vikncodes",
        application: "abcd",
        logtype: "warning",
        message: "Product group deleted failed",
        status: "solved",
      },
      {
        id: "22",
        date: "12-12-233",
        time: "10:00 AM",
        organization: "vikncodes",
        application: "abcd",
        logtype: "warning",
        message: "Product group deleted failed",
        status: "solved",
      },
      {
        id: "23",
        date: "12-12-233",
        time: "10:00 AM",
        organization: "vikncodes",
        application: "abcd",
        logtype: "warning",
        message: "Product group deleted failed",
        status: "solved",
      },
      {
        id: "24",
        date: "12-12-233",
        time: "10:00 AM",
        organization: "vikncodes",
        application: "abcd",
        logtype: "warning",
        message: "Product group deleted failed",
        status: "solved",
      },
    ],
  });
  const handleChange = (index) => (event) => {
    const data = [...activityList.data];

    data[index]["status"] = event.target.value;

    setActivityList({ data });
  };
  //pagination=======================================

  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage, setItemsPerPage] = useState(9);

  const IndexofLastItem = currentPage * itemsPerPage;
  const indexOfFirstDish = IndexofLastItem - itemsPerPage;
  let PaginatedData = activityList.data.slice(
    indexOfFirstDish,
    IndexofLastItem
  );

  const ChangePage = (event, value) => {
    setCurrentPage(value);
  };

  const NumOfpages = Math.ceil(activityList.data.length / itemsPerPage);

  return (
    <TableContainer>
      <Table>
        <THead>
          <TableHeadRow>
            <TH> ID </TH>
            <TH> Date & Time </TH>
            <TH> Organization </TH>
            <TH> Application </TH>
            <TH> Log Type </TH>
            <TH> Message </TH>
            <TH style={{ width: "199px" }}>Status</TH>
          </TableHeadRow>
        </THead>
        <TBody>
          {PaginatedData.map((i, index) => (
            <TableBodyRow>
              <TD> {i.id} </TD>
              <TD>
                <h4 style={{ fontSize: "15px" }}>{i.date} </h4>
                <span>{i.time} </span>
              </TD>
              <TD> {i.organization} </TD>
              <TD> {i.application} </TD>
              <TD> {i.logtype} </TD>
              <TD> {i.message} </TD>

              <TD style={{ padding: "5px 6px !important " }}>
                <SelectBox1 status={i.status}>
                  <FormControl sx={{ m: 1, minWidth: 115 }}>
                    <Select
                      value={i.status}
                      onChange={handleChange(index)}
                      MenuProps={{ disableScrollLock: true }}
                    >
                      <MenuItem value={"solved"}>Solved</MenuItem>
                      <MenuItem value={"unsolved"}>Unsolved</MenuItem>
                    </Select>
                  </FormControl>
                </SelectBox1>
              </TD>
            </TableBodyRow>
          ))}
        </TBody>
      </Table>
      <PaginationContainer>
        <Pagination count={NumOfpages} onChange={ChangePage} />
      </PaginationContainer>
    </TableContainer>
  );
}

export default ActivityList;

const PaginationContainer = styled.div`
  width: 100%;
  display: flex;
  margin-top: 10px;
  justify-content: center;
`;
const SelectBox1 = styled.div`
  .css-1yk1gt9-MuiInputBase-root-MuiOutlinedInput-root-MuiSelect-root {
    font-size: 12px !important ;

    background-color: ${({ status }) =>
      status === "solved"
        ? " #009a05 "
        : status === "unsolved"
        ? "#9A0000"
        : null};
    color: white;
  }
  .css-hfutr2-MuiSvgIcon-root-MuiSelect-icon {
    color: white !important;
  }
  .css-bpeome-MuiSvgIcon-root-MuiSelect-icon {
    color: white !important;
  }
  .css-1869usk-MuiFormControl-root {
    min-width: 175px !important;
    margin: unset !important;
    @media (min-width: 1920px) {
      width: 250px;
    }
  }
  .MuiOutlinedInput-notchedOutline {
    border: unset;

    border-width: 1px !important ;

    outline: unset !important;
  }

  div div div {
    padding: 6px;
  }

  em {
    font-style: normal !important;
    font-family: unset !important;
  }

  .css-11u53oe-MuiSelect-select-MuiInputBase-input-MuiOutlinedInput-input.css-11u53oe-MuiSelect-select-MuiInputBase-input-MuiOutlinedInput-input.css-11u53oe-MuiSelect-select-MuiInputBase-input-MuiOutlinedInput-input {
    padding-left: 12px !important;
  }
`;
const TableContainer = styled.div`
  margin-top: 15px;
`;
const TD = styled.td`
  padding: 5px 15px;
  text-align: left;
  font-size: 14px;
  padding: 0.5em 1em;
  border-bottom: 1px solid #ababab;
  vertical-align: middle;

  &.cursor {
    cursor: pointer;
  }
`;
const TableBodyRow = styled.tr`
  :hover {
    background-color: rgba(0, 0, 0, 0.04);
  }
`;
const Table = styled.table`
  border-radius: 15px;
  width: 100%;
  background: #fff;
  border-spacing: unset;
`;

const THead = styled.thead`
  box-shadow: 0 0 0 1px #c6c6c6;
  border-radius: 3px;
  background-color: black;
  color: white;
`;
const TableHeadRow = styled.tr``;
const TBody = styled.tbody``;
const TH = styled.th`
  padding: 5px 15px;
  font-weight: normal;
  text-align: left;
  font-size: 14px;
`;
