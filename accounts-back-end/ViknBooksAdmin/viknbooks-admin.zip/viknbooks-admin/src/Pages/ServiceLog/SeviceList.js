import React, { useState } from "react";
import styled from "styled-components/macro";

import { IconButton, Menu, MenuItem } from "@mui/material";

import MoreVertIcon from "@mui/icons-material/MoreVert";
import Pagination from "@mui/material/Pagination";
function ServiceList() {
  const options = ["Edit", "Delete", "View"];
  const [anchorEl, setAnchorEl] = useState(null);
  const open = Boolean(anchorEl);

  const [currentIndex, setCurrentIndex] = useState();
  const handleClick = (index) => (event) => {
    setAnchorEl(event.currentTarget);
    setCurrentIndex(index);
  };
  const handleClose = () => {
    setAnchorEl(null);
  };
  const ITEM_HEIGHT = 48;

  const [partnersList, setPartnersList] = useState({
    data: [
      {
        slno: "1",
        date: "uvais T ",
        title: "admin",
        description: "uvais@gmail.com",
        organization: "Invitation send",
        application: "Invitation send",
        status: "Invitation send",
      },
      {
        slno: "2",
        date: "uvais T ",
        title: "admin",
        description: "uvais@gmail.com",
        organization: "Invitation send",
        application: "Invitation send",
        status: "Invitation send",
      },
      {
        slno: "3",
        date: "uvais T ",
        title: "admin",
        description: "uvais@gmail.com",
        organization: "Invitation send",
        application: "Invitation send",
        status: "Invitation send",
      },
      {
        slno: "4",
        date: "uvais T ",
        title: "admin",
        description: "uvais@gmail.com",
        organization: "Invitation send",
        application: "Invitation send",
        status: "Invitation send",
      },
      {
        slno: "5",
        date: "uvais T ",
        title: "admin",
        description: "uvais@gmail.com",
        organization: "Invitation send",
        application: "Invitation send",
        status: "Invitation send",
      },
      {
        slno: "6",
        date: "uvais T ",
        title: "admin",
        description: "uvais@gmail.com",
        organization: "Invitation send",
        application: "Invitation send",
        status: "Invitation send",
      },
      {
        slno: "7",
        date: "uvais T ",
        title: "admin",
        description: "uvais@gmail.com",
        organization: "Invitation send",
        application: "Invitation send",
        status: "Invitation send",
      },
      {
        slno: "8",
        date: "uvais T ",
        title: "admin",
        description: "uvais@gmail.com",
        organization: "Invitation send",
        application: "Invitation send",
        status: "Invitation send",
      },
      {
        slno: "9",
        date: "uvais T ",
        title: "admin",
        description: "uvais@gmail.com",
        organization: "Invitation send",
        application: "Invitation send",
        status: "Invitation send",
      },
      {
        slno: "10",
        date: "uvais T ",
        title: "admin",
        description: "uvais@gmail.com",
        organization: "Invitation send",
        application: "Invitation send",
        status: "Invitation send",
      },
      {
        slno: "11",
        date: "uvais T ",
        title: "admin",
        description: "uvais@gmail.com",
        organization: "Invitation send",
        application: "Invitation send",
        status: "Invitation send",
      },
      {
        slno: "12",
        date: "uvais T ",
        title: "admin",
        description: "uvais@gmail.com",
        organization: "Invitation send",
        application: "Invitation send",
        status: "Invitation send",
      },
      {
        slno: "13",
        date: "uvais T ",
        title: "admin",
        description: "uvais@gmail.com",
        organization: "Invitation send",
        application: "Invitation send",
        status: "Invitation send",
      },
      {
        slno: "14",
        date: "uvais T ",
        title: "admin",
        description: "uvais@gmail.com",
        organization: "Invitation send",
        application: "Invitation send",
        status: "Invitation send",
      },
      {
        slno: "15",
        date: "uvais T ",
        title: "admin",
        description: "uvais@gmail.com",
        organization: "Invitation send",
        application: "Invitation send",
        status: "Invitation send",
      },
      {
        slno: "16",
        date: "uvais T ",
        title: "admin",
        description: "uvais@gmail.com",
        organization: "Invitation send",
        application: "Invitation send",
        status: "Invitation send",
      },
      {
        slno: "17",
        date: "uvais T ",
        title: "admin",
        description: "uvais@gmail.com",
        organization: "Invitation send",
        application: "Invitation send",
        status: "Invitation send",
      },
      {
        slno: "18",
        date: "uvais T ",
        title: "admin",
        description: "uvais@gmail.com",
        organization: "Invitation send",
        application: "Invitation send",
        status: "Invitation send",
      },
      {
        slno: "19",
        date: "uvais T ",
        title: "admin",
        description: "uvais@gmail.com",
        organization: "Invitation send",
        application: "Invitation send",
        status: "Invitation send",
      },
      {
        slno: "20",
        date: "uvais T ",
        title: "admin",
        description: "uvais@gmail.com",
        organization: "Invitation send",
        application: "Invitation send",
        status: "Invitation send",
      },
      {
        slno: "21",
        date: "uvais T ",
        title: "admin",
        description: "uvais@gmail.com",
        organization: "Invitation send",
        application: "Invitation send",
        status: "Invitation send",
      },
      {
        slno: "22",
        date: "uvais T ",
        title: "admin",
        description: "uvais@gmail.com",
        organization: "Invitation send",
        application: "Invitation send",
        status: "Invitation send",
      },
      {
        slno: "23",
        date: "uvais T ",
        title: "admin",
        description: "uvais@gmail.com",
        organization: "Invitation send",
        application: "Invitation send",
        status: "Invitation send",
      },
      {
        slno: "24",
        date: "uvais T ",
        title: "admin",
        description: "uvais@gmail.com",
        organization: "Invitation send",
        application: "Invitation send",
        status: "Invitation send",
      },
      {
        slno: "325",
        date: "uvais T ",
        title: "admin",
        description: "uvais@gmail.com",
        organization: "Invitation send",
        application: "Invitation send",
        status: "Invitation send",
      },
      {
        slno: "26",
        date: "uvais T ",
        title: "admin",
        description: "uvais@gmail.com",
        organization: "Invitation send",
        application: "Invitation send",
        status: "Invitation send",
      },
      {
        slno: "27",
        date: "uvais T ",
        title: "admin",
        description: "uvais@gmail.com",
        organization: "Invitation send",
        application: "Invitation send",
        status: "Invitation send",
      },
      {
        slno: "28",
        date: "uvais T ",
        title: "admin",
        description: "uvais@gmail.com",
        organization: "Invitation send",
        application: "Invitation send",
        status: "Invitation send",
      },
      {
        slno: "29",
        date: "uvais T ",
        title: "admin",
        description: "uvais@gmail.com",
        organization: "Invitation send",
        application: "Invitation send",
        status: "Invitation send",
      },
      {
        slno: "30",
        date: "uvais T ",
        title: "admin",
        description: "uvais@gmail.com",
        organization: "Invitation send",
        application: "Invitation send",
        status: "Invitation send",
      },
      {
        slno: "31",
        date: "uvais T ",
        title: "admin",
        description: "uvais@gmail.com",
        organization: "Invitation send",
        application: "Invitation send",
        status: "Invitation send",
      },
      {
        slno: "32",
        date: "uvais T ",
        title: "admin",
        description: "uvais@gmail.com",
        organization: "Invitation send",
        application: "Invitation send",
        status: "Invitation send",
      },
      {
        slno: "33",
        date: "uvais T ",
        title: "admin",
        description: "uvais@gmail.com",
        organization: "Invitation send",
        application: "Invitation send",
        status: "Invitation send",
      },
      {
        slno: "34",
        date: "uvais T ",
        title: "admin",
        description: "uvais@gmail.com",
        organization: "Invitation send",
        application: "Invitation send",
        status: "Invitation send",
      },
      {
        slno: "35",
        date: "uvais T ",
        title: "admin",
        description: "uvais@gmail.com",
        organization: "Invitation send",
        application: "Invitation send",
        status: "Invitation send",
      },
      {
        slno: "36",
        date: "uvais T ",
        title: "admin",
        description: "uvais@gmail.com",
        organization: "Invitation send",
        application: "Invitation send",
        status: "Invitation send",
      },
      {
        slno: "37",
        date: "uvais T ",
        title: "admin",
        description: "uvais@gmail.com",
        organization: "Invitation send",
        application: "Invitation send",
        status: "Invitation send",
      },
    ],
  });
  //pagination=======================================

  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage, setItemsPerPage] = useState(18);

  const IndexofLastItem = currentPage * itemsPerPage;
  const indexOfFirstDish = IndexofLastItem - itemsPerPage;
  let PaginatedData = partnersList.data.slice(
    indexOfFirstDish,
    IndexofLastItem
  );
  console.log("page", PaginatedData);

  const ChangePage = (event, value) => {
    setCurrentPage(value);
  };

  const NumOfpages = Math.ceil(partnersList.data.length / itemsPerPage);

  return (
    <TableContainer>
      <Table>
        <THead>
          <TableHeadRow>
            <TH> SI No</TH>
            <TH> Date </TH>
            <TH> Title</TH> <TH> Description </TH>
            <TH> Organization </TH>
            <TH>Application </TH>
            <TH>Status </TH>
            <TH></TH>
          </TableHeadRow>
        </THead>
        <TBody>
          {PaginatedData.map((i, index) => (
            <TableBodyRow>
              <TD> {i.slno} </TD>
              <TD> {i.date} </TD>
              <TD> {i.title} </TD>
              <TD> {i.description} </TD>
              <TD> {i.organization} </TD>
              <TD> {i.application} </TD>
              <TD> {i.status} </TD>

              <TD style={{ textAlign: "right" }}>
                <RightSide>
                  <IconButton
                    aria-label="more"
                    id={index}
                    aria-controls={open ? "long-menu" : undefined}
                    aria-expanded={open ? "true" : undefined}
                    aria-haspopup="true"
                    onClick={handleClick(index)}
                  >
                    <MoreVertIcon />
                  </IconButton>

                  {index === currentIndex ? (
                    <Menus
                      // id="long-menu"
                      MenuListProps={
                        {
                          // "aria-labelledby": ` ${index}`,
                        }
                      }
                      disableScrollLock={true}
                      anchorEl={anchorEl}
                      open={open}
                      onClose={handleClose}
                      PaperProps={{
                        style: {
                          maxHeight: ITEM_HEIGHT * 4.5,
                          width: "20ch",
                        },
                      }}
                    >
                      {options.map((option) => (
                        <MenuItem
                          key={option}
                          selected={option === "Edit"}
                          onClick={handleClose}
                        >
                          {option}
                        </MenuItem>
                      ))}
                    </Menus>
                  ) : null}
                </RightSide>
              </TD>
            </TableBodyRow>
          ))}
        </TBody>
      </Table>
      <PaginationContainer>
        <Pagination count={NumOfpages} onChange={ChangePage} />
      </PaginationContainer>
    </TableContainer>
  );
}

export default ServiceList;
const PaginationContainer = styled.div`
  width: 100%;
  display: flex;
  margin-top: 10px;
  justify-content: center;
`;
const Menus = styled(Menu)`
  && {
    .css-1poimk-MuiPaper-root-MuiMenu-paper-MuiPaper-root-MuiPopover-paper {
      width: 17ch !important;
      left: 1212px !important;
      @media (width: 1309.09px) {
        left: 1083px !important;
      }
      @media (width: 1920px) {
        left: 1687px !important;
      }
      @media (width: 1600px) {
        left: 1371px !important;
      }
      @media (width: 1800px) {
        left: 98rem !important;
      }
      ::-webkit-scrollbar {
        display: none !important;
      }
    }
  }
`;
const RightSide = styled.div`
  height: 100%;
  svg {
    font-size: 1.1rem !important ;
    color: black !important;
  }
  .css-78trlr-MuiButtonBase-root-MuiIconButton-root {
    padding: unset !important;
  }
  .MuiPaper-root {
    box-shadow: none !important;
  }
`;

const TableContainer = styled.div`
  margin-top: 15px;
`;
const TD = styled.td`
  padding: 5px 15px !important;
  text-align: left;

  border-bottom: 1px solid #ababab;
  vertical-align: middle;
  font-size: 12px;
  &.cursor {
    cursor: pointer;
  }
`;
const TableBodyRow = styled.tr`
  cursor: pointer;
  :hover {
    background-color: rgba(0, 0, 0, 0.04);
  }
`;
const Table = styled.table`
  border-radius: 15px;
  width: 100%;
  background: #fff;
  border-spacing: unset;
`;

const THead = styled.thead`
  box-shadow: 0 0 0 1px #c6c6c6;
  border-radius: 3px;
  background-color: black;
  color: white;
`;
const TableHeadRow = styled.tr``;
const TBody = styled.tbody``;
const TH = styled.th`
  padding: 5px 15px;
  font-weight: normal;
  text-align: left;
  font-size: 14px;
`;
