import React from "react";
import CreateButton from "../../Components/CreateButton";
import { useState } from "react";
import styled from "styled-components/macro";
import TextField from "@mui/material/TextField";
import DatePicker from "../../Components/DatePicker";
import {
  Autocomplete,
  Button,
  FormControl,
  MenuItem,
  Select,
} from "@mui/material";
import ServiceList from "./SeviceList";
function Servicelog() {
  const [state, setState] = useState({
    data: ["Uvais", "jasmal", "abhi"],
  });
  const [organTableHead, setOrganTableHead] = useState({
    tableHead: [
      "SI No",
      "Date",
      "Title",
      "Description",
      "Organization",
      "Application",
      "Status",
    ],

    rows: [
      "1",
      "12-04-2022",
      "vikncodes",
      "abcdefghijklmnop",
      "vikncodes",
      "viknbooks",
      "status",
    ],
  });
  const [showSelect, setShowSelect] = useState(false);

  const [threedotMenu, setThreeeDotMenu] = useState(true);
  const handleSelectChange = () => {
    console.log("select");
  };
  const [age, setAge] = useState("");
  const handleChange = (event) => {
    setAge(event.target.value);
  };
  return (
    <Container>
      <Heading>
        <LeftContainer>
          <ServiceTxt>Service Log</ServiceTxt>
        </LeftContainer>

        <BoxContainer>
          <DatePicker />

          <CustomeAutocomplete
            size="small"
            id="combo-box-demo"
            options={state.data}
            // getOptionLabel={(option) => option.username || ""}
            onInputChange={(event, value, reason) => {}}
            onChange={(e, v) => handleSelectChange("ReportUserID", v)}
            renderInput={(params) => (
              <TextField size="small" {...params} placeholder="Organization" />
            )}
          />

          <CustomeAutocomplete
            size="small"
            id="combo-box-demo"
            options={state.data}
            // getOptionLabel={(option) => option.username || ""}
            onInputChange={(event, value, reason) => {}}
            onChange={(e, v) => handleSelectChange("ReportUserID", v)}
            renderInput={(params) => (
              <TextField size="small" {...params} placeholder="Application" />
            )}
          />

          <SelectBox1>
            <FormControl sx={{ m: 1, minWidth: 120 }}>
              <Select
                value={age}
                displayEmpty
                onChange={handleChange}
                MenuProps={{ disableScrollLock: true }}
                inputProps={{ "aria-label": "Without label" }}
              >
                <MenuItems
                  value=""
                  disabled
                  selected
                  style={{ fontsize: "13px" }}
                >
                  Status
                </MenuItems>
                <MenuItems value={10}>Ten</MenuItems>
                <MenuItems value={20}>Twenty</MenuItems>
                <MenuItems value={30}>Thirty</MenuItems>
              </Select>
            </FormControl>
          </SelectBox1>
          <SearchButton>Search</SearchButton>
        </BoxContainer>

        <CreateButtonContainer>
          <CreateButton label={"Add New"} />
        </CreateButtonContainer>
      </Heading>
      <div>
        <ServiceList />
      </div>
    </Container>
  );
}

export default Servicelog;
const MenuItems = styled(MenuItem)`
  font-size: 13px !important;
`;
const Projectname = styled.p`
  /* font-size: 15px;
  cursor: pointer;
  border: 1px solid #d8d8d8;
  border-radius: 2px;
  width: 100%;
  margin-top: 5px;
  .css-78trlr-MuiButtonBase-root-MuiIconButton-root {
    padding: 4px !important ;
  } */
`;
const SearchButton = styled(Button)`
  && {
    background: #009e15;
    color: #fff;
    border-radius: 4px;
    padding: 3px 32px;
    text-transform: capitalize;
    @media (min-width: 1920px) {
      width: 150px;
    }
    &:hover {
      background: #009e15;
    }
  }
`;
const SelectBox1 = styled.div`
  .css-1869usk-MuiFormControl-root {
    min-width: 156px !important;
    margin: unset !important;
  }
  .css-kk1bwy-MuiButtonBase-root-MuiMenuItem-root {
    font-size: 13px !important;
    line-height: 1.4rem !important ;
  }
  @media (min-width: 1920px) {
    width: 250px;
  }

  .MuiOutlinedInput-notchedOutline {
    border-color: #d4d4d4 !important;
    border-width: 1px !important ;
    outline: unset !important;
  }

  div div div {
    padding: 4px;
  }

  em {
    font-style: normal !important;
    font-family: unset !important;
  }
  .css-11u53oe-MuiSelect-select-MuiInputBase-input-MuiOutlinedInput-input.css-11u53oe-MuiSelect-select-MuiInputBase-input-MuiOutlinedInput-input.css-11u53oe-MuiSelect-select-MuiInputBase-input-MuiOutlinedInput-input {
    padding-left: 12px !important;
  }
`;
const BoxContainer = styled.div`
  .css-1auycx3-MuiAutocomplete-root
    .MuiOutlinedInput-root.MuiInputBase-sizeSmall {
    padding: 5px !important;
    width: 156px;
    @media (min-width: 1920px) {
      width: 250px;
    }
  }
  display: flex;
  align-items: center;
  gap: 5px;
  @media (min-width: 1920px) {
    display: flex;
    gap: 15px;
  }
`;

const CustomeAutocomplete = styled(Autocomplete)`
  && {
    /* width: 150px; */
    margin-top: unset !important;
  }
  .css-1d3z3hw-MuiOutlinedInput-notchedOutline {
    outline: unset !important ;
    border-color: #d4d4d4 !important;
    border-width: 1px !important;
  }
  margin-top: 3px;
  button {
    padding: 0;
  }
  .css-19qh8xo-MuiInputBase-input-MuiOutlinedInput-input {
    height: 1rem !important;
  }
`;
const Container = styled.div``;
const Heading = styled.div`
  width: 100%;
  display: flex;
  justify-content: space-between;
`;
const LeftContainer = styled.div`
  display: flex;
  gap: 18px;
  align-items: center;
`;
const ServiceTxt = styled.h2`
  font-size: 27px;
  letter-spacing: 1px; ;
`;
const CreateButtonContainer = styled.div`
  position: relative;
`;
