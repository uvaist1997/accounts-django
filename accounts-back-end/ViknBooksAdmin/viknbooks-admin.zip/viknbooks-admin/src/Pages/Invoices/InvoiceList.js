import { Button } from "@mui/material";
import React, { useState } from "react";
import styled from "styled-components/macro";
import Pagination from "@mui/material/Pagination";
function InvoiceList() {
  const [Invoicedata, setInvoicedata] = useState({
    data: [
      {
        slno: "1",
        invoiceno: "12233",
        organization: "vikncodes",
        user: "jasmal",
        gross: "qweerrt",
        discount: "10",
        total: "123444",
        status: "Added",
      },
      {
        slno: "2",
        invoiceno: "1433",
        organization: "vikncodes",
        user: "jasmal",
        gross: "qweerrt",
        discount: "20",
        total: "1656444",
        status: "Added",
      },
      {
        slno: "3",
        invoiceno: "5233",
        organization: "vikncodes",
        user: "abhi",
        gross: "qweerrt",
        discount: "50",
        total: "12844",
        status: "Not Added",
      },
      {
        slno: "3",
        invoiceno: "5233",
        organization: "vikncodes",
        user: "abhi",
        gross: "qweerrt",
        discount: "50",
        total: "12844",
        status: "Not Added",
      },
      {
        slno: "4",
        invoiceno: "5233",
        organization: "vikncodes",
        user: "abhi",
        gross: "qweerrt",
        discount: "50",
        total: "12844",
        status: "Not Added",
      },
      {
        slno: "5",
        invoiceno: "5233",
        organization: "vikncodes",
        user: "abhi",
        gross: "qweerrt",
        discount: "50",
        total: "12844",
        status: "Not Added",
      },
      {
        slno: "6",
        invoiceno: "5233",
        organization: "vikncodes",
        user: "abhi",
        gross: "qweerrt",
        discount: "50",
        total: "12844",
        status: "Not Added",
      },
      {
        slno: "7",
        invoiceno: "5233",
        organization: "vikncodes",
        user: "abhi",
        gross: "qweerrt",
        discount: "50",
        total: "12844",
        status: "Not Added",
      },
      {
        slno: "8",
        invoiceno: "5233",
        organization: "vikncodes",
        user: "abhi",
        gross: "qweerrt",
        discount: "50",
        total: "12844",
        status: "Not Added",
      },
      {
        slno: "9",
        invoiceno: "5233",
        organization: "vikncodes",
        user: "abhi",
        gross: "qweerrt",
        discount: "50",
        total: "12844",
        status: "Not Added",
      },
      {
        slno: "10",
        invoiceno: "5233",
        organization: "vikncodes",
        user: "abhi",
        gross: "qweerrt",
        discount: "50",
        total: "12844",
        status: "Not Added",
      },
      {
        slno: "11",
        invoiceno: "5233",
        organization: "vikncodes",
        user: "abhi",
        gross: "qweerrt",
        discount: "50",
        total: "12844",
        status: "Not Added",
      },
      {
        slno: "12",
        invoiceno: "5233",
        organization: "vikncodes",
        user: "abhi",
        gross: "qweerrt",
        discount: "50",
        total: "12844",
        status: "Not Added",
      },
      {
        slno: "13",
        invoiceno: "5233",
        organization: "vikncodes",
        user: "abhi",
        gross: "qweerrt",
        discount: "50",
        total: "12844",
        status: "Not Added",
      },
      {
        slno: "14",
        invoiceno: "5233",
        organization: "vikncodes",
        user: "abhi",
        gross: "qweerrt",
        discount: "50",
        total: "12844",
        status: "Not Added",
      },
      {
        slno: "15",
        invoiceno: "5233",
        organization: "vikncodes",
        user: "abhi",
        gross: "qweerrt",
        discount: "50",
        total: "12844",
        status: "Not Added",
      },
      {
        slno: "16",
        invoiceno: "5233",
        organization: "vikncodes",
        user: "abhi",
        gross: "qweerrt",
        discount: "50",
        total: "12844",
        status: "Not Added",
      },
      {
        slno: "17",
        invoiceno: "5233",
        organization: "vikncodes",
        user: "abhi",
        gross: "qweerrt",
        discount: "50",
        total: "12844",
        status: "Not Added",
      },
      {
        slno: "18",
        invoiceno: "5233",
        organization: "vikncodes",
        user: "abhi",
        gross: "qweerrt",
        discount: "50",
        total: "12844",
        status: "Not Added",
      },
      {
        slno: "19",
        invoiceno: "5233",
        organization: "vikncodes",
        user: "abhi",
        gross: "qweerrt",
        discount: "50",
        total: "12844",
        status: "Not Added",
      },
      {
        slno: "20",
        invoiceno: "5233",
        organization: "vikncodes",
        user: "abhi",
        gross: "qweerrt",
        discount: "50",
        total: "12844",
        status: "Not Added",
      },
      {
        slno: "21",
        invoiceno: "5233",
        organization: "vikncodes",
        user: "abhi",
        gross: "qweerrt",
        discount: "50",
        total: "12844",
        status: "Not Added",
      },
      {
        slno: "22",
        invoiceno: "5233",
        organization: "vikncodes",
        user: "abhi",
        gross: "qweerrt",
        discount: "50",
        total: "12844",
        status: "Not Added",
      },
      {
        slno: "23",
        invoiceno: "5233",
        organization: "vikncodes",
        user: "abhi",
        gross: "qweerrt",
        discount: "50",
        total: "12844",
        status: "Not Added",
      },
      {
        slno: "24",
        invoiceno: "5233",
        organization: "vikncodes",
        user: "abhi",
        gross: "qweerrt",
        discount: "50",
        total: "12844",
        status: "Not Added",
      },
      {
        slno: "25",
        invoiceno: "5233",
        organization: "vikncodes",
        user: "abhi",
        gross: "qweerrt",
        discount: "50",
        total: "12844",
        status: "Not Added",
      },
      {
        slno: "26",
        invoiceno: "5233",
        organization: "vikncodes",
        user: "abhi",
        gross: "qweerrt",
        discount: "50",
        total: "12844",
        status: "Not Added",
      },
      {
        slno: "27",
        invoiceno: "5233",
        organization: "vikncodes",
        user: "abhi",
        gross: "qweerrt",
        discount: "50",
        total: "12844",
        status: "Not Added",
      },
      {
        slno: "28",
        invoiceno: "5233",
        organization: "vikncodes",
        user: "abhi",
        gross: "qweerrt",
        discount: "50",
        total: "12844",
        status: "Not Added",
      },
      {
        slno: "29",
        invoiceno: "5233",
        organization: "vikncodes",
        user: "abhi",
        gross: "qweerrt",
        discount: "50",
        total: "12844",
        status: "Not Added",
      },
      {
        slno: "30",
        invoiceno: "5233",
        organization: "vikncodes",
        user: "abhi",
        gross: "qweerrt",
        discount: "50",
        total: "12844",
        status: "Not Added",
      },
      {
        slno: "31",
        invoiceno: "5233",
        organization: "vikncodes",
        user: "abhi",
        gross: "qweerrt",
        discount: "50",
        total: "12844",
        status: "Not Added",
      },
      {
        slno: "32",
        invoiceno: "5233",
        organization: "vikncodes",
        user: "abhi",
        gross: "qweerrt",
        discount: "50",
        total: "12844",
        status: "Not Added",
      },
      {
        slno: "33",
        invoiceno: "5233",
        organization: "vikncodes",
        user: "abhi",
        gross: "qweerrt",
        discount: "50",
        total: "12844",
        status: "Not Added",
      },
      {
        slno: "34",
        invoiceno: "5233",
        organization: "vikncodes",
        user: "abhi",
        gross: "qweerrt",
        discount: "50",
        total: "12844",
        status: "Not Added",
      },
      {
        slno: "35",
        invoiceno: "5233",
        organization: "vikncodes",
        user: "abhi",
        gross: "qweerrt",
        discount: "50",
        total: "12844",
        status: "Not Added",
      },
    ],
  });
  //pagination=======================================

  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage, setItemsPerPage] = useState(19);

  const IndexofLastItem = currentPage * itemsPerPage;
  const indexOfFirstDish = IndexofLastItem - itemsPerPage;
  let PaginatedData = Invoicedata.data.slice(indexOfFirstDish, IndexofLastItem);
  console.log("page", PaginatedData);

  const ChangePage = (event, value) => {
    setCurrentPage(value);
  };

  const NumOfpages = Math.ceil(Invoicedata.data.length / itemsPerPage);

  return (
    <TableContainer>
      <Table>
        <THead>
          <TableHeadRow>
            <TH> SI No </TH>
            <TH> Invoice No </TH>
            <TH> Organization </TH>
            <TH> User </TH>
            <TH> Gross </TH>
            <TH> Discount </TH>
            <TH> Total </TH>
            <TH> Status </TH>
          </TableHeadRow>
        </THead>
        <TBody>
          {PaginatedData.map((i) => (
            <TableBodyRow>
              <TD> {i.slno} </TD>
              <TD> {i.invoiceno} </TD>
              <TD> {i.organization} </TD>
              <TD> {i.user} </TD>
              <TD> {i.gross} </TD>
              <TD> {i.discount} </TD>

              <TD> {i.total} </TD>
              <TD>
                <StatusText status={i.status}>{i.status} </StatusText>
              </TD>
            </TableBodyRow>
          ))}
        </TBody>
      </Table>
      <PaginationContainer>
        <Pagination count={NumOfpages} onChange={ChangePage} />
      </PaginationContainer>
    </TableContainer>
  );
}

export default InvoiceList;
const PaginationContainer = styled.div`
  width: 100%;
  display: flex;
  margin-top: 10px;
  justify-content: center;
`;
const StatusText = styled(Button)`
  &&,
  &&:hover {
    margin-bottom: 1px;
    text-transform: capitalize;
    color: #013d23;

    background-color: ${({ status }) =>
      status === "Added" ? "#00600C" : "#6D0202"};
    border-radius: 0;

    height: 22px;
    font-size: 10px !important;
    width: 100px;
    margin-left: auto;
    border-radius: 2px;
    font-family: "Poppins";
    color: white !important;
  }

  .MuiButton-root:hover {
    background-color: unset !important;
  }
`;

const TableContainer = styled.div`
  margin-top: 15px;
`;
const TD = styled.td`
  padding: 5px 15px !important;
  text-align: left;
  font-size: 12px;
  padding: 0.5em 1em;
  border-bottom: 1px solid #ababab;
  vertical-align: middle;

  &.cursor {
    cursor: pointer;
  }
`;
const TableBodyRow = styled.tr`
  :hover {
    background-color: rgba(0, 0, 0, 0.04);
  }
`;
const Table = styled.table`
  border-radius: 15px;
  width: 100%;
  background: #fff;
  border-spacing: unset;
`;

const THead = styled.thead`
  box-shadow: 0 0 0 1px #c6c6c6;
  border-radius: 3px;
  background-color: black;
  color: white;
`;
const TableHeadRow = styled.tr``;
const TBody = styled.tbody``;
const TH = styled.th`
  padding: 5px 15px;
  font-weight: normal;
  text-align: left;
  font-size: 14px;
`;
