import React, { useState } from "react";
import LineChart from "../../Components/LineChart";
import styled from "styled-components/macro";
import MenuItem from "@mui/material/MenuItem";
import FormControl from "@mui/material/FormControl";
import Select from "@mui/material/Select";

import CardContent from "@mui/material/CardContent";
import CardMedia from "@mui/material/CardMedia";
import Typography from "@mui/material/Typography";
import { CardActionArea } from "@mui/material";
import { PaymentChart } from "../../Components/PaymentChart";

function DashBoard() {
  //selcect box................
  const [age, setAge] = React.useState("");
  const handleChange = (event) => {
    setAge(event.target.value);
  };

  //cards................

  const [card, setCard] = useState([
    {
      name: "Lite",
      number: 12,
      color: ["#E6D009", "#E9B300"],
    },
    {
      name: "Essential",
      number: 13,
      color: ["#FF9C07", "#FC7B38"],
    },
    {
      name: "Standard",
      number: 23,
      color: ["#44B1E2", "#0860E4"],
    },
    {
      name: "Professional",
      number: "10",
      color: ["#07D459", "#049E7F"],
    },
  ]);
  return (
    <Container>
      <Heading>
        <DashboardText>Dashboard</DashboardText>

        <SelectBox1>
          <FormControl sx={{ m: 1, minWidth: 120 }}>
            <Select
              value={age}
              onChange={handleChange}
              displayEmpty
              MenuProps={{
                disableScrollLock: true,
              }}
              inputProps={{ "aria-label": "Without label" }}
            >
              <MenuItems
                value=""
                disabled
                selected
                hidden
                style={{ fontsize: "13px" }}
              >
                ViknERP
              </MenuItems>
              <MenuItems value={10}>Ten</MenuItems>
              <MenuItems value={20}>Twenty</MenuItems>
              <MenuItems value={30}>Thirty</MenuItems>
            </Select>
          </FormControl>
        </SelectBox1>
      </Heading>

      <GraphHeader>Users</GraphHeader>
      <TopContainer>
        <GraphContainer>
          <LineChart />
        </GraphContainer>

        <TopRight>
          <NewUserText>New Users</NewUserText>

          <CardContainer>
            {card.map((i) => {
              return (
                <Card sx={{ maxWidth: 345 }} color={i.color}>
                  <CardActionArea>
                    <CardMedia />
                    <CardContent>
                      <Typography
                        variant="body2"
                        color="dark"
                        style={{
                          fontSize: "18px",
                          fontWeight: "bold",
                          paddingLeft: "10px",
                        }}
                      >
                        {i.name}
                      </Typography>
                      <Typography
                        variant="h5"
                        component="div"
                        textAlign="right"
                        style={{
                          fontWeight: "bold",
                          fontSize: "45px",
                          paddingRight: "10px",
                        }}
                      >
                        {i.number}
                      </Typography>
                    </CardContent>
                  </CardActionArea>
                </Card>
              );
            })}
          </CardContainer>
        </TopRight>
      </TopContainer>

      <PaymentChart />
    </Container>
  );
}

export default DashBoard;

const Card = styled.div`
  border: 1px solid #c9c9c9;
  .css-46bh2p-MuiCardContent-root {
    padding: unset;
  }
  button {
    border-left: 8px solid transparent;
    border-image: ${({ color }) =>
      color ? ` linear-gradient(180deg,${color})1` : ""};

    /* border-left: 5px solid;
    border-image: linear-gradient(180deg, #e6d009, #e9b300) 1; */
  }
  padding: 5px;
`;
const CardContainer = styled.div`
  margin-top: 10px;
  display: grid;
  grid-template-columns: auto auto;
  grid-row-gap: 10px;
  grid-column-gap: 10px;
`;
const TopRight = styled.div`
  width: 50%;
  padding-left: 30px; ;
`;
const TopContainer = styled.div`
  display: flex;
`;
const GraphContainer = styled.div`
  height: 318px;
  width: 50%;
  margin-top: 10px; ;
`;
const GraphHeader = styled.h4`
  font-size: 18px;
  margin-top: 18px;
`;
const NewUserText = styled.h4`
  font-size: 18px;
`;
const Container = styled.div``;
const Heading = styled.div`
  width: 100%;
  display: flex;
  justify-content: space-between;
`;
const DashboardText = styled.h2`
  font-size: 25px;
  letter-spacing: 1px; ;
`;
const MenuItems = styled(MenuItem)`
  font-size: 13px !important;
`;
const SelectBox1 = styled.div`
  .css-1yk1gt9-MuiInputBase-root-MuiOutlinedInput-root-MuiSelect-root {
    font-size: 13px;
  }
  .css-kk1bwy-MuiButtonBase-root-MuiMenuItem-root {
    font-size: 13px !important;
    line-height: 1.4rem !important ;
  }
  .css-1869usk-MuiFormControl-root {
    min-width: 165px !important;
    margin: 0px 8px !important;
    background-color: #e2e2e2;
  }
  .MuiOutlinedInput-notchedOutline {
    border: unset !important;

    outline: unset !important;
  }
  .css-11u53oe-MuiSelect-select-MuiInputBase-input-MuiOutlinedInput-input.css-11u53oe-MuiSelect-select-MuiInputBase-input-MuiOutlinedInput-input.css-11u53oe-MuiSelect-select-MuiInputBase-input-MuiOutlinedInput-input {
    padding-left: 20px;
  }

  div div div {
    padding: 6px 10px;
  }
`;
