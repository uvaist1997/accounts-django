import { Button, IconButton, Menu, MenuItem, TextField } from "@mui/material";
import MoreVertIcon from "@mui/icons-material/MoreVert";
import React, { useState } from "react";
import styled from "styled-components/macro";
import CreateButton from "../../../Components/CreateButton";
import ApplicationCard from "./ApplicationCard";
import { useNavigate } from "react-router-dom";

function Application() {
  const navigate = useNavigate();
  const [card, setCard] = useState([
    "viknbooks",
    "rassasy",
    "viknbooks",
    "rassasy",
    "viknbooks",
    "rassasy",
    "viknbooks",
    "rassasy",
    "viknbooks",
    "rassasy",
  ]);
  const options = ["Phobos", "Pyxis", "Sedna", "Titania", "Triton", "Umbriel"];

  const [anchorEl, setAnchorEl] = useState(null);
  const open = Boolean(anchorEl);
  const [currentIndex, setCurrentIndex] = useState();
  const handleClick = (index) => (event) => {
    setAnchorEl(event.currentTarget);
    setCurrentIndex(index);
  };
  const handleClose = () => {
    setAnchorEl(null);
  };
  const ITEM_HEIGHT = 48;
  const showAddApplication = () => {
    navigate("/addapplication");
  };

  return (
    <Container>
      <Heading>
        <LeftContainer>
          <ApplicationTxt>Applications</ApplicationTxt>
          <SubContainer>
            <Field1>
              <EditContainer>
                <CustomTextField
                  id="outlined-basic"
                  variant="outlined"
                  placeholder="Search..."
                />
              </EditContainer>
            </Field1>
          </SubContainer>
        </LeftContainer>
        <CreateButtonContainer onClick={() => showAddApplication()}>
          <CreateButton label={"Add New"} />
        </CreateButtonContainer>
      </Heading>

      <CardContainer>
        {card.map((i, index) => {
          return i === "viknbooks" ? (
            <Card>
              {/* <CardBody> */}
              <LeftSide>
                <LogoContainer>
                  <Logo src="../../Images/Icons/Rassasy.svg" />
                </LogoContainer>

                <AppTxtContainer>
                  <AppText>Viknbooks</AppText>
                  <VersionTxtContainer>
                    <VersionTxt>version</VersionTxt>
                    <VersionTxt>23.56.77</VersionTxt>
                  </VersionTxtContainer>
                  <Button_LogoContainer>
                    <AddonButton>
                      <Button variant="text" color="success">
                        Add on
                      </Button>
                    </AddonButton>
                    <SmallIcon>
                      <Logo src="../../Images/Icons//viknbookSmall.svg" />
                    </SmallIcon>
                  </Button_LogoContainer>
                </AppTxtContainer>
              </LeftSide>
              <RightSide>
                <IconButton
                  aria-label="more"
                  id={index}
                  aria-controls={open ? "long-menu" : undefined}
                  aria-expanded={open ? "true" : undefined}
                  aria-haspopup="true"
                  onClick={handleClick(index)}
                >
                  <MoreVertIcon />
                </IconButton>
                {currentIndex === index ? (
                  <Menus
                    disableScrollLock={true}
                    id=""
                    MenuListProps={{
                      "aria-labelledby": "long-buttonasdfasd",
                    }}
                    anchorEl={anchorEl}
                    onOpen={Boolean(anchorEl)}
                    open={open}
                    onClose={handleClose}
                    PaperProps={{
                      style: {
                        maxHeight: ITEM_HEIGHT * 4.5,
                        width: "20ch",
                      },
                    }}
                  >
                    {options.map((option) => (
                      <MenuItem
                        key={option}
                        selected={option === "Pyxis"}
                        onClick={handleClose}
                      >
                        {option}
                      </MenuItem>
                    ))}
                  </Menus>
                ) : null}
              </RightSide>
            </Card>
          ) : (
            <ApplicationCard index={index} />
          );
        })}
      </CardContainer>
    </Container>
  );
}

export default Application;
const CustomTextField = styled(TextField)`
  && {
    /* min-width: 150px; */
  }
  border: unset !important;
  outline: unset !important;
  &.css-1u3bzj6-MuiFormControl-root-MuiTextField-root {
    border-radius: 2px;
  }
  .css-1t8l2tu-MuiInputBase-input-MuiOutlinedInput-input {
    padding: 6.5px 30px 6.5px 14px !important;
    font-size: 13px !important;
  }
  .css-1d3z3hw-MuiOutlinedInput-notchedOutline {
    border-color: #d4d4d4 !important;
    border-width: 1px !important;
  }
`;
const EditContainer = styled.div`
  display: flex;

  align-items: center;
`;
const Field1 = styled.div``;
const SubContainer = styled.div``;
const LeftContainer = styled.div`
  display: flex;
  gap: 25px;
  align-items: center;
`;
const SmallIcon = styled.div`
  display: flex;
  align-items: center;
`;
const Button_LogoContainer = styled.div`
  display: flex;
  gap: 5px;
`;
const RightSide = styled.div`
  height: 100%;
  svg {
    font-size: 1.4rem !important ;
    color: black !important;
  }
  .css-78trlr-MuiButtonBase-root-MuiIconButton-root {
    padding: unset !important;
  }
  .MuiPaper-root {
    box-shadow: none !important;
  }
`;
const Menus = styled(Menu)`
  .css-1poimk-MuiPaper-root-MuiMenu-paper-MuiPaper-root-MuiPopover-paper {
    ::-webkit-scrollbar {
      display: none;
    }
  }
`;
const CustomButton = styled.div`
  display: flex;
  width: 100%;

  .css-1lg55su-MuiButtonBase-root-MuiButton-root {
    background: #ced4ce;
    font-size: 10px !important;
    color: green;
    border: unset !important;
    border-radius: unset;
    font-family: "Poppins" sans-serif !important;
    text-transform: unset !important ;
    padding: 1px !important;
  }
  .css-1lg55su-MuiButtonBase-root-MuiButton-root:hover {
    background-color: #ced4ce;
  }
  .css-1e6y48t-MuiButtonBase-root-MuiButton-root:hover {
    /* background-color: #ced4ce !important; */
    color: white;
  }
`;

const AddonButton = styled(CustomButton)`
  .css-1lg55su-MuiButtonBase-root-MuiButton-root {
    background: #e1d4bf;
    color: #784c0a;
  }
  .css-1lg55su-MuiButtonBase-root-MuiButton-root:hover {
    background: #e1d4bf;
  }
`;
const VersionTxtContainer = styled.div`
  display: flex;
  gap: 5px;
`;
const VersionTxt = styled.span`
  color: #004d8f;
  font-size: 10px;
`;
const AppText = styled.h3`
  font-size: 15px;
  font-weight: bold;
`;
const AppTxtContainer = styled.div`
  display: flex;
  flex-direction: column;
`;
const Logo = styled.img`
  width: 100%;
  height: 100%;
  object-fit: contain;
`;
const LogoContainer = styled.div`
  display: flex;
  align-items: center;
  border-radius: 1px;
  background-color: white;
  padding: 10px;
  width: 59px;
  height: 59px; ;
`;
const LeftSide = styled.div`
  display: flex;
  gap: 10px;
`;
// const CardBody = styled.div`
//   display: flex;
//   justify-content: space-between;
//   background-color: #eeeeee;
// `;
const Card = styled.div`
  padding: 10px;

  display: flex;
  cursor: pointer;
  align-items: center;

  justify-content: space-between;
  background-color: #eeeeee;
`;

const CardContainer = styled.div`
  margin-top: 25px;
  display: grid;
  grid-template-columns: auto auto auto auto;
  grid-row-gap: 10px;
  grid-column-gap: 10px;
`;
const Container = styled.div``;
const Heading = styled.div`
  width: 100%;
  display: flex;
  justify-content: space-between;
`;
const ApplicationTxt = styled.h2`
  font-size: 25px;
  letter-spacing: 1px; ;
`;
const CreateButtonContainer = styled.div`
  position: relative;
`;
