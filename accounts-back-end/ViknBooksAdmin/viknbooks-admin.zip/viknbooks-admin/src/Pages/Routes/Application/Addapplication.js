import React, { useState } from "react";
import SaveButton from "../../../Components/SaveButton";
import styled from "styled-components/macro";
import { SnackbarProvider } from "notistack";
import ImageUpload from "../../../Components/ImageUplaod";
import { Fab, IconButton, TextField } from "@mui/material";
import EditIcon from "@mui/icons-material/Edit";
import DeleteIcon from "@mui/icons-material/Delete";
import {
  Autocomplete,
  FormControl,
  MenuItem,
  Select,
  TextareaAutosize,
} from "@mui/material";
import Box from "@mui/material/Box";
import Modal from "@mui/material/Modal";
import Button from "@mui/material/Button";
import AddIcon from "@mui/icons-material/Add";
import Typography from "@mui/material/Typography";
import { useSnackbar } from "notistack";
function Addapplication() {
  //modal===========================

  const style = {
    position: "absolute",
    top: "50%",
    left: "50%",
    transform: "translate(-50%, -50%)",
    width: 700,
    bgcolor: "background.paper",

    boxShadow: 24,
    p: 2,
  };
  const [open, setOpen] = React.useState(false);
  const handleOpen = () => setOpen(true);
  const handleClose = () => setOpen(false);

  //modal===========================

  const [appType, setAppType] = useState("addon");

  const handleChange = (event) => {
    setAppType(event.target.value);
  };
  const handleSelectChange = () => {
    console.log("select");
  };
  const [state, setState] = useState({
    data: ["uvais", "jasmal", "abhi"],
    serviceData: [
      {
        upgrade: "",
        downgrade: "",
        users: "",
        services: "",
        validity: "",
      },
    ],
  });
  const { enqueueSnackbar } = useSnackbar();
  const handleClickVariant = (variant) => () => {
    // variant could be success, error, warning, info, or default
    enqueueSnackbar(" Saved Successfully !", { variant });
  };

  return (
    <Container>
      <Heading>
        <AddApplicationTxt>Add Applications</AddApplicationTxt>
        <SnackbarProvider maxSnack={3}>
          <SaveButtonContainer onClick={handleClickVariant("success")}>
            <SaveButton label={"Save"} />
          </SaveButtonContainer>
        </SnackbarProvider>
      </Heading>
      <BodyContainer>
        <TopContainer>
          <TextContainer>
            <Label for="question">Application Name</Label>

            <CustomTextField id="outlined-basic" variant="outlined" />
          </TextContainer>

          <TextContainer>
            <Label>Application Type</Label>
            <SelectBox1>
              <FormControl sx={{ m: 1, minWidth: 120 }}>
                <Select
                  value={appType}
                  onChange={handleChange}
                  displayEmpty
                  defaultValue="Status"
                  MenuProps={{ disableScrollLock: true }}
                >
                  <MenuItem value=""></MenuItem>
                  <MenuItem value={"core"}>Core</MenuItem>
                  <MenuItem value={"addon"}>Add on</MenuItem>
                </Select>
              </FormControl>
            </SelectBox1>
          </TextContainer>
          <AddonContainer>
            {appType === "addon" ? (
              <TextContainer>
                <Label>Parent Application</Label>
                <CustomeAutocomplete
                  size="small"
                  id="combo-box-demo"
                  options={state.data}
                  // getOptionLabel={(option) => option.username || ""}
                  onInputChange={(event, value, reason) => {}}
                  onChange={(e, v) => handleSelectChange("ReportUserID", v)}
                  renderInput={(params) => (
                    <TextField size="small" {...params} />
                  )}
                />
              </TextContainer>
            ) : (
              ""
            )}

            <TextContainer>
              <Label for="question">Current Version</Label>

              <CustomTextField id="outlined-basic" variant="outlined" />
            </TextContainer>
          </AddonContainer>
          <ImageContanier>
            <Label for="question">Application Logo</Label>

            <ImageUpload />
          </ImageContanier>
        </TopContainer>

        <BottomContainer>
          <EditionTxt>Editions</EditionTxt>
          <Top>
            <HeaderContainer>
              <RightHeader>
                <TableContainer>
                  <Table>
                    <TableHeadRow>
                      <TH> Edit Name </TH>
                      <TH> Price </TH>
                      <TH> Users/Devices</TH>
                      <TH> Add On's </TH>
                      <TH rowSpan="2" style={{ padding: "3px 0px" }}>
                        <IconButton>
                          <EditButton onClick={handleOpen} />
                        </IconButton>
                        &nbsp; &nbsp;
                        <IconButton>
                          <DeleteButton />
                        </IconButton>
                      </TH>
                    </TableHeadRow>

                    <TableBodyRow>
                      <TD styled={{ color: "#054158" }}> Edit Name </TD>
                      <TD style={{ color: "#04925D" }}> Price</TD>
                      <TD style={{ color: "#888888" }}> 0 </TD>
                      <TD style={{ color: "#888888" }}> 0 </TD>
                    </TableBodyRow>
                  </Table>
                </TableContainer>
              </RightHeader>

              <RightHeader>
                <TableContainer>
                  <Table>
                    <TableHeadRow>
                      <TH> Edit Name </TH>
                      <TH> Price </TH>
                      <TH> Users/Devices</TH>
                      <TH> Add On's </TH>
                      <TH rowSpan="2" style={{ padding: "3px 0px" }}>
                        <IconButton>
                          <EditButton onClick={handleOpen} />
                        </IconButton>
                        &nbsp; &nbsp;
                        <IconButton>
                          <DeleteButton />
                        </IconButton>
                      </TH>
                    </TableHeadRow>

                    <TableBodyRow>
                      <TD styled={{ color: "#054158" }}> Edit Name </TD>
                      <TD style={{ color: "#04925D" }}> Price</TD>
                      <TD style={{ color: "#888888" }}> 0 </TD>
                      <TD style={{ color: "#888888" }}> 0 </TD>
                    </TableBodyRow>
                  </Table>
                </TableContainer>
              </RightHeader>
            </HeaderContainer>
            <PlusBtn onClick={handleOpen}>
              <Box sx={{ "& > :not(style)": { m: 1 } }}>
                <Fab size="small" aria-label="add">
                  <AddIcon />
                </Fab>
              </Box>
            </PlusBtn>
          </Top>
        </BottomContainer>
      </BodyContainer>

      <ModalContainer>
        <Modal
          keepMounted
          open={open}
          onClose={handleClose}
          aria-labelledby="keep-mounted-modal-title"
          aria-describedby="keep-mounted-modal-description"
        >
          <Box sx={style}>
            <HaaderModal>
              <Typography
                id="keep-mounted-modal-title"
                variant="h6"
                component="h2"
                sx={{ fontFamily: "Poppins" }}
              >
                Edition Details
              </Typography>
              <Typography
                id="keep-mounted-modal-title"
                variant="h6"
                component="h2"
                sx={{ fontFamily: "Poppins" }}
                onClick={() => setOpen(false)}
              >
                <SaveButton />
              </Typography>
            </HaaderModal>
            <Typography
              id="keep-mounted-modal-description"
              sx={{ fontFamily: "Poppins" }}
            >
              <ThreeBoxContainer>
                <TextContainer>
                  <Label for="question">Edit Name</Label>

                  <CustomTextField id="outlined-basic" variant="outlined" />
                </TextContainer>
                <TextContainer>
                  <Label for="question">Price</Label>

                  <CustomTextField id="outlined-basic" variant="outlined" />
                </TextContainer>
                <TextContainer>
                  <Label for="question">No of Users/devices</Label>

                  <CustomTextField id="outlined-basic" variant="outlined" />
                </TextContainer>
              </ThreeBoxContainer>
            </Typography>
            <BottomHeader>
              <Typography
                id="keep-mounted-modal-title"
                variant="h6"
                component="h2"
                sx={{ fontFamily: "Poppins" }}
              >
                Add ons
              </Typography>

              <CustomeAutocomplete2
                size="small"
                id="combo-box-demo"
                options={state.data}
                onInputChange={(event, value, reason) => {}}
                onChange={(e, v) => handleSelectChange("ReportUserID", v)}
                renderInput={(params) => (
                  <TextField size="small" {...params} placeholder="+ AddOn" />
                )}
              />
            </BottomHeader>

            <CardScroll>
              <RassayButton>
                <SmallCard>
                  <Card1>
                    <Rassasy2>
                      <RassasyContainer>
                        <ImgLogo src="../../Images/Icons/Rassasy.svg" />
                      </RassasyContainer>
                      <h4 style={{ fontSize: "15px" }}>Rassasy</h4>
                    </Rassasy2>
                    <IconButton>
                      <DeleteButton />
                    </IconButton>
                  </Card1>
                </SmallCard>
              </RassayButton>{" "}
              <RassayButton>
                <SmallCard>
                  <Card1>
                    <Rassasy2>
                      <RassasyContainer>
                        <ImgLogo src="../../Images/Icons/Rassasy.svg" />
                      </RassasyContainer>
                      <h4 style={{ fontSize: "15px" }}>Rassasy</h4>
                    </Rassasy2>
                    <IconButton>
                      <DeleteButton />
                    </IconButton>
                  </Card1>
                </SmallCard>
              </RassayButton>{" "}
              <RassayButton>
                <SmallCard>
                  <Card1>
                    <Rassasy2>
                      <RassasyContainer>
                        <ImgLogo src="../../Images/Icons/Rassasy.svg" />
                      </RassasyContainer>
                      <h4 style={{ fontSize: "15px" }}>Rassasy</h4>
                    </Rassasy2>
                    <IconButton>
                      <DeleteButton />
                    </IconButton>
                  </Card1>
                </SmallCard>
              </RassayButton>{" "}
              <RassayButton>
                <SmallCard>
                  <Card1>
                    <Rassasy2>
                      <RassasyContainer>
                        <ImgLogo src="../../Images/Icons/Rassasy.svg" />
                      </RassasyContainer>
                      <h4 style={{ fontSize: "15px" }}>Rassasy</h4>
                    </Rassasy2>
                    <IconButton>
                      <DeleteButton />
                    </IconButton>
                  </Card1>
                </SmallCard>
              </RassayButton>{" "}
              <RassayButton>
                <SmallCard>
                  <Card1>
                    <Rassasy2>
                      <RassasyContainer>
                        <ImgLogo src="../../Images/Icons/Rassasy.svg" />
                      </RassasyContainer>
                      <h4 style={{ fontSize: "15px" }}>Rassasy</h4>
                    </Rassasy2>
                    <IconButton>
                      <DeleteButton />
                    </IconButton>
                  </Card1>
                </SmallCard>
              </RassayButton>{" "}
              <RassayButton>
                <SmallCard>
                  <Card1>
                    <Rassasy2>
                      <RassasyContainer>
                        <ImgLogo src="../../Images/Icons/Rassasy.svg" />
                      </RassasyContainer>
                      <h4 style={{ fontSize: "15px" }}>Rassasy</h4>
                    </Rassasy2>
                    <IconButton>
                      <DeleteButton />
                    </IconButton>
                  </Card1>
                </SmallCard>
              </RassayButton>{" "}
              <RassayButton>
                <SmallCard>
                  <Card1>
                    <Rassasy2>
                      <RassasyContainer>
                        <ImgLogo src="../../Images/Icons/Rassasy.svg" />
                      </RassasyContainer>
                      <h4 style={{ fontSize: "15px" }}>Rassasy</h4>
                    </Rassasy2>
                    <IconButton>
                      <DeleteButton />
                    </IconButton>
                  </Card1>
                </SmallCard>
              </RassayButton>
              <RassayButton>
                <SmallCard>
                  <Card1>
                    <Rassasy2>
                      <RassasyContainer>
                        <ImgLogo src="../../Images/Icons/Rassasy.svg" />
                      </RassasyContainer>
                      <h4 style={{ fontSize: "15px" }}>Rassasy</h4>
                    </Rassasy2>
                    <IconButton>
                      <DeleteButton />
                    </IconButton>
                  </Card1>
                </SmallCard>
              </RassayButton>
            </CardScroll>
          </Box>
        </Modal>
      </ModalContainer>
    </Container>
  );
}

export default function IntegrationNotistack() {
  return (
    <SnackbarProvider maxSnack={3}>
      <Addapplication />
    </SnackbarProvider>
  );
}
const PlusBtn = styled.div`
  display: flex;
  justify-content: flex-end;
  padding-right: 5px;
  background-color: #f1f1f1;
  .css-12m9wit-MuiButtonBase-root-MuiFab-root:hover {
    background-color: #2979ff !important;
  }

  .css-12m9wit-MuiButtonBase-root-MuiFab-root {
    background-color: #2979ff;
    border-radius: 4px;
    color: white !important;
    width: 35px !important;
    height: 35px !important;
  }
`;
const Rassasy2 = styled.div`
  display: flex;
  align-items: center;
  gap: 10px;
`;
const RassasyContainer = styled.div`
  width: 35px;
  height: 35px;
`;
const ImgLogo = styled.img`
  width: 100%;
  height: 100%;
  object-fit: contain;
`;
const SmallCard = styled.div`
  width: 100%;
  margin-top: 10px;
  :nth-child(1) {
    margin-top: unset;
  }
`;
const Card1 = styled.div`
  display: flex;
  align-items: center;
  justify-content: space-between;
`;
const RassayButton = styled(Button)`
  &.css-1e6y48t-MuiButtonBase-root-MuiButton-root:hover {
    background-color: #d4d4d4 !important;
  }
  .css-1e6y48t-MuiButtonBase-root-MuiButton-root {
    padding: 1px 8px !important;
  }
  && {
    /* background: rgba(0, 0, 0, 0.04) !important; */

    color: black !important;
    text-transform: unset !important;
    width: 100%;
    /* justify-content: left; */
    border-radius: 2px;

    /* display: flex;
    justify-content: space-between; */

    align-items: center;
    border-radius: 4px;
    height: 50px;

    /* border: 1px solid #d4d4d4; */
    svg {
    }
  }
`;
const CardScroll = styled.div`
  overflow-x: scroll;
  padding: 10px;
  background-color: #f1f1f1;
  ::-webkit-scrollbar {
    display: none;
  }
  height: 350px;
  margin-top: 20px;
  @media (min-width: 1920px) {
    height: 535px;
  }
`;
const HaaderModal = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
`;
const BottomHeader = styled(HaaderModal)`
  margin-top: 10px;
`;
const ModalContainer = styled.div`
  h2 {
    font-family: "Poppins", sans-serif !important;
  }
  &.css-ix1f03-MuiTypography-root {
    font-family: "Poppins", sans-serif !important;
  }

  font-family: "Poppins", sans-serif !important;
`;
const EditButton = styled(EditIcon)`
  color: #4c69dc;
`;
const DeleteButton = styled(DeleteIcon)`
  color: #c83d42;
`;
const TableContainer = styled.div`
  margin-top: 10px;
  :nth-child(2) {
    margin-top: unset;
  }
`;
const TD = styled.td`
  padding: 0px 15px !important;
  text-align: left;
  font-size: 12px;
  padding: 0.5em 1em;

  vertical-align: middle;

  &.cursor {
    cursor: pointer;
  }
`;
const TableBodyRow = styled.tr``;
const Table = styled.table`
  width: 100%;
  background: #fff;
  border-spacing: unset;
`;

const TableHeadRow = styled.tr``;

const TH = styled.th`
  padding: 3px 15px;
  font-weight: normal;
  text-align: left;
  font-size: 10px;
`;

const Top = styled.div`
  background-color: #f1f1f1;
  padding: 5px 5px;
  height: 58vh; ;
`;
const EditionTxt = styled.h2`
  font-size: 19px;
`;
const BottomContainer = styled.div`
  width: 100%;
  margin-top: 15px;
`;
const TopContainer = styled.div`
  position: relative;
`;
const AddonContainer = styled.div`
  display: flex;
  justify-content: space-between;
  width: 100%;
  align-items: center;
`;
const CustomeAutocomplete = styled(Autocomplete)`
  &.css-1auycx3-MuiAutocomplete-root
    .MuiOutlinedInput-root.MuiInputBase-sizeSmall
    .MuiAutocomplete-input {
    padding: 1px 10px;
    font-size: 14px !important;
  }
  && {
    min-width: 167px;
    margin-top: 5px;
    background-color: #e9e9e9;

    /* @media (min-width: 1920px) {
      min-width: 245px;
    }

    @media (max-width: 1920px) {
      width: 244px;
    } */
  }
  .css-1d3z3hw-MuiOutlinedInput-notchedOutline {
    outline: unset !important ;
    border: unset;
    border-width: 1px !important;
  }

  button {
    padding: 0;
  }
  .css-19qh8xo-MuiInputBase-input-MuiOutlinedInput-input {
    height: 1rem !important;
  }
`;
const SelectBox1 = styled.div`
  margin-top: 5px;
  &.css-1u3bzj6-MuiFormControl-root-MuiTextField-root {
    width: 100% !important;
    margin-top: 5px;
  }
  .kyHogC .css-1869usk-MuiFormControl-root {
    border-radius: 2px !important;
  }
  .css-1t8l2tu-MuiInputBase-input-MuiOutlinedInput-input {
    padding: 3.5px 14px !important;
  }
  .css-1d3z3hw-MuiOutlinedInput-notchedOutline {
    border: none !important;
  }
  .css-1869usk-MuiFormControl-root {
    min-width: 100%;
    margin: unset !important;
    background-color: #e9e9e9 !important ;
    @media (min-width: 1920px) {
      width: 250px;
    }
  }
  .css-1auycx3-MuiAutocomplete-root
    .MuiOutlinedInput-root
    .MuiAutocomplete-endAdornment {
    top: -1px !important;
  }
  .MuiOutlinedInput-notchedOutline {
    border-color: #d4d4d4 !important;
    border-width: 1px !important ;
    border-radius: 2px !important ;
    outline: unset !important;
  }

  div div div {
    padding: 3px;
  }

  em {
    font-style: normal !important;
    font-family: unset !important;
  }
  .css-11u53oe-MuiSelect-select-MuiInputBase-input-MuiOutlinedInput-input.css-11u53oe-MuiSelect-select-MuiInputBase-input-MuiOutlinedInput-input.css-11u53oe-MuiSelect-select-MuiInputBase-input-MuiOutlinedInput-input {
    padding-left: 12px !important;
    border: unset !important;
    font-size: 14px !important;
    outline: unset !important;
    background: #efefef !important;
  }
`;

const CustomeAutocomplete2 = styled(CustomeAutocomplete)`
  && {
    min-width: 215px;
  }
`;

const CustomTextField = styled(TextField)`
  margin-top: 5px !important;
  background-color: #e9e9e9 !important ;
  border: unset !important;
  outline: unset !important;
  &.css-1u3bzj6-MuiFormControl-root-MuiTextField-root {
    width: 100% !important;
  }
  .css-1t8l2tu-MuiInputBase-input-MuiOutlinedInput-input {
    padding: 4.6px 14px !important;
    font-size: 14px !important;
  }
  .css-1d3z3hw-MuiOutlinedInput-notchedOutline {
    border: none !important;
  }
`;
const TextContainer = styled.div`
  margin-top: 10px;
  width: 48%;
`;
const ImageContanier = styled(TextContainer)`
  margin-top: unset;
  width: unset;
  position: absolute;
  top: 0;
  right: 176px;

  @media (min-width: 1920px) {
    right: 290px;
  }
`;
const Label = styled.label`
  font-size: 13px;
  margin-top: 15px;
  margin-left: 1px;
`;
const BodyContainer = styled.div`
  width: 50%;
  margin-top: 10px;
`;
const Container = styled.div``;
const Heading = styled.div`
  width: 100%;
  display: flex;
  justify-content: space-between;
`;
const AddApplicationTxt = styled.h2`
  font-size: 25px;
  letter-spacing: 1px; ;
`;
const SaveButtonContainer = styled.div`
  position: relative;
`;

const HeaderContainer = styled.div`
  padding: 5px;
`;

const RightHeader = styled.div`
  width: 100%;
`;

const ThreeBoxContainer = styled.div`
  display: flex;
  gap: 10px;
`;
