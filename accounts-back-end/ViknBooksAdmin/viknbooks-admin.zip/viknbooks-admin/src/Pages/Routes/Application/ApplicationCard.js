import React, { useState } from "react";
import { Button, IconButton, Menu, MenuItem } from "@mui/material";
import styled from "styled-components/macro";
import MoreVertIcon from "@mui/icons-material/MoreVert";
function ApplicationCard({ index }) {
  const options = ["Phobos", "Pyxis", "Sedna", "Titania", "Triton", "Umbriel"];
  const [anchorEl, setAnchorEl] = useState(null);
  const open = Boolean(anchorEl);
  const handleClick = (event) => {
    setAnchorEl(event.currentTarget);
  };
  const handleClose = () => {
    setAnchorEl(null);
  };
  const ITEM_HEIGHT = 48;
  return (
    <div>
      <Card>
        <LeftSide>
          <LogoContainer>
            <Logo src="../../Images/Icons/viknlogo.svg" />
          </LogoContainer>

          <AppTxtContainer>
            <AppText>Viknbooks</AppText>
            <VersionTxtContainer>
              <VersionTxt>version</VersionTxt>
              <VersionTxt>23.56.77</VersionTxt>
            </VersionTxtContainer>
            <CustomButton>
              <Button variant="text" color="success">
                Core App
              </Button>
            </CustomButton>
          </AppTxtContainer>
        </LeftSide>
        <RightSide>
          <IconButton
            aria-label="more"
            id={index}
            aria-controls={open ? "long-menu" : undefined}
            aria-expanded={open ? "true" : undefined}
            aria-haspopup="true"
            onClick={handleClick}
          >
            <MoreVertIcon />
          </IconButton>
          <Menus
            disableScrollLock={true}
            id="long-menu"
            MenuListProps={{
              "aria-labelledby": ` ${index}`,
            }}
            anchorEl={anchorEl}
            open={open}
            onClose={handleClose}
            PaperProps={{
              style: {
                maxHeight: ITEM_HEIGHT * 4.5,
                width: "20ch",
              },
            }}
          >
            {options.map((option) => (
              <MenuItem
                key={option}
                selected={option === "Pyxis"}
                onClick={handleClose}
              >
                {option}
              </MenuItem>
            ))}
          </Menus>
        </RightSide>
      </Card>

      {/* ///second Card------------------------- */}
    </div>
  );
}

export default ApplicationCard;
const Menus = styled(Menu)`
  .css-1poimk-MuiPaper-root-MuiMenu-paper-MuiPaper-root-MuiPopover-paper {
    ::-webkit-scrollbar {
      display: none;
    }
  }
`;
const Logo = styled.img`
  width: 100%;
  height: 100%;
  object-fit: contain;
`;
const Card = styled.div`
  padding: 10px;

  display: flex;
  cursor: pointer;
  align-items: center;

  justify-content: space-between;
  background-color: #eeeeee;
`;
const RightSide = styled.div`
  display: flex;
  align-self: baseline;
  height: 100%;
  svg {
    font-size: 1.4rem !important ;
    color: black !important;
  }
  .css-78trlr-MuiButtonBase-root-MuiIconButton-root {
    padding: unset !important;
  }
  .MuiPaper-root {
    box-shadow: none !important;
  }
`;
const LeftSide = styled.div`
  display: flex;
  gap: 10px;
`;
const LogoContainer = styled.div`
  display: flex;
  align-items: center;
  border-radius: 1px;
  background-color: white;
  padding: 10px;
  width: 59px;
  height: 59px; ;
`;
const AppTxtContainer = styled.div`
  display: flex;
  flex-direction: column;
`;
const AppText = styled.h3`
  font-size: 15px;
  font-weight: bold;
`;
const VersionTxtContainer = styled.div`
  display: flex;
  gap: 5px;
`;
const VersionTxt = styled.span`
  color: #004d8f;
  font-size: 10px;
`;
const CustomButton = styled.div`
  display: flex;
  width: 100%;

  .css-1lg55su-MuiButtonBase-root-MuiButton-root {
    background: #ced4ce;
    font-size: 10px !important;
    color: green;
    border: unset !important;
    border-radius: unset;

    text-transform: unset !important ;
    padding: 1px !important;
  }
  .css-1lg55su-MuiButtonBase-root-MuiButton-root:hover {
    background-color: #ced4ce;
  }
  .css-1e6y48t-MuiButtonBase-root-MuiButton-root:hover {
    /* background-color: #ced4ce !important; */
    color: white;
  }
`;
