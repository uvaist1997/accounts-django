import { Box, TextField } from "@mui/material";
import { Button } from "@mui/material";

import styled from "styled-components/macro";
import React, { useRef, useState } from "react";
import ReactDOM from "react-dom";
import "jodit";
import "jodit/build/jodit.min.css";
import JoditEditor from "jodit-react";
const copyStringToClipboard = function (str) {
  var el = document.createElement("textarea");
  el.value = str;
  el.setAttribute("readonly", "");
  el.style = { position: "absolute", left: "-9999px" };
  document.body.appendChild(el);
  el.select();
  document.execCommand("copy");
  document.body.removeChild(el);
};

const facilityMergeFields = [
  "FacilityNumber",
  "FacilityName",
  "Address",
  "MapCategory",
  "Latitude",
  "Longitude",
  "ReceivingPlant",
  "TrunkLine",
  "SiteElevation",
];
const inspectionMergeFields = ["InspectionCompleteDate", "InspectionEventType"];
const createOptionGroupElement = (mergeFields, optionGrouplabel) => {
  let optionGroupElement = document.createElement("optgroup");
  optionGroupElement.setAttribute("label", optionGrouplabel);
  for (let index = 0; index < mergeFields.length; index++) {
    let optionElement = document.createElement("option");
    optionElement.setAttribute("class", "merge-field-select-option");
    optionElement.setAttribute("value", mergeFields[index]);
    optionElement.text = mergeFields[index];
    optionGroupElement.appendChild(optionElement);
  }
  return optionGroupElement;
};
const buttons = [
  "undo",
  "redo",
  "|",
  "bold",
  "strikethrough",
  "underline",
  "italic",
  "|",
  "superscript",
  "subscript",
  "|",
  "align",
  "|",
  "ul",
  "ol",
  "outdent",
  "indent",
  "|",
  "font",
  "fontsize",
  "brush",
  "paragraph",
  "|",
  "image",
  "link",
  "table",
  "|",
  "hr",
  "eraser",
  "copyformat",
  "|",
  "fullsize",
  "selectall",
  "print",
  "|",
  "source",
  "|",
  {
    name: "insertMergeField",
    tooltip: "Insert Merge Field",
    iconURL: "images/merge.png",
    popup: (editor, current, self, close) => {
      function onSelected(e) {
        let mergeField = e.target.value;
        if (mergeField) {
          console.log(mergeField);
          editor.selection.insertNode(
            editor.create.inside.fromHTML("{{" + mergeField + "}}")
          );
        }
      }
      let divElement = editor.create.div("merge-field-popup");

      let labelElement = document.createElement("label");
      labelElement.setAttribute("class", "merge-field-label");
      labelElement.text = "Merge field: ";
      divElement.appendChild(labelElement);

      let selectElement = document.createElement("select");
      selectElement.setAttribute("class", "merge-field-select");
      selectElement.appendChild(
        createOptionGroupElement(facilityMergeFields, "Facility")
      );
      selectElement.appendChild(
        createOptionGroupElement(inspectionMergeFields, "Inspection")
      );
      selectElement.onchange = onSelected;
      divElement.appendChild(selectElement);

      console.log(divElement);
      return divElement;
    },
  },
  {
    name: "copyContent",
    tooltip: "Copy HTML to Clipboard",
    iconURL: "images/copy.png",
    exec: function (editor) {
      let html = editor.value;
      copyStringToClipboard(html);
    },
  },
];

const editorConfig = {
  readonly: false,
  toolbar: true,
  spellcheck: true,
  language: "en",
  toolbarButtonSize: "medium",
  toolbarAdaptive: false,
  showCharsCounter: true,
  showWordsCounter: true,
  showXPathInStatusbar: false,
  askBeforePasteHTML: true,
  askBeforePasteFromWord: true,
  //defaultActionOnPaste: "insert_clear_html",
  buttons: buttons,
  uploader: {
    insertImageAsBase64URI: true,
  },
  width: 800,
  height: 842,
};

function CreateBlog() {
  const [data, setData] = useState();
  const changeValue = (value) => {
    setData(value);
  };
  return (
    <Container>
      <Heading>
        <BlogCreateBlogTxt>Create Blog</BlogCreateBlogTxt>
      </Heading>

      <Header__BoxContaner>
        <SeachBoxContainer>
          <span>Title</span>
          <Box
            component="form"
            sx={{
              "& > :not(style)": { width: "100% " },
            }}
            noValidate
            autoComplete="off"
          >
            <TextBox id="outlined-basic" variant="outlined" />
          </Box>
        </SeachBoxContainer>
        <SeachBoxContainer2>
          <span>Author</span>
          <Box
            component="form"
            sx={{
              "& > :not(style)": { width: "100% " },
            }}
            noValidate
            autoComplete="off"
          >
            <TextBox id="outlined-basic" variant="outlined" />
          </Box>{" "}
        </SeachBoxContainer2>{" "}
        <SearchButton>Publish</SearchButton>
      </Header__BoxContaner>

      {/* <div>
        <MuiThemeProvider theme={defaultTheme}>
          <MUIRichTextEditor
            label="Type something here..."
            onSave={save}
            inlineToolbar={false}
          />
        </MuiThemeProvider>
      </div> */}

      <JoditContainer>
        {/* <JoditEditor
          ref={editor}
          value={initialValue}
          config={config}
          tabIndex={1}
          // onBlur={(newContent) => getValue(newContent)}
          // onChange={(newContent) => getValue(newContent)}
          onBlur={(newContent) => setContent(newContent)} // preferred to use only this option to update the content for performance reasons
          onChange={(newContent) => {}}
        /> */}
        <div
          className="App"
          style={{ maxWidth: editorConfig.width, margin: "0 auto" }}
        >
          <JoditEditor
            value={data}
            config={editorConfig}
            onChange={() => changeValue(data)}
          />
        </div>
      </JoditContainer>
    </Container>
  );
}
export default CreateBlog;
const JoditContainer = styled.div`
  margin-top: 20px;
  && {
    .App {
      width: 100%;
      max-width: 100% !important;

      .jodit-container:not(.jodit_inline) {
        width: 74.4rem !important;
        @media (width: 1600px) {
          width: 84.4rem !important;
        }
        @media (width: 1309.09px) {
          width: 66.29rem !important;
        }
        @media (width: 1800px) {
          width: 96.7rem !important;
        }
        @media (width: 1920px) {
          width: 104.1rem !important;
        }
      }
    }
    .jodit-workplace + .jodit-status-bar:not(:empty) {
      display: none;
    }
  }
`;
const SearchButton = styled(Button)`
  && {
    background: #009e15;
    color: #fff;
    margin-bottom: 1px;
    border-radius: 2px;
    align-self: self-end;
    display: flex;
    padding: 3px 45px;
    text-transform: capitalize;
    &:hover {
      background: #009e15;
    }
  }
`;
const TextBox = styled(TextField)`
  outline: unset !important;
  .MuiOutlinedInput-input {
    padding: 4px 15px !important;
  }
  &.fieldset {
    border-color: black !important ;
  }
`;
const SeachBoxContainer = styled.div`
  width: 100%;

  .MuiOutlinedInput-notchedOutline {
    border-color: #d4d4d4 !important;
    border-width: 1px !important ;
    outline: unset !important;
  }
`;
const SeachBoxContainer2 = styled(SeachBoxContainer)`
  width: 30%;
  margin: 0px 8px;
`;
const Header__BoxContaner = styled.div`
  display: flex;
  align-items: center;
  width: 100%;
  /* justify-content: space-evenly; */
`;
const Container = styled.div``;
const Heading = styled.div`
  width: 100%;
  display: flex;
  justify-content: space-between;
`;
const BlogCreateBlogTxt = styled.h2`
  font-size: 25px;
  letter-spacing: 1px; ;
`;
