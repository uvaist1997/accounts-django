import React, { useState } from "react";
import styled from "styled-components/macro";
import { Avatar } from "@mui/material";
import FavoriteIcon from "@mui/icons-material/Favorite";
import DeleteIcon from "@mui/icons-material/Delete";
import CreateIcon from "@mui/icons-material/Create";
import IconButton from "@mui/material/IconButton";
import Checkbox from "@mui/material/Checkbox";
import FavoriteBorder from "@mui/icons-material/FavoriteBorder";
import Favorite from "@mui/icons-material/Favorite";
import Tooltip from "@mui/material/Tooltip";
function BlogCards({ title }) {
  ///favorite Icon
  const label = { inputProps: { "aria-label": "Checkbox demo" } };
  return (
    <Card__mainContainer>
      <LeftContainer>
        <ImgContainer>
          <ImgTag src="https://cdn.pixabay.com/photo/2015/04/23/22/00/tree-736885__480.jpg" />
        </ImgContainer>
        <div>
          <Title>{title}</Title>
          <DateContainer>
            <p>Published</p>
            <span>30 November 2021</span>
          </DateContainer>
        </div>
      </LeftContainer>
      <RightContainer>
        <AvatarContainer>
          <span>Savad Farook</span>
          <AvatarImage>
            <Avatar
              alt="Remy Sharp"
              src="https://i.pinimg.com/originals/02/6c/da/026cdaf717ac7af4482aec84436709ab.jpg"
            />
          </AvatarImage>
        </AvatarContainer>
        <Icons__Container>
          <Pencil>
            <Tooltip title="Add to fav">
              <Checkbox
                {...label}
                icon={<FavoriteBorder />}
                checkedIcon={<Favorite />}
              />
            </Tooltip>
          </Pencil>
          <Pencil>
            <Tooltip title="Edit">
              <IconButton>
                <CreateIcon />
              </IconButton>
            </Tooltip>
          </Pencil>
          <Pencil>
            <Tooltip title="Delete">
              <IconButton>
                <DeleteIcon />
              </IconButton>
            </Tooltip>
          </Pencil>
        </Icons__Container>
      </RightContainer>
    </Card__mainContainer>
  );
}

export default BlogCards;
const Card__mainContainer = styled.div`
  padding: 5px;
  border: 1px solid #d4d4d4;

  border-radius: 2px;
  &:hover {
    background-color: rgba(0, 0, 0, 0.04);
  }
  display: flex;

  margin-top: 5px;
  :nth-child(1) {
    margin: unset;
  }
`;
const ImgContainer = styled.div`
  width: 50px;
  height: 50px;
`;
const ImgTag = styled.img`
  width: 100%;
  height: 100%;
`;
const Title = styled.span`
  font-size: 13px;
  font-weight: bold;
`;
const DateContainer = styled.div`
  color: #808080;
  font-size: 11px;
  display: flex;
  gap: 5px;
`;

const LeftContainer = styled.div`
  display: flex;
  width: 50%;
  gap: 10px;
  align-items: center;
`;
const AvatarImage = styled.div`
  div {
    width: 28px;
    height: 28px;
  }
`;

const AvatarContainer = styled.div`
  display: flex;
  gap: 15px;
  justify-content: flex-end;
  font-weight: bold;
  font-size: 13px;
  align-items: center;
`;
const RightContainer = styled.div`
  display: flex;
  flex-direction: column;
  width: 50%;
`;
const Icons__Container = styled.div`
  display: flex;
  gap: 20px;
  justify-content: flex-end;
  padding-right: 42px;
  /* align-items: center; */
`;
const Pencil = styled.div`
  cursor: pointer;
  width: 15px;
  height: 15px;
  .css-i4bv87-MuiSvgIcon-root {
    font-size: 1.3rem !important;
  }
  .css-78trlr-MuiButtonBase-root-MuiIconButton-root {
    padding: unset !important ;
  }
  .css-12wnr2w-MuiButtonBase-root-MuiCheckbox-root {
    padding: unset !important;
  }
  .css-12wnr2w-MuiButtonBase-root-MuiCheckbox-root.Mui-checked,
  .css-12wnr2w-MuiButtonBase-root-MuiCheckbox-root.MuiCheckbox-indeterminate {
    color: #eb0000 !important;
  }
`;
const PencilIcon = styled.img`
  width: 100%;
  height: 100%;
`;

const FavIcon = styled(FavoriteIcon)`
  color: ${({ fav }) => (fav ? "#EB0000" : "#bfbfbf")};
  cursor: pointer;
`;
