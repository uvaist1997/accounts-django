import React, { useEffect, useState } from "react";
import styled from "styled-components/macro";
import Box from "@mui/material/Box";
import TextField from "@mui/material/TextField";
import MenuItem from "@mui/material/MenuItem";
import { Button } from "@mui/material";
import FormControl from "@mui/material/FormControl";
import Select from "@mui/material/Select";
import BlogCards from "./BlogCards";
import CreateButton from "../../../Components/CreateButton";
import Pagination from "@mui/material/Pagination";
import { Typography } from "antd";
import { useNavigate } from "react-router-dom";
function Blog() {
  const navigate = useNavigate();
  const [age, setAge] = useState("");
  //pagination===================

  const [page, setPage] = useState(1);
  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage, setItemsPerPage] = useState(9);

  const IndexofLastItem = currentPage * itemsPerPage;
  const indexOfFirstDish = IndexofLastItem - itemsPerPage;

  const [card, setCard] = useState([
    {
      title: "uvais",
    },
    {
      title: "abhi",
    },
    {
      title: "uvais",
    },
    {
      title: "jasmal jaizz",
    },
    {
      title: "uvais",
    },
    {
      title: "122334",
    },
    {
      title: "qwert",
    },
    {
      title: "cgf",
    },
    {
      title: "xdf",
    },
    {
      title: "uvaxgis",
    },
    {
      title: "hokmng",
    },
    {
      title: "pppppppppp",
    },
    {
      title: "iiiiiiiiiii",
    },
    {
      title: "tttttttttt",
    },
    {
      title: "eeeeeeee",
    },
    {
      title: "eeeeeeeee",
    },
    {
      title: "eeeeeeeee",
    },
    {
      title: "eeeeeeeee",
    },
    {
      title: "eeeeeeeee",
    },
    {
      title: "eeeeeeeee",
    },
    {
      title: "eeeeeeeee",
    },
    {
      title: "eeeeeeeee",
    },
  ]);
  let PaginatedData = card.slice(indexOfFirstDish, IndexofLastItem);
  console.log("page", PaginatedData);
  const handleChange = (event) => {
    setAge(event.target.value);
  };

  const ChangePage = (event, value) => {
    setCurrentPage(value);
  };

  const NumOfpages = Math.ceil(card.length / itemsPerPage);

  const NavigateToCreateBlog = () => {
    navigate("/create-blog");
  };
  return (
    <Container>
      <Heading>
        <BlogTxt>Blogs</BlogTxt>
        <CreateButtonContainer onClick={NavigateToCreateBlog}>
          <CreateButton label={"Create New"} />
        </CreateButtonContainer>
      </Heading>

      <span>Search</span>
      <Header__BoxContaner>
        <SeachBoxContainer>
          <Box
            component="form"
            sx={{
              "& > :not(style)": { width: "100% " },
            }}
            noValidate
            autoComplete="off"
          >
            <TextBox id="outlined-basic" variant="outlined" />
          </Box>
        </SeachBoxContainer>
        <SelectBox1>
          <FormControl sx={{ m: 1, minWidth: 120 }}>
            <Select
              value={age}
              onChange={handleChange}
              displayEmpty
              MenuProps={{
                disableScrollLock: true,
              }}
            >
              <MenuItems value="" disabled selected hidden>
                Published
              </MenuItems>
              <MenuItems value={10}>Ten</MenuItems>
              <MenuItems value={20}>Twenty</MenuItems>
              <MenuItems value={30}>Thirty</MenuItems>
            </Select>
          </FormControl>
        </SelectBox1>
        <SearchButton>Search</SearchButton>
      </Header__BoxContaner>

      {/* //card section============================================== */}
      <Cards>
        <Typography>
          {PaginatedData.map((i) => {
            return <BlogCards title={i.title} />;
          })}
        </Typography>
      </Cards>
      <PagenationContainer>
        <Pagination count={NumOfpages} onChange={ChangePage} />
      </PagenationContainer>
    </Container>
  );
}

export default Blog;

const MenuItems = styled(MenuItem)`
  font-size: 13px !important;
`;
const PagenationContainer = styled.div`
  width: 100%;
  display: flex;
  justify-content: center;
`;
const CreateButtonContainer = styled.div`
  position: relative;
`;

const Cards = styled.div`
  margin-top: 15px;
  margin-bottom: 20px;
`;

const SearchButton = styled(Button)`
  && {
    background: #009e15;
    color: #fff;
    border-radius: 2px;
    padding: 3px 45px;
    text-transform: capitalize;
    &:hover {
      background: #009e15;
    }
  }
`;

const SeachBoxContainer = styled.div`
  width: 100%;

  .MuiOutlinedInput-notchedOutline {
    border-color: #d4d4d4 !important;
    border-width: 1px !important ;
    outline: unset !important;
  }
`;
const Header__BoxContaner = styled.div`
  display: flex;
  align-items: center;
  width: 100%;
  /* justify-content: space-evenly; */
`;
const TextBox = styled(TextField)`
  outline: unset !important;
  .MuiOutlinedInput-input {
    padding: 4px 15px !important;
  }
  &.fieldset {
    border-color: black !important ;
  }
`;
const BlogTxt = styled.h2`
  font-size: 25px;
  letter-spacing: 1px; ;
`;
const Container = styled.div``;
const Heading = styled.div`
  width: 100%;
  display: flex;
  justify-content: space-between;
`;
const SelectBox1 = styled.div`
  .css-1869usk-MuiFormControl-root {
    min-width: 299px !important;
    margin: 0px 8px !important;

    .css-1yk1gt9-MuiInputBase-root-MuiOutlinedInput-root-MuiSelect-root {
      font-size: 13px !important;
      line-height: 1.4rem !important ;
    }
  }
  .MuiOutlinedInput-notchedOutline {
    border-color: #d4d4d4 !important;
    border-width: 1px !important ;
    outline: unset !important;
  }

  div div div {
    padding: 4px 10px;
  }

  em {
    font-style: normal !important;
  }
`;
