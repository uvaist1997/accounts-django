import { CircularProgress } from "@mui/material";
import React, { lazy, Suspense } from "react";
import {
  BrowserRouter as Router,
  Routes as Switch,
  Route,
} from "react-router-dom";
import styled from "styled-components/macro";
import Header from "../../Components/Header/Header";
import SideBar from "../../Components/SideBar/SideBar";
const DashBoard = lazy(() => import("../DashBoard/DashBoard"));
const Blog = lazy(() => import("./Blog/Blog"));
const Organization = lazy(() => import("../Organization/Organization"));
const Partners = lazy(() => import("../Partners/Partners"));
const Deal = lazy(() => import("../Deals/Deal"));
const Application = lazy(() => import("./Application/Application"));
const Leads = lazy(() => import("../Leads/Leads"));
const Countries = lazy(() => import("../../Screens/Countries/Countries"));
const States = lazy(() => import("../../Screens/States/States"));
const Users = lazy(() => import("../../Screens/Users/Users"));
const Uqc = lazy(() => import("../../Screens/UQC/Uqc"));
const BussinessType = lazy(() =>
  import("../../Screens/BussinessType/BussinessType")
);
const Servicelog = lazy(() => import("../../Pages/ServiceLog/Servicelog"));
const Invoice = lazy(() => import("../Invoices/Invoice"));
const EnquiryQuestions = lazy(() =>
  import("../../Screens/EnquiryQuestions/EnquiryQuestions")
);

const Enquiry = lazy(() => import("../Enquiry/Enquiry"));
const PartnerDetails = lazy(() => import("../Partners/PartnerDetails"));

const ActivityLog = lazy(() => import("../../Screens/ActivityLog/ActivityLog"));

const Viknbooks = lazy(() => import("../Organization/Viknbooks"));
const ViknERP = lazy(() => import("../Organization/ViknERP"));

const Activity = lazy(() => import("../Activity/Activity"));
const CreateBlog = lazy(() => import("../Routes/Blog/CreateBlog"));
const Addapplication = lazy(() =>
  import("../Routes/Application/Addapplication")
);
function Navigation() {
  return (
    <Container>
      <Header />

      <MenuContainer>
        <SideBar />
        <Suspense
          fallback={
            <Box>
              <CircularProgress />
            </Box>
          }
        >
          <Routes>
            <Switch>
              <Route path="/*" element={<DashBoard />} />
              <Route path="/organization" element={<Organization />} />
              <Route path="/partners" element={<Partners />} />
              <Route path="/service-log" element={<Servicelog />} />

              <Route path="/blog" element={<Blog />} />
              <Route path="/application" element={<Application />} />
              <Route path="/enquiry" element={<Enquiry />} />
              <Route path="/deals" element={<Deal />} />
              <Route path="/leads" element={<Leads />} />
              <Route path="/invoice" element={<Invoice />} />
              <Route path="/countries" element={<Countries />} />
              <Route path="/states" element={<States />} />
              <Route path="/users" element={<Users />} />
              <Route path="/uqc" element={<Uqc />} />
              <Route path="/bussinesstypes" element={<BussinessType />} />
              <Route path="/enquiryquestions" element={<EnquiryQuestions />} />
              <Route path="/partner-details" element={<PartnerDetails />} />
              <Route path="/activitylog" element={<ActivityLog />} />

              <Route path="/viknbooks" element={<Viknbooks />} />
              <Route path="/vikn-erp" element={<ViknERP />} />
              <Route path="/activities" element={<Activity />} />
              <Route path="/addapplication" element={<Addapplication />} />
              <Route path="/create-blog" element={<CreateBlog />} />
            </Switch>
          </Routes>
        </Suspense>
      </MenuContainer>
    </Container>
  );
}

export default Navigation;

const Container = styled.div`
  background-color: #ebebeb;
  width: 100%;
  padding-top: 62px;
  /* min-height: 100vh; */
`;

const MenuContainer = styled.div`
  display: flex;
  width: 100%;
  height: 100%;
  padding: 8px 8px 8px 0px;
`;
const Routes = styled.div`
  /* width: 86.4%; */
  margin: 0;
  margin-left: 197px;
  display: flex;
  flex-direction: column;
  flex: 1;
  padding: 15px;
  background-color: #ffffff;
  min-height: 100vh;
  border-radius: 6px;
`;

const Box = styled.div`
  width: 100%;
  height: 80vh;

  /* width: 96%; */

  display: grid;
  place-items: center;
`;
