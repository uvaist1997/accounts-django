import { Menu } from "@mui/material";
import React from "react";
import styled from "styled-components/macro";

import MenuItem from "@mui/material/MenuItem";
import IconButton from "@mui/material/IconButton";

import MoreVertIcon from "@mui/icons-material/MoreVert";
import FilterBox from "../../Components/FilterBox";
import CustomTable from "../../Components/CustomTable";
function Deal() {
  const [age, setAge] = React.useState("");
  const handleChange = (event) => {
    setAge(event.target.value);
  };

  const [anchorEl, setAnchorEl] = React.useState(null);
  const open = Boolean(anchorEl);
  const handleClick = (event) => {
    setAnchorEl(event.currentTarget);
  };
  const handleClose = () => {
    setAnchorEl(null);
  };
  const options = [
    "None",
    "Atria",
    "Callisto",
    "Dione",
    "Ganymede",
    "Hangouts Call",
    "Luna",

    "Umbriel",
  ];
  const ITEM_HEIGHT = 48;
  return (
    <Container>
      <Heading>
        <BlogTxt>Deal</BlogTxt>

        <LeftContainer>
          <FilterBox label={"filter"} />

          <MenuIconContainer>
            <IconButton
              aria-label="more"
              id="long-button"
              aria-controls={open ? "long-menu" : undefined}
              aria-expanded={open ? "true" : undefined}
              aria-haspopup="true"
              onClick={handleClick}
            >
              <MoreVertIcon />
            </IconButton>
            <Menus
              disableScrollLock={true}
              id="long-menu"
              MenuListProps={{
                "aria-labelledby": "long-button",
              }}
              anchorEl={anchorEl}
              open={open}
              onClose={handleClose}
              PaperProps={{
                style: {
                  maxHeight: ITEM_HEIGHT * 4.5,
                  width: "20ch",
                },
              }}
            >
              {options.map((option) => (
                <MenuItem
                  key={option}
                  selected={option === "Pyxis"}
                  onClick={handleClose}
                >
                  {option}
                </MenuItem>
              ))}
            </Menus>
          </MenuIconContainer>
        </LeftContainer>
      </Heading>
      <TableContainer>
        <CustomTable isMenu={true} />
      </TableContainer>
    </Container>
  );
}

export default Deal;

const TableContainer = styled.div`
  margin-top: 10px;
`;

const LeftContainer = styled.div`
  display: flex;
  gap: 8px;
`;
const Menus = styled(Menu)`
  .css-1poimk-MuiPaper-root-MuiMenu-paper-MuiPaper-root-MuiPopover-paper {
    ::-webkit-scrollbar {
      display: none;
    }
  }
`;
const MenuIconContainer = styled.div`
  svg {
    font-size: 2.1rem !important ;
    color: black !important;

    transform: rotate(90deg);
    border: 1px solid #aeaeae;
    border-radius: 4px;

    width: 36px;
    height: 38px;
  }
  /* .css-78trlr-MuiButtonBase-root-MuiIconButton-root {
    border-radius: unset !important ;
  } */
  .css-78trlr-MuiButtonBase-root-MuiIconButton-root {
    padding: unset !important;
    border-radius: unset !important ;
  }
`;
const SelectBox1 = styled.div`
  position: relative;
  .css-1869usk-MuiFormControl-root {
    min-width: 299px !important;
    margin: 0px 8px !important;
  }
  .MuiOutlinedInput-notchedOutline {
    border-color: #d4d4d4 !important;
    border-width: 1px !important ;
    outline: unset !important;
  }

  div div div {
    padding: 6px;
  }

  em {
    font-style: normal !important;
  }
`;
const Container = styled.div``;
const Heading = styled.div`
  width: 100%;
  display: flex;
  justify-content: space-between;
`;
const BlogTxt = styled.h2`
  font-size: 25px;
  letter-spacing: 1px; ;
`;
