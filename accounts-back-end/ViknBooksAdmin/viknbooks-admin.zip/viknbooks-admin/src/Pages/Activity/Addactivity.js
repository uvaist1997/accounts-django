import React from "react";
import styled from "styled-components/macro";
import CloseIcon from "@mui/icons-material/Close";
import { Menu, Button } from "@mui/material";
import IconButton from "@mui/material/IconButton";
import TextField from "@mui/material/TextField";
import { useState } from "react";
import DomainIcon from "@mui/icons-material/Domain";

import LocalPhoneIcon from "@mui/icons-material/LocalPhone";
import AccessTimeFilledIcon from "@mui/icons-material/AccessTimeFilled";
import { Autocomplete } from "@mui/material";
import { TextareaAutosize } from "@material-ui/core";
import DateRangePicker from "../../Components/DateRangePIcker";
import { AdapterDateFns } from "@mui/x-date-pickers/AdapterDateFns";
import { LocalizationProvider } from "@mui/x-date-pickers/LocalizationProvider";
import { TimePicker } from "@mui/x-date-pickers/TimePicker";
function Addactivity({ activityBox, setActivityBox }) {
  const [age, setAge] = useState("");
  const [sideTab, setSideTab] = useState(true);
  const handleChange = (event) => {
    setAge(event.target.value);
  };
  const [value, setValue] = React.useState(null);
  const [showSelect, setShowSelect] = useState(false);
  const [state, setState] = useState({
    data: ["jasmal", "MUI X: Missing license key ", "Abhi"],
    Projectlsd: [],
    ProjeID: "",
    contact_data: [
      {
        phone: "",
        work: "",
      },
    ],

    contact_email: [
      {
        email: "",
        work: "",
      },
    ],
  });
  const handleSelectChange = () => {
    console.log("select");
  };

  return (
    <Container activityBox={activityBox}>
      <div>
        <Header>
          <AddLeadText>Add Activity</AddLeadText>
          <IconButton>
            <CloseIcon onClick={(e) => setActivityBox(false)} />
          </IconButton>
        </Header>

        <Form>
          <TextContainer>
            <Label for="title">Title</Label>

            <CustomTextField
              id="outlined-basic"
              variant="outlined"
              name="name"
            />
          </TextContainer>
          <BtnContainer>
            <SpanButton1
              variant="text"
              startIcon={<LocalPhoneIcon />}
              sideTab={sideTab}
              onClick={(e) => setSideTab(true)}
            >
              Call
            </SpanButton1>

            <SpanButton2
              variant="text"
              startIcon={<AccessTimeFilledIcon />}
              sideTab={sideTab}
              onClick={(e) => setSideTab(false)}
            >
              Task
            </SpanButton2>
          </BtnContainer>

          <TextContainer>
            <Label for="description">Description</Label>
            <CustomTextArea
              maxRows={4}
              aria-label="maximum height"
              name="description"
              style={{ width: "100%" }}
            />
          </TextContainer>
          <DateTimeContainer>
            <DateRangePicker />

            <TimePick>
              <LocalizationProvider dateAdapter={AdapterDateFns}>
                <TimePicker
                  label="Basic example"
                  value={value}
                  onChange={(newValue) => {
                    setValue(newValue);
                  }}
                  renderInput={(params) => <TextField {...params} />}
                />
              </LocalizationProvider>
              <LocalizationProvider dateAdapter={AdapterDateFns}>
                <TimePicker
                  label="Basic example"
                  value={value}
                  onChange={(newValue) => {
                    setValue(newValue);
                  }}
                  renderInput={(params) => <TextField {...params} />}
                />
              </LocalizationProvider>
            </TimePick>
          </DateTimeContainer>

          <DetailBlock>
            <OrganizationLabel>Organization</OrganizationLabel>

            {showSelect ? (
              <CustomeAutocomplete
                size="small"
                id="combo-box-demo"
                options={state.data}
                // getOptionLabel={(option) => option.username || ""}
                onInputChange={(event, value, reason) => {}}
                onChange={(e, v) => handleSelectChange("ReportUserID", v)}
                renderInput={(params) => <TextField size="small" {...params} />}
              />
            ) : (
              [
                <Projectname
                  onClick={() => {
                    setShowSelect(true);
                  }}
                >
                  <IconButton>
                    <DomainBtn />
                  </IconButton>
                </Projectname>,
              ]
            )}
          </DetailBlock>
        </Form>

        <ButtonsContaier>
          <CancelButton>Cancel</CancelButton>
          <SaveButton>Save</SaveButton>
        </ButtonsContaier>
      </div>
    </Container>
  );
}

export default Addactivity;
const DateTimeContainer = styled.div`
  display: flex;
  width: 100%;
  margin-top: 10px;
  align-items: center;
  gap: 10px;
`;

const DomainBtn = styled(DomainIcon)`
  && {
    font-size: 1rem !important;
  }
`;

const TimePick = styled.div`
  gap: 10px;
  display: flex;
  flex-direction: column;
  svg {
    color: black;
    margin-right: 5px;
    font-size: 1rem !important;
  }
  .css-1yq5fb3-MuiButtonBase-root-MuiIconButton-root {
    padding: unset;
  }
  &.jTVpet .css-1t8l2tu-MuiInputBase-input-MuiOutlinedInput-input {
    padding: 3.5px 7px 3.5px 11px !important;
  }
  .css-nxo287-MuiInputBase-input-MuiOutlinedInput-input {
    padding: 3.5px 7px 3.5px 11px !important;
  }
  .css-1u3bzj6-MuiFormControl-root-MuiTextField-root {
    border-color: #d4d4d4 !important;
    border-width: 1px !important;
    border-radius: 2px;
    width: 100%;
    outline: none;
  }
  .css-9ddj71-MuiInputBase-root-MuiOutlinedInput-root {
    border-color: #d4d4d4 !important;
    border-width: 1px !important;

    border-radius: 2px;
    border: none;
  }
  .css-14s5rfu-MuiFormLabel-root-MuiInputLabel-root {
    font-size: 13px;
    top: -9px !important;
    left: 0px;
  }
  .css-1sumxir-MuiFormLabel-root-MuiInputLabel-root.Mui-focused {
    color: black;
  }
  .css-o9k5xi-MuiInputBase-root-MuiOutlinedInput-root:hover
    .MuiOutlinedInput-notchedOutline {
    border-color: #d4d4d4 !important;
  }
  .css-o9k5xi-MuiInputBase-root-MuiOutlinedInput-root.Mui-focused {
    border-color: #d4d4d4 !important;
    border-width: 1px !important;
  }
  .css-1d3z3hw-MuiOutlinedInput-notchedOutline {
    border-color: #d4d4d4 !important;
    border-width: 1px !important;
    border-radius: 2px;
  }
  .css-9ddj71-MuiInputBase-root-MuiOutlinedInput-root.Mui-focused
    .MuiOutlinedInput-notchedOutline {
    border-color: #d4d4d4 !important;
    border-width: 1px !important;
    border-radius: 2px;
  }

  label[data-shrink="false"]
    + .MuiInputBase-formControl
    .css-nxo287-MuiInputBase-input-MuiOutlinedInput-input {
    padding: 3.5px 7px 3.5px 11px !important;
  }
`;
const CustomTextArea = styled(TextareaAutosize)`
  height: 60px !important;
  padding: 10px 10px;
  outline: unset !important ;
  border-color: #d4d4d4 !important;
  border-width: 1px !important;
  overflow-y: scroll !important;
  ::-webkit-scrollbar {
    display: none;
  }
`;

const BtnContainer = styled.div`
  display: flex;
  width: 100%;
  align-items: center;
  justify-content: space-between;
  margin-top: 10px;
`;
const SpanButton1 = styled(Button)`
  svg {
    font-size: 16px;
  }
  && {
    padding: 2px 50px 2px 15px;
    gap: 28px;
    display: flex;
    color: black;
    border-radius: unset !important ;
    background-color: ${({ sideTab }) => (sideTab ? "#D4EEFE" : "#E8E8E8")};

    text-transform: capitalize;
  }

  &&:hover {
    background-color: #d4eefe;
  }
  .css-1d6wzja-MuiButton-startIcon {
    margin-right: 4px !important;
  }
`;
const SpanButton2 = styled(Button)`
  svg {
    font-size: 16px;
  }
  && {
    padding: 2px 50px 2px 15px;
    gap: 28px;
    display: flex;
    color: black;
    border-radius: unset !important ;
    background-color: ${({ sideTab }) => (!sideTab ? "#D4EEFE" : "#E8E8E8")};
    text-transform: capitalize;
  }

  &&:hover {
    background-color: #d4eefe;
  }
  .css-1d6wzja-MuiButton-startIcon {
    margin-right: 4px !important;
  }
`;

const ButtonsContaier = styled.div`
  margin-top: 20px;
  display: flex;
  justify-content: space-between;
`;
const SaveButton = styled(Button)`
  && {
    background: #257d00;
    color: #fff;
    border-radius: 2px;
    padding: 5px 45px;
    text-transform: capitalize;
    &:hover {
      background: #257d00;
    }
  }
`;
const CancelButton = styled(Button)`
  && {
    background: #1e1e1e;
    color: #fff;
    border-radius: 2px;
    padding: 5px 45px;
    text-transform: capitalize;

    &:hover {
      background: #1e1e1e;
    }
  }
`;

const SearchButton = styled(Button)`
  .css-1d6wzja-MuiButton-startIcon {
    margin-right: 5px !important ;
  }
  && {
    background: rgb(255 255 255);

    color: #024987;
    border-radius: 4px;
    padding: 6px 157px 4px 12px;
    text-transform: capitalize;
    &:hover {
      background: rgb(255 255 255);
    }
  }
`;
const AddMorePlusContainer = styled.div`
  width: 100%;
`;
const AddMorContainer = styled.div`
  display: flex;
  gap: 10px;
  margin-top: 3px;
  cursor: pointer;
  color: #024987;
`;
const SelectBox1 = styled.div`
  padding-top: 30px;
  width: 48%;
  .css-1yk1gt9-MuiInputBase-root-MuiOutlinedInput-root-MuiSelect-root {
    font-size: 0.9rem !important;
  }

  .css-1869usk-MuiFormControl-root {
    width: 100% !important;
  }
  .css-1869usk-MuiFormControl-root {
    margin: unset !important;
  }
  .MuiOutlinedInput-notchedOutline {
    border-color: #d4d4d4 !important;

    border-width: 1px !important ;
    outline: unset !important;
  }

  div div div {
    padding: 6px;
  }

  em {
    font-style: normal !important;
  }
`;

const LabelContainer = styled.div`
  width: 48%;
`;
const CustomSelectContainer = styled(LabelContainer)`
  display: flex;
  align-items: end;
`;

const TextContainer = styled.div`
  margin-top: 5px;
`;
const LabelTextContainer = styled(TextContainer)`
  display: flex;
  gap: 5px;
  justify-content: space-between;
`;
const AddMoreCard = styled(LabelTextContainer)`
  /* display: ${({ addMorePhone }) => (!addMorePhone ? "none" : "")}; */
  margin: unset;
`;

const AddMoreEmail = styled(LabelTextContainer)`
  /* display: ${({ addEmail }) => (!addEmail ? "none" : "")}; */
`;
const CustomTextField = styled(TextField)`
  &.css-1u3bzj6-MuiFormControl-root-MuiTextField-root {
    width: 100% !important;
    margin-top: 5px;
  }
  .css-1t8l2tu-MuiInputBase-input-MuiOutlinedInput-input {
    padding: 3.5px 14px !important;
  }

  .css-1d3z3hw-MuiOutlinedInput-notchedOutline {
    border-color: #d4d4d4 !important;
    border-width: 1px !important;
  }
`;

const CustomSelect = styled.div`
  padding-top: 5px;
  .css-1yk1gt9-MuiInputBase-root-MuiOutlinedInput-root-MuiSelect-root {
    font-size: 0.9rem !important;
  }

  .css-1869usk-MuiFormControl-root {
    width: 100% !important;
  }
  .css-1869usk-MuiFormControl-root {
    margin: unset !important;
  }
  .MuiOutlinedInput-notchedOutline {
    border-color: #d4d4d4 !important;

    border-width: 1px !important ;
    outline: unset !important;
  }

  div div div {
    padding: 4px 10px;
  }

  em {
    font-style: normal !important;
  }
`;

const CustomeAutocomplete = styled(Autocomplete)`
  margin-top: 3px;
  /* button {
    padding: 0px;
  } */
  .css-19qh8xo-MuiInputBase-input-MuiOutlinedInput-input {
    height: 1rem !important;
  }
  && {
    .css-1d3z3hw-MuiOutlinedInput-notchedOutline {
      border-color: #d4d4d4 !important;
      border-width: 1px !important;
    }
  }
  &.css-1auycx3-MuiAutocomplete-root
    .MuiOutlinedInput-root.MuiInputBase-sizeSmall {
    padding: 4px !important;
  }
`;
const Label = styled.label`
  font-size: 12px;
  margin-top: 15px; ;
`;
const DetailBlock = styled.div`
  width: 100%;
  margin-top: 10px;
`;
const OrganizationLabel = styled.p`
  width: 100px;
  font-size: 12px;
  cursor: pointer;
`;
const Projectname = styled(OrganizationLabel)`
  border: 1px solid #d8d8d8;
  border-radius: 2px;
  width: 100%;
  height: 30px;
  display: flex;
  align-items: center;
  margin-top: 5px;
  .css-78trlr-MuiButtonBase-root-MuiIconButton-root {
    padding: 4px !important ;
  }
`;
const Form = styled.form`
  overflow-y: scroll;

  /* margin-top: 20px; */
  ::-webkit-scrollbar {
    display: none;
  }
`;
const AddLeadText = styled.h4`
  font-size: 18px;
`;
const Header = styled.div`
  display: flex;
  align-items: center;
  justify-content: space-between;
`;
const Container = styled.div`
  z-index: 1;
  padding: 15px;
  width: 316px;

  box-shadow: 0px 2px 1px -1px rgb(0 0 0 / 20%),
    0px 1px 1px 0px rgb(0 0 0 / 14%), 0px 1px 3px 0px rgb(0 0 0 / 12%);
  position: absolute;
  border-radius: 2px;
  right: 22px;
  top: 131px;
  background: white;

  display: ${({ activityBox }) => (!activityBox ? "none" : "")};
`;
