import { Menu, Button } from "@mui/material";
import React, { useState } from "react";
import styled from "styled-components/macro";
import AccessTimeFilledIcon from "@mui/icons-material/AccessTimeFilled";
import MenuItem from "@mui/material/MenuItem";
import IconButton from "@mui/material/IconButton";

import MoreVertIcon from "@mui/icons-material/MoreVert";
import FilterBox from "../../Components/FilterBox";
import AddIcon from "@mui/icons-material/Add";
import LocalPhoneIcon from "@mui/icons-material/LocalPhone";

import ActivityTable from "./ActivityTable";
import Addactivity from "./Addactivity";

function Activity() {
  const [age, setAge] = useState("");
  const [allBtn, setAllBtn] = useState(false);
  const [activityBox, setActivityBox] = useState(false);
  const handleChange = (event) => {
    setAge(event.target.value);
  };
  const [buttonColor, setButtonColor] = useState("");
  const [anchorEl, setAnchorEl] = useState(null);
  const [active, setActive] = useState("todo");
  const open = Boolean(anchorEl);
  const handleClick = (event) => {
    setAnchorEl(event.currentTarget);
  };
  const handleClose = () => {
    setAnchorEl(null);
  };
  const options = [
    "None",
    "Atria",
    "Callisto",
    "Dione",
    "Ganymede",
    "Hangouts Call",
    "Luna",

    "Umbriel",
  ];
  const ITEM_HEIGHT = 48;
  const ActiveClass = () => {
    setAllBtn(!allBtn);
  };
  return (
    <Container>
      <Heading>
        <ActivityTxt>Activities</ActivityTxt>

        <LeftContainer>
          <FilterBox label={"filter"} />
          <SearchButton
            startIcon={<AddIcon />}
            onClick={(e) => {
              setActivityBox(true);
            }}
          >
            Activity
          </SearchButton>

          <MenuIconContainer>
            <IconButton
              aria-label="more"
              id="long-button"
              aria-controls={open ? "long-menu" : undefined}
              aria-expanded={open ? "true" : undefined}
              aria-haspopup="true"
              onClick={handleClick}
            >
              <MoreVertIcon />
            </IconButton>
            <Menus
              disableScrollLock={true}
              id="long-menu"
              MenuListProps={{
                "aria-labelledby": "long-button",
              }}
              anchorEl={anchorEl}
              open={open}
              onClose={handleClose}
              PaperProps={{
                style: {
                  maxHeight: ITEM_HEIGHT * 4.5,
                  width: "20ch",
                },
              }}
            >
              {options.map((option) => (
                <MenuItem
                  key={option}
                  selected={option === "Pyxis"}
                  onClick={handleClose}
                >
                  {option}
                </MenuItem>
              ))}
            </Menus>
          </MenuIconContainer>
        </LeftContainer>
      </Heading>
      <Header>
        <LeftButtonsContainer>
          <AllButton>
            <AllButton1 variant="text" onClick={ActiveClass}>
              All
            </AllButton1>
          </AllButton>
          <SpanButton__Time
            allBtn={allBtn}
            variant="text"
            startIcon={<LocalPhoneIcon />}
          >
            Call
          </SpanButton__Time>
          <SpanButton__Time
            variant="text"
            allBtn={allBtn}
            startIcon={<AccessTimeFilledIcon />}
          >
            Task
          </SpanButton__Time>
        </LeftButtonsContainer>

        <RightButtonContainer>
          <SpanButton
            variant="text"
            onClick={() => setActive("todo")}
            name={"todo"}
            active={active}
          >
            To Do
          </SpanButton>
          <SpanButton
            variant="text"
            name={"over_due"}
            active={active}
            onClick={() => setActive("over_due")}
          >
            Over Due
          </SpanButton>
          <SpanButton
            variant="text"
            name={"today"}
            onClick={() => setActive("today")}
            active={active}
          >
            Today
          </SpanButton>
          <SpanButton
            variant="text"
            name={"tomorrow"}
            onClick={() => setActive("tomorrow")}
            active={active}
          >
            Tommorrow
          </SpanButton>
          <SpanButton
            variant="text"
            name={"this_week"}
            onClick={() => setActive("this_week")}
            active={active}
          >
            This Week
          </SpanButton>
          <SpanButton
            variant="text"
            name={"next_week"}
            onClick={() => setActive("next_week")}
            active={active}
          >
            Next Week
          </SpanButton>
          <SpanButton
            variant="text"
            name={"custom"}
            onClick={() => setActive("custom")}
            active={active}
          >
            Custom
          </SpanButton>
        </RightButtonContainer>
      </Header>
      <TableContainer>
        <ActivityTable />
      </TableContainer>

      <Addactivity activityBox={activityBox} setActivityBox={setActivityBox} />
    </Container>
  );
}

export default Activity;

const AllButton1 = styled(Button)`
  .css-1e6y48t-MuiButtonBase-root-MuiButton-root {
    font-family: "Poppins", sans-serif !important;
    font: none !important;
  }
  && {
    padding: unset;
    color: black;

    text-transform: capitalize;
  }

  &&.active {
    background-color: white;
  }
`;
const AllButton = styled.div`
  border-right: 1px solid black;
  padding-right: 10px;
`;
const LeftButtonsContainer = styled.div`
  display: flex;
  align-items: center;
  gap: 10px;
`;

const RightButtonContainer = styled.div`
  display: flex;
  align-items: center;
  gap: 10px;
`;

const SpanButton__Time = styled(Button)`
  svg {
    font-size: 16px;
  }
  && {
    padding: 0px 10px;
    color: black;
    background-color: ${({ allBtn }) => (allBtn ? "#d4eefe" : "white")};
    text-transform: capitalize;
  }

  &&:hover {
    background-color: white;
  }
  .css-1d6wzja-MuiButton-startIcon {
    margin-right: 4px !important;
  }
`;
const SpanButton = styled(Button)`
  svg {
    font-size: 16px;
  }
  && {
    padding: 0px 10px;
    color: black;
    background-color: ${({ name, active }) =>
      name === active ? "#d4eefe" : "white"};
    text-transform: capitalize;
  }

  &&:hover {
    background-color: white;
  }
  .css-1d6wzja-MuiButton-startIcon {
    margin-right: 4px !important;
  }
`;

const SearchButton = styled(Button)`
  .css-1d6wzja-MuiButton-startIcon {
    margin-right: 5px !important ;

    font-family: "Popins", sans-serif;
  }
  && {
    background: #257d00;
    color: #fff;
    border-radius: 4px;
    padding: 5px 15px 5px 12px;
    text-transform: capitalize;
    &:hover {
      background: #009e15;
    }
  }
`;

const TableContainer = styled.div`
  margin-top: 10px;
`;

const LeftContainer = styled.div`
  display: flex;
  gap: 8px;
`;
const Header = styled.div`
  display: flex;
  width: 100%;
  margin-top: 20px;
  justify-content: space-between;
`;

const Menus = styled(Menu)`
  .css-1poimk-MuiPaper-root-MuiMenu-paper-MuiPaper-root-MuiPopover-paper {
    ::-webkit-scrollbar {
      display: none;
    }
  }
`;
const MenuIconContainer = styled.div`
  svg {
    font-size: 1.1rem !important ;
    color: black !important;

    transform: rotate(90deg);
    border: 1px solid #aeaeae;
    border-radius: 4px;

    width: 36px;
    height: 38px;
  }
  /* .css-78trlr-MuiButtonBase-root-MuiIconButton-root {
    border-radius: unset !important ;
  } */
  .css-78trlr-MuiButtonBase-root-MuiIconButton-root {
    padding: unset !important;
    border-radius: unset !important ;
  }
`;
const SelectBox1 = styled.div`
  position: relative;
  .css-1869usk-MuiFormControl-root {
    min-width: 299px !important;
    margin: 0px 8px !important;
  }
  .MuiOutlinedInput-notchedOutline {
    border-color: #d4d4d4 !important;
    border-width: 1px !important ;
    outline: unset !important;
  }

  div div div {
    padding: 6px;
  }

  em {
    font-style: normal !important;
  }
`;
const Container = styled.div``;
const Heading = styled.div`
  width: 100%;
  display: flex;
  justify-content: space-between;
`;
const ActivityTxt = styled.h2`
  font-size: 25px;
  letter-spacing: 1px; ;
`;
