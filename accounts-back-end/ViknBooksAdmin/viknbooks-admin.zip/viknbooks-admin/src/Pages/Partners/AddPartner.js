import React from "react";
import styled from "styled-components/macro";
import CloseIcon from "@mui/icons-material/Close";
import { Menu, Button } from "@mui/material";
import IconButton from "@mui/material/IconButton";
import TextField from "@mui/material/TextField";
import { useState } from "react";
import DomainIcon from "@mui/icons-material/Domain";
import Box from "@mui/material/Box";
import AddIcon from "@mui/icons-material/Add";
import InputLabel from "@mui/material/InputLabel";
import MenuItem from "@mui/material/MenuItem";
import FormControl from "@mui/material/FormControl";
import Select from "@mui/material/Select";
import TextareaAutosize from "@mui/material/TextareaAutosize";
import { Autocomplete } from "@mui/material";
import { SnackbarProvider } from "notistack";

function AddPartner({ addPopup, setAddPopup }) {
  const [age, setAge] = useState("");
  const [addMorePhone, setAddMorePhone] = useState(false);
  const [addEmail, setAddEmail] = useState(false);
  const handleChange = (event) => {
    setAge(event.target.value);
  };
  const [showSelect, setShowSelect] = useState(false);
  const [state, setState] = useState({
    data: ["jasmal", "uvais ", "Abhi"],
    Projectlsd: [],
    ProjeID: "",
    contact_data: [
      {
        phone: "",
        work: "",
      },
    ],

    contact_email: [
      {
        email: "",
        work: "",
      },
    ],
  });
  const handleSelectChange = () => {
    console.log("select");
  };

  const addContactData = () => {
    let contact_data = [...state.contact_data];
    contact_data.push({
      phone: "",
      work: "",
    });
    setState({
      ...state,
      contact_data,
    });
  };

  const AddContactMail = () => {
    let contact_email = [...state.contact_email];
    contact_email.push({
      email: "",
      work: "",
    });

    setState({ ...state, contact_email });
  };
  return (
    <Container addpopup={addPopup}>
      <div>
        <Header>
          <AddLeadText>Add Partner</AddLeadText>
          <IconButton>
            <CloseIcon onClick={(e) => setAddPopup(false)} />
          </IconButton>
        </Header>

        <Form>
          <DetailBlock>
            <TextContainer>
              <Label for="name">Name</Label>

              <CustomTextField id="outlined-basic" variant="outlined" />
            </TextContainer>
          </DetailBlock>

          <TextContainer>
            <Label for="phone">Phone</Label>

            <CustomTextField id="outlined-basic" variant="outlined" />
          </TextContainer>

          <TextContainer>
            <Label for="email">Email</Label>

            <CustomTextField id="outlined-basic" variant="outlined" />
          </TextContainer>

          <LabelTextContainer>
            <LabelContainer>
              <Label for="lname">Address</Label>

              <CustomTextArea
                maxRows={4}
                aria-label="maximum height"
                style={{ width: "100%" }}
              />
            </LabelContainer>
          </LabelTextContainer>

          <TextContainer>
            <Label for="username">Username</Label>

            <CustomTextField id="outlined-basic" variant="outlined" />
          </TextContainer>

          <TextContainer>
            <Label for="password">Password</Label>

            <CustomTextField
              id="outlined-basic"
              variant="outlined"
              type="password"
            />
          </TextContainer>

          {/* Add mail================================================ */}
        </Form>

        <ButtonsContaier>
          <SaveButton onClick={(e) => setAddPopup(false)}>Save</SaveButton>
        </ButtonsContaier>
      </div>
    </Container>
  );
}

export default AddPartner;
const CustomTextArea = styled(TextareaAutosize)`
  height: 60px !important;
  padding: 10px 10px;
  overflow-y: scroll !important;
  outline: unset !important;
  border: unset !important;
  background-color: #e9e9e9 !important;
  background-color: #e9e9e9 !important ;
  ::-webkit-scrollbar {
    display: none;
  }
`;

const ButtonsContaier = styled.div`
  margin-top: 10px;
  display: flex;
  justify-content: space-between;
`;
const SaveButton = styled(Button)`
  && {
    background: #009e15;
    color: #fff;
    width: 100%;
    border-radius: 2px;
    padding: 5px 45px;
    text-transform: capitalize;
    &:hover {
      background: #009e15;
    }
  }
`;
const CancelButton = styled(Button)`
  && {
    background: #1e1e1e;
    color: #fff;
    border-radius: 2px;
    padding: 5px 45px;
    text-transform: capitalize;

    &:hover {
      background: #1e1e1e;
    }
  }
`;

const SearchButton = styled(Button)`
  .css-1d6wzja-MuiButton-startIcon {
    margin-right: 5px !important ;
  }
  && {
    background: rgb(255 255 255);

    color: #024987;
    border-radius: 4px;
    padding: 6px 157px 4px 12px;
    text-transform: capitalize;
    &:hover {
      background: rgb(255 255 255);
    }
  }
`;
const AddMorePlusContainer = styled.div`
  width: 100%;
`;
const AddMorContainer = styled.div`
  display: flex;
  gap: 10px;
  margin-top: 3px;
  cursor: pointer;
  color: #024987;
`;
const SelectBox1 = styled.div`
  padding-top: 30px;
  width: 48%;
  .css-1yk1gt9-MuiInputBase-root-MuiOutlinedInput-root-MuiSelect-root {
    font-size: 0.9rem !important;
  }

  .css-1869usk-MuiFormControl-root {
    width: 100% !important;
  }
  .css-1869usk-MuiFormControl-root {
    margin: unset !important;
  }
  .MuiOutlinedInput-notchedOutline {
    border-color: #d4d4d4 !important;

    border-width: 1px !important ;
    outline: unset !important;
  }

  div div div {
    padding: 6px;
  }

  em {
    font-style: normal !important;
  }
`;

const LabelContainer = styled.div`
  width: 100%;
`;
const CustomSelectContainer = styled(LabelContainer)`
  display: flex;
  align-items: end;
`;

const TextContainer = styled.div`
  margin-top: 5px;
`;
const LabelTextContainer = styled(TextContainer)`
  display: flex;
  gap: 5px;
  justify-content: space-between;
`;
const AddMoreCard = styled(LabelTextContainer)`
  /* display: ${({ addMorePhone }) => (!addMorePhone ? "none" : "")}; */
  margin: unset;
`;

const AddMoreEmail = styled(LabelTextContainer)`
  /* display: ${({ addEmail }) => (!addEmail ? "none" : "")}; */
`;
const CustomTextField = styled(TextField)`
  background-color: #e9e9e9 !important ;
  border: unset !important;
  outline: unset !important;
  &.css-1u3bzj6-MuiFormControl-root-MuiTextField-root {
    width: 100% !important;
    margin-top: 5px;
  }
  .css-1t8l2tu-MuiInputBase-input-MuiOutlinedInput-input {
    padding: 3.5px 14px !important;
  }
  .css-1d3z3hw-MuiOutlinedInput-notchedOutline {
    border: none !important;
  }
`;

const CustomSelect = styled.div`
  padding-top: 5px;
  .css-1yk1gt9-MuiInputBase-root-MuiOutlinedInput-root-MuiSelect-root {
    font-size: 0.9rem !important;
  }

  .css-1869usk-MuiFormControl-root {
    width: 100% !important;
  }
  .css-1869usk-MuiFormControl-root {
    margin: unset !important;
  }
  .MuiOutlinedInput-notchedOutline {
    border-color: #d4d4d4 !important;

    border-width: 1px !important ;
    outline: unset !important;
  }

  div div div {
    padding: 6px;
  }

  em {
    font-style: normal !important;
  }
`;

const CustomeAutocomplete = styled(Autocomplete)`
  margin-top: 3px;
  button {
    padding: 0;
  }
  .css-19qh8xo-MuiInputBase-input-MuiOutlinedInput-input {
    height: 1rem !important;
  }
`;
const Label = styled.label`
  font-size: 12px;
  margin-top: 15px; ;
`;
const DetailBlock = styled.div`
  width: 100%;
`;
const OrganizationLabel = styled.p`
  width: 100px;
  font-size: 15px;
  cursor: pointer;
`;
const Projectname = styled(OrganizationLabel)`
  border: 1px solid #d8d8d8;
  border-radius: 2px;
  width: 100%;
  margin-top: 5px;
  .css-78trlr-MuiButtonBase-root-MuiIconButton-root {
    padding: 4px !important ;
  }
`;
const Form = styled.form``;
const AddLeadText = styled.h4`
  font-size: 18px;
`;
const Header = styled.div`
  display: flex;
  align-items: center;
  justify-content: space-between;
`;
const Container = styled.div`
  z-index: 1;
  padding: 15px;
  width: 316px;

  box-shadow: 0px 2px 1px -1px rgb(0 0 0 / 20%),
    0px 1px 1px 0px rgb(0 0 0 / 14%), 0px 1px 3px 0px rgb(0 0 0 / 12%);
  position: absolute;
  border-radius: 2px;
  right: 22px;
  top: 138px;
  background: white;

  display: ${({ addpopup }) => (!addpopup ? "none" : "")};
`;
