import React, { useRef, useState, useEffect } from "react";
import styled from "styled-components/macro";
import {
  Autocomplete,
  Button,
  FormControl,
  MenuItem,
  Select,
  TextareaAutosize,
  TextField,
} from "@mui/material";

import EditIcon from "@mui/icons-material/Edit";
import DatePicker from "../../Components/DatePicker";

import IndividualList from "./IndividualList";
function PartnerDetails() {
  const [state, setState] = useState({
    data: ["uvais", "jasmal", "abhi"],
  });

  const [showBox, setShowBox] = useState({
    nameTxt: false,
    phoneTxt: false,
    emailTxt: false,
    addressTxt: false,
  });

  const [partnerData, setPartnerData] = useState({
    name: "",
    email: "",
    phone: "",
    address: "",
  });

  const handleSelectChange = () => {
    console.log("select");
  };
  const [age, setAge] = useState("");
  const handleChange = (event) => {
    setAge(event.target.value);
  };

  const TextRead = () => {
    // setValues({ ...values, [prop]: event.target.value });
  };

  const [values, setValues] = useState({
    name: "",
  });

  const handleMouseDownPassword = (event) => {
    event.preventDefault();
  };

  const ReadAllDetails = (e) => {
    console.log(e.target.name);
    setPartnerData({
      ...partnerData,
      [e.target.name]: e.target.value,
    });
  };

  // outside click
  function useOutsideAlerter(ref) {
    useEffect(() => {
      /**
       * Alert if clicked on outside of element
       */
      function handleClickOutside(event) {
        if (ref.current && !ref.current.contains(event.target)) {
          setShowBox(false);
          // setOption(false);
          // alert("You clicked outside of me!");
        }
      }

      // Bind the event listener
      document.addEventListener("mousedown", handleClickOutside);
      return () => {
        // Unbind the event listener on clean up
        document.removeEventListener("mousedown", handleClickOutside);
      };
    }, [ref]);
  }

  const wrapperRef = useRef(null);
  useOutsideAlerter(wrapperRef);

  return (
    <Container>
      <Heading>
        <LeftContainer ref={wrapperRef}>
          <PartnerTxt>Partner Details</PartnerTxt>

          <EditableContainer>
            <MainContainer>
              <SubContainer>
                <LabelTxt>Name</LabelTxt>

                {!showBox.nameTxt ? (
                  <Field1>
                    <EditContainer
                      onClick={() =>
                        setShowBox({ ...showBox, nameTxt: !showBox.nameTxt })
                      }
                    >
                      <NameTxt>Uvais T</NameTxt>

                      <EditIcon />
                    </EditContainer>
                  </Field1>
                ) : (
                  <Field1>
                    <TextField
                      id="outlined-basic"
                      placeholder="Name"
                      variant="outlined"
                      onChange={ReadAllDetails}
                      name="name"
                      style={{ width: "100%" }}
                    />
                  </Field1>
                )}
              </SubContainer>
              <SubContainer>
                <LabelTxt>Phone</LabelTxt>

                {!showBox.phoneTxt ? (
                  <Field1>
                    <EditContainer
                      onClick={() => {
                        setShowBox({ ...showBox, phoneTxt: !showBox.phoneTxt });
                      }}
                    >
                      <NameTxt>9876543212</NameTxt>

                      <EditIcon />
                    </EditContainer>
                  </Field1>
                ) : (
                  <Field1>
                    <TextField
                      id="outlined-basic"
                      placeholder="Phone"
                      variant="outlined"
                      name="phone"
                      onChange={ReadAllDetails}
                      style={{ width: "100%" }}
                    />
                  </Field1>
                )}
              </SubContainer>

              <SubContainer>
                <LabelTxt>Email</LabelTxt>

                {!showBox.emailTxt ? (
                  <Field1>
                    <EditContainer
                      onClick={() =>
                        setShowBox({ ...showBox, emailTxt: !showBox.emailTxt })
                      }
                    >
                      <AddressTxt>uvais@gmail.com</AddressTxt>

                      <EditIcon />
                    </EditContainer>
                  </Field1>
                ) : (
                  <Field1>
                    <TextField
                      id="outlined-basic"
                      type="email"
                      placeholder="Email Address"
                      onChange={ReadAllDetails}
                      variant="outlined"
                      name="email"
                      style={{ width: "100%" }}
                    />
                  </Field1>
                )}
              </SubContainer>
              <SubContainer>
                <LabelTxt>Address</LabelTxt>

                {!showBox.addressTxt ? (
                  <Field1>
                    <EditContainer
                      onClick={() =>
                        setShowBox({
                          ...showBox,
                          addressTxt: !showBox.addressTxt,
                        })
                      }
                    >
                      <AddressTxt>qqwweewereewuuuruew</AddressTxt>

                      <EditIcon />
                    </EditContainer>
                  </Field1>
                ) : (
                  <Field1>
                    <CustomTextArea
                      onChange={ReadAllDetails}
                      maxRows={4}
                      aria-label="maximum height"
                      style={{ width: "100%" }}
                      name="address"
                    />
                  </Field1>
                )}
              </SubContainer>
            </MainContainer>
          </EditableContainer>
        </LeftContainer>

        <Right>
          <BoxContainer>
            <InvoiceTxt>Invoice</InvoiceTxt>
            <DatePicker />

            <CustomeAutocomplete
              size="small"
              id="combo-box-demo"
              options={state.data}
              // getOptionLabel={(option) => option.username || ""}
              onInputChange={(event, value, reason) => {}}
              onChange={(e, v) => handleSelectChange("ReportUserID", v)}
              renderInput={(params) => (
                <TextField size="small" {...params} label="Organization" />
              )}
            />

            <CustomeAutocomplete
              size="small"
              id="combo-box-demo"
              options={state.data}
              // getOptionLabel={(option) => option.username || ""}
              onInputChange={(event, value, reason) => {}}
              onChange={(e, v) => handleSelectChange("ReportUserID", v)}
              renderInput={(params) => (
                <TextField size="small" {...params} label="Application" />
              )}
            />

            <SelectBox1>
              <FormControl sx={{ m: 1, minWidth: 120 }}>
                <Select
                  value={age}
                  onChange={handleChange}
                  displayEmpty
                  MenuProps={{ disableScrollLock: true }}
                  style={{ fontSize: "13px" }}
                >
                  <MenuItem value="" disabled style={{ fontSize: "13px" }}>
                    Status
                  </MenuItem>
                  <MenuItem style={{ fontSize: "13px" }} value={10}>
                    Ten
                  </MenuItem>
                  <MenuItem style={{ fontSize: "13px" }} value={20}>
                    Twenty
                  </MenuItem>
                  <MenuItem style={{ fontSize: "13px" }} value={30}>
                    Thirty
                  </MenuItem>
                </Select>
              </FormControl>
            </SelectBox1>
            <SearchButton>Search</SearchButton>
          </BoxContainer>

          <div>
            <IndividualList />
          </div>
        </Right>
      </Heading>
    </Container>
  );
}

export default PartnerDetails;

const CustomTextArea = styled(TextareaAutosize)`
  .css-1t8l2tu-MuiInputBase-input-MuiOutlinedInput-input {
    font: unset !important ;
  }
  height: 41px !important;
  overflow: unset !important ;
  padding: 10px 10px;
  font: unset !important;
  border-color: #d4d4d4 !important;
  outline: unset !important ;
  border-radius: 4px !important ;
  font-family: unset !important;
  background-color: transparent !important ;
  ::-webkit-scrollbar {
    display: none;
  }
  ::placeholder {
    color: #a2a2a2 !important;
    font-size: 17px;
    font-family: "Franklin Gothic Medium", "Arial Narrow", Arial, sans-serif;
  }
`;
const EditContainer = styled(Button)`
  && {
    background: rgba(0, 0, 0, 0.04) !important;
    margin-top: 5px;
    padding: 10px;
    color: black !important;
    text-transform: unset !important;
    width: 100%;
    justify-content: left;
    border-radius: 2px;

    display: flex;
    justify-content: space-between;
    padding: 1px 12px;
    align-items: center;
    border-radius: 4px;
    height: 41px;

    /* border: 1px solid #d4d4d4; */
    svg {
      margin-right: 5px;
      color: #787878 !important;
    }
  }
`;
const NameTxt = styled.span`
  font-size: 15px;
`;

const AddressTxt = styled(NameTxt)`
  text-overflow: ellipsis;
  overflow: hidden;
  width: 150px;
`;

const LabelTxt = styled.label`
  font-size: 12px;
  color: #767676;
  width: 100%;
  padding-left: 10px; ;
`;

const SubContainer = styled.div`
  width: 100%;
  .css-14s5rfu-MuiFormLabel-root-MuiInputLabel-root {
    top: -6 !important;
  }

  input {
    padding: 8.5px 14px !important;
  }

  .css-1d3z3hw-MuiOutlinedInput-notchedOutline {
    outline: unset !important ;
    /* border: unset !important; */
    border-color: #d4d4d4 !important;
    border-width: 1px !important;
  }
`;

const MainContainer = styled.div`
  background-color: #f3f3f3;
  padding: 22px 10px 0px 10px;
  height: 90vh;
  display: flex;
  flex-direction: column;
  align-items: center;
`;
const EditableContainer = styled.div`
  margin-top: 13px;

  padding-right: 15px;
`;

const Container = styled.div``;

const Right = styled.div`
  width: 75%;
`;
const Heading = styled.div`
  width: 100%;
  display: flex;
  justify-content: space-between;
`;
const LeftContainer = styled.div`
  display: flex;
  flex-direction: column;
  width: 25%;
`;
const PartnerTxt = styled.h2`
  font-size: 27px;
  letter-spacing: 1px; ;
`;
const InvoiceTxt = styled(PartnerTxt)`
  font-size: 25px !important;
`;
const BoxContainer = styled.div`
  .css-1auycx3-MuiAutocomplete-root
    .MuiOutlinedInput-root.MuiInputBase-sizeSmall {
    padding: 7.5px !important;
  }

  .css-1auycx3-MuiAutocomplete-root
    .MuiOutlinedInput-root.MuiInputBase-sizeSmall
    .MuiAutocomplete-input {
    padding: unset !important ;
  }

  .css-1sumxir-MuiFormLabel-root-MuiInputLabel-root {
    color: rgba(0, 0, 0, 0.6) !important;
  }
  .css-1pysi21-MuiFormLabel-root-MuiInputLabel-root {
    top: -2px !important;
    font-size: 13px;
  }
  .css-1auycx3-MuiAutocomplete-root
    .MuiOutlinedInput-root.MuiInputBase-sizeSmall {
    width: 138px;
    @media (min-width: 1920px) {
      width: 210px;
    }
    @media (min-width: 1800px) {
      width: 200px;
    }
  }
  display: flex;
  align-items: center;
  justify-content: space-between;
`;

const CustomeAutocomplete = styled(Autocomplete)`
  && {
    margin-top: unset !important;
  }
  .css-1d3z3hw-MuiOutlinedInput-notchedOutline {
    outline: unset !important ;
    border-color: #d4d4d4 !important;
    border-width: 1px !important;
  }
  margin-top: 3px;
  button {
    padding: 0;
  }
  .css-19qh8xo-MuiInputBase-input-MuiOutlinedInput-input {
    height: 1rem !important;
  }
`;
const Field1 = styled.div`
  margin: 8px;
`;

const SearchButton = styled(Button)`
  && {
    background: #009e15;
    color: #fff;
    border-radius: 4px;
    padding: 3px 28px;
    text-transform: capitalize;
    @media (min-width: 1920px) {
      width: 160px;
    }

    @media (min-width: 1800px) {
      width: 160px;
    }
    &:hover {
      background: #009e15;
    }
  }
`;
const SelectBox1 = styled.div`
  .css-1869usk-MuiFormControl-root {
    min-width: 138px !important;
    margin: unset !important;
    @media (min-width: 1920px) {
      width: 210px;
    }

    @media (width: 1800px) {
      width: 200px;
    }
  }
  .MuiOutlinedInput-notchedOutline {
    border-color: #d4d4d4 !important;
    border-width: 1px !important ;
    outline: unset !important;
  }

  div div div {
    padding: 6px;
  }

  &.css-kk1bwy-MuiButtonBase-root-MuiMenuItem-root {
    font-size: 12px !important;
  }

  .css-11u53oe-MuiSelect-select-MuiInputBase-input-MuiOutlinedInput-input.css-11u53oe-MuiSelect-select-MuiInputBase-input-MuiOutlinedInput-input.css-11u53oe-MuiSelect-select-MuiInputBase-input-MuiOutlinedInput-input {
    padding-left: 12px !important;
  }
`;
