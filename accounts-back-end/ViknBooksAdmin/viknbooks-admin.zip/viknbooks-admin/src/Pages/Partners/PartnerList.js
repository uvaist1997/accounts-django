import React, { useState } from "react";
import styled from "styled-components/macro";

import { IconButton, Menu, MenuItem, TableSortLabel } from "@mui/material";
import { useNavigate } from "react-router-dom";
import MoreVertIcon from "@mui/icons-material/MoreVert";
import Pagination from "@mui/material/Pagination";
function PartnerList() {
  const navigate = useNavigate();
  const options = ["Edit", "Delete", "View"];
  const [anchorEl, setAnchorEl] = useState(null);
  const open = Boolean(anchorEl);

  const [currentIndex, setCurrentIndex] = useState();
  const handleClick = (index) => (event) => {
    setAnchorEl(event.currentTarget);
    setCurrentIndex(index);
  };
  const handleClose = () => {
    setAnchorEl(null);
  };
  const ITEM_HEIGHT = 48;

  const [partnersList, setPartnersList] = useState({
    data: [
      {
        slno: "1",
        name: "uvais T ",
        phone: "admin",
        emailaddress: "uvais@gmail.com",
        address: "Invitation send",
      },
      {
        slno: "2",
        name: "jasmal",
        phone: "987654212",
        emailaddress: "uvais@gmail.com",
        address: "qweerttyu",
      },
      {
        slno: "3",
        name: "abhi",
        phone: "admin",
        emailaddress: "uvais@gmail.com",
        address: "zxczczcz",
      },
      {
        slno: "4",
        name: "abhi",
        phone: "admin",
        emailaddress: "uvais@gmail.com",
        address: "zxczczcz",
      },
      {
        slno: "5",
        name: "abhi",
        phone: "admin",
        emailaddress: "uvais@gmail.com",
        address: "zxczczcz",
      },
      {
        slno: "6",
        name: "abhi",
        phone: "admin",
        emailaddress: "uvais@gmail.com",
        address: "zxczczcz",
      },
      {
        slno: "7",
        name: "abhi",
        phone: "admin",
        emailaddress: "uvais@gmail.com",
        address: "zxczczcz",
      },
      {
        slno: "8",
        name: "abhi",
        phone: "admin",
        emailaddress: "uvais@gmail.com",
        address: "zxczczcz",
      },
      {
        slno: "9",
        name: "abhi",
        phone: "admin",
        emailaddress: "uvais@gmail.com",
        address: "zxczczcz",
      },
      {
        slno: "10",
        name: "abhi",
        phone: "admin",
        emailaddress: "uvais@gmail.com",
        address: "zxczczcz",
      },
      {
        slno: "11",
        name: "abhi",
        phone: "admin",
        emailaddress: "uvais@gmail.com",
        address: "zxczczcz",
      },
      {
        slno: "12",
        name: "abhi",
        phone: "admin",
        emailaddress: "uvais@gmail.com",
        address: "zxczczcz",
      },
      {
        slno: "13",
        name: "abhi",
        phone: "admin",
        emailaddress: "uvais@gmail.com",
        address: "zxczczcz",
      },
      {
        slno: "14",
        name: "abhi",
        phone: "admin",
        emailaddress: "uvais@gmail.com",
        address: "zxczczcz",
      },
      {
        slno: "15",
        name: "abhi",
        phone: "admin",
        emailaddress: "uvais@gmail.com",
        address: "zxczczcz",
      },
      {
        slno: "16",
        name: "abhi",
        phone: "admin",
        emailaddress: "uvais@gmail.com",
        address: "zxczczcz",
      },
      {
        slno: "17",
        name: "abhi",
        phone: "admin",
        emailaddress: "uvais@gmail.com",
        address: "zxczczcz",
      },
      {
        slno: "18",
        name: "abhi",
        phone: "admin",
        emailaddress: "uvais@gmail.com",
        address: "zxczczcz",
      },
      {
        slno: "19",
        name: "abhi",
        phone: "admin",
        emailaddress: "uvais@gmail.com",
        address: "zxczczcz",
      },
      {
        slno: "20",
        name: "abhi",
        phone: "admin",
        emailaddress: "uvais@gmail.com",
        address: "zxczczcz",
      },
      {
        slno: "21",
        name: "abhi",
        phone: "admin",
        emailaddress: "uvais@gmail.com",
        address: "zxczczcz",
      },
      {
        slno: "22",
        name: "abhi",
        phone: "admin",
        emailaddress: "uvais@gmail.com",
        address: "zxczczcz",
      },
      {
        slno: "23",
        name: "abhi",
        phone: "admin",
        emailaddress: "uvais@gmail.com",
        address: "zxczczcz",
      },
      {
        slno: "24",
        name: "abhi",
        phone: "admin",
        emailaddress: "uvais@gmail.com",
        address: "zxczczcz",
      },
      {
        slno: "3",
        name: "abhi",
        phone: "admin",
        emailaddress: "uvais@gmail.com",
        address: "zxczczcz",
      },
      {
        slno: "25",
        name: "abhi",
        phone: "admin",
        emailaddress: "uvais@gmail.com",
        address: "zxczczcz",
      },
      {
        slno: "26",
        name: "abhi",
        phone: "admin",
        emailaddress: "uvais@gmail.com",
        address: "zxczczcz",
      },
      {
        slno: "27",
        name: "abhi",
        phone: "admin",
        emailaddress: "uvais@gmail.com",
        address: "zxczczcz",
      },
      {
        slno: "28",
        name: "abhi",
        phone: "admin",
        emailaddress: "uvais@gmail.com",
        address: "zxczczcz",
      },
      {
        slno: "29",
        name: "abhi",
        phone: "admin",
        emailaddress: "uvais@gmail.com",
        address: "zxczczcz",
      },
      {
        slno: "30",
        name: "abhi",
        phone: "admin",
        emailaddress: "uvais@gmail.com",
        address: "zxczczcz",
      },
      {
        slno: "31",
        name: "abhi",
        phone: "admin",
        emailaddress: "uvais@gmail.com",
        address: "zxczczcz",
      },
      {
        slno: "32",
        name: "abhi",
        phone: "admin",
        emailaddress: "uvais@gmail.com",
        address: "zxczczcz",
      },
      {
        slno: "33",
        name: "abhi",
        phone: "admin",
        emailaddress: "uvais@gmail.com",
        address: "zxczczcz",
      },
      {
        slno: "34",
        name: "abhi",
        phone: "admin",
        emailaddress: "uvais@gmail.com",
        address: "zxczczcz",
      },
    ],
  });

  //pagination=======================================

  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage, setItemsPerPage] = useState(18);

  const IndexofLastItem = currentPage * itemsPerPage;
  const indexOfFirstDish = IndexofLastItem - itemsPerPage;
  let PaginatedData = partnersList.data.slice(
    indexOfFirstDish,
    IndexofLastItem
  );
  console.log("page", PaginatedData);

  const ChangePage = (event, value) => {
    setCurrentPage(value);
  };

  const NumOfpages = Math.ceil(partnersList.data.length / itemsPerPage);
  const IndividualDetail = () => {
    navigate("/partner-details");
  };

  return (
    <TableContainer>
      <Table>
        <THead>
          <TableHeadRow>
            <TH> SI No</TH>
            <TH> Name </TH>
            <TH> Phone</TH>
            <TH> Email Address </TH>
            <TH>Address </TH>

            <TH></TH>
          </TableHeadRow>
        </THead>
        <TBody>
          {PaginatedData.map((i, index) => (
            <TableBodyRow>
              <TD onClick={() => IndividualDetail()}> {i.slno} </TD>
              <TD onClick={() => IndividualDetail()}> {i.name} </TD>
              <TD onClick={() => IndividualDetail()}> {i.phone} </TD>
              <TD onClick={() => IndividualDetail()}> {i.emailaddress} </TD>
              <TD onClick={() => IndividualDetail()}> {i.address} </TD>

              <TD style={{ textAlign: "right" }}>
                <RightSide>
                  <IconButton
                    aria-label="more"
                    id={index}
                    aria-controls={open ? "long-menu" : undefined}
                    aria-expanded={open ? "true" : undefined}
                    aria-haspopup="true"
                    onClick={handleClick(index)}
                  >
                    <MoreVertIcon />
                  </IconButton>

                  {currentIndex === index ? (
                    <Menus
                      // id="long-menu"
                      MenuListProps={
                        {
                          // "aria-labelledby": ` ${index}`,
                        }
                      }
                      disableScrollLock={true}
                      anchorEl={anchorEl}
                      open={open}
                      onClose={handleClose}
                      PaperProps={{
                        style: {
                          maxHeight: ITEM_HEIGHT * 4.5,
                          width: "20ch",
                        },
                      }}
                    >
                      {options.map((option) => (
                        <MenuItem
                          key={option}
                          selected={option === "Edit"}
                          onClick={handleClose}
                        >
                          {option}
                        </MenuItem>
                      ))}
                    </Menus>
                  ) : null}
                </RightSide>
              </TD>
            </TableBodyRow>
          ))}
        </TBody>
      </Table>
      <PaginationContainer>
        <Pagination count={NumOfpages} onChange={ChangePage} />
      </PaginationContainer>
    </TableContainer>
  );
}

export default PartnerList;

const PaginationContainer = styled.div`
  width: 100%;
  display: flex;
  margin-top: 10px;
  justify-content: center;
`;
const Menus = styled(Menu)`
  && {
    .css-1poimk-MuiPaper-root-MuiMenu-paper-MuiPaper-root-MuiPopover-paper {
      width: 17ch !important;
      left: 1212px !important;
      @media (width: 1309.09px) {
        left: 1083px !important;
      }
      @media (width: 1920px) {
        left: 1687px !important;
      }
      @media (width: 1600px) {
        left: 1371px !important;
      }
      @media (width: 1800px) {
        left: 98rem !important;
      }
      ::-webkit-scrollbar {
        display: none !important;
      }
    }
  }
`;
const RightSide = styled.div`
  height: 100%;
  svg {
    font-size: 1.1rem !important ;
    color: black !important;
  }
  .css-78trlr-MuiButtonBase-root-MuiIconButton-root {
    padding: unset !important;
  }
  .MuiPaper-root {
    box-shadow: none !important;
  }
`;

const TableContainer = styled.div`
  margin-top: 15px;
`;
const TD = styled.td`
  padding: 5px 15px !important;
  text-align: left;

  border-bottom: 1px solid #ababab;
  vertical-align: middle;
  font-size: 12px;
  &.cursor {
    cursor: pointer;
  }
`;
const TableBodyRow = styled.tr`
  cursor: pointer;
  :hover {
    background-color: rgba(0, 0, 0, 0.04);
  }
`;
const Table = styled.table`
  border-radius: 15px;
  width: 100%;
  background: #fff;
  border-spacing: unset;
`;

const THead = styled.thead`
  box-shadow: 0 0 0 1px #c6c6c6;
  border-radius: 3px;
  background-color: black;
  color: white;
`;
const TableHeadRow = styled.tr``;
const TBody = styled.tbody``;
const TH = styled.th`
  padding: 5px 15px;
  font-weight: normal;
  text-align: left;
  font-size: 14px;
`;
