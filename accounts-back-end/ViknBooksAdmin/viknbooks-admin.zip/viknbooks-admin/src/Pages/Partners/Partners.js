import React from "react";
import styled from "styled-components/macro";
import { useState } from "react";
import CreateButton from "../../Components/CreateButton";

import AddPartner from "../Partners/AddPartner";
import PartnerList from "./PartnerList";
import { TextField } from "@mui/material";
function Partners() {
  const [addPopup, setAddPopup] = useState(false);

  console.log(addPopup);
  return (
    <Container>
      <Heading>
        <LeftContainer>
          <PartnersTxt>Partners</PartnersTxt>
          <SubContainer>
            <Field1>
              <EditContainer>
                <CustomTextField
                  id="outlined-basic"
                  variant="outlined"
                  placeholder="Search..."
                />
              </EditContainer>
            </Field1>
          </SubContainer>
        </LeftContainer>

        <CreateButtonContainer onClick={() => setAddPopup(!addPopup)}>
          <CreateButton label={"Add New"} />
        </CreateButtonContainer>
      </Heading>
      <div>
        <PartnerList />
      </div>

      <AddPartner addPopup={addPopup} setAddPopup={setAddPopup} />
    </Container>
  );
}

export default Partners;
const CustomTextField = styled(TextField)`
  && {
    /* min-width: 150px; */
  }
  border: unset !important;
  outline: unset !important;
  &.css-1u3bzj6-MuiFormControl-root-MuiTextField-root {
    border-radius: 2px;
  }
  .css-1t8l2tu-MuiInputBase-input-MuiOutlinedInput-input {
    padding: 6.5px 30px 6.5px 14px !important;
    font-size: 13px !important;
  }
  .css-1d3z3hw-MuiOutlinedInput-notchedOutline {
    border-color: #d4d4d4 !important;
    border-width: 1px !important;
  }
`;
const EditContainer = styled.div`
  display: flex;

  align-items: center;
`;
const Field1 = styled.div``;
const SubContainer = styled.div``;
const LeftContainer = styled.div`
  display: flex;
  gap: 25px;
  align-items: center;
`;
const Container = styled.div``;
const Heading = styled.div`
  width: 100%;
  display: flex;
  justify-content: space-between;
`;

const PartnersTxt = styled.h2`
  font-size: 27px;
  letter-spacing: 1px; ;
`;
const CreateButtonContainer = styled.div`
  position: relative;
`;
