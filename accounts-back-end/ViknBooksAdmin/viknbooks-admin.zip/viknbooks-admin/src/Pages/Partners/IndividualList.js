import { Button } from "@mui/material";
import React, { useState } from "react";
import styled from "styled-components/macro";
import Pagination from "@mui/material/Pagination";
function IndividualList() {
  const [Invoicedata, setInvoicedata] = useState({
    data: [
      {
        slno: "1",
        invoiceno: "12233",
        organization: "vikncodes",
        user: "Uvais T",
        gross: "qweerrt",
        discount: "10",
        total: "123444",
        status: "Paid",
      },
      {
        slno: "2",
        invoiceno: "1433",
        organization: "vikncodes",
        user: "jasmal",
        gross: "qweerrt",
        discount: "20",
        total: "1656444",
        status: "Unpaid",
      },
      {
        slno: "3",
        invoiceno: "5233",
        organization: "vikncodes",
        user: "abhi",
        gross: "qweerrt",
        discount: "50",
        total: "12844",
        status: "Paid",
      },
      {
        slno: "4",
        invoiceno: "5233",
        organization: "vikncodes",
        user: "abhi",
        gross: "qweerrt",
        discount: "50",
        total: "12844",
        status: "Paid",
      },
      {
        slno: "5",
        invoiceno: "5233",
        organization: "vikncodes",
        user: "abhi",
        gross: "qweerrt",
        discount: "50",
        total: "12844",
        status: "Paid",
      },
      {
        slno: "6",
        invoiceno: "5233",
        organization: "vikncodes",
        user: "abhi",
        gross: "qweerrt",
        discount: "50",
        total: "12844",
        status: "Paid",
      },
      {
        slno: "7",
        invoiceno: "5233",
        organization: "vikncodes",
        user: "abhi",
        gross: "qweerrt",
        discount: "50",
        total: "12844",
        status: "Paid",
      },
      {
        slno: "8",
        invoiceno: "5233",
        organization: "vikncodes",
        user: "abhi",
        gross: "qweerrt",
        discount: "50",
        total: "12844",
        status: "Paid",
      },
      {
        slno: "9",
        invoiceno: "5233",
        organization: "vikncodes",
        user: "abhi",
        gross: "qweerrt",
        discount: "50",
        total: "12844",
        status: "Paid",
      },
      {
        slno: "10",
        invoiceno: "5233",
        organization: "vikncodes",
        user: "abhi",
        gross: "qweerrt",
        discount: "50",
        total: "12844",
        status: "Paid",
      },
      {
        slno: "11",
        invoiceno: "5233",
        organization: "vikncodes",
        user: "abhi",
        gross: "qweerrt",
        discount: "50",
        total: "12844",
        status: "Paid",
      },
      {
        slno: "12",
        invoiceno: "5233",
        organization: "vikncodes",
        user: "abhi",
        gross: "qweerrt",
        discount: "50",
        total: "12844",
        status: "Paid",
      },
      {
        slno: "13",
        invoiceno: "5233",
        organization: "vikncodes",
        user: "abhi",
        gross: "qweerrt",
        discount: "50",
        total: "12844",
        status: "Paid",
      },
      {
        slno: "14",
        invoiceno: "5233",
        organization: "vikncodes",
        user: "abhi",
        gross: "qweerrt",
        discount: "50",
        total: "12844",
        status: "Paid",
      },
      {
        slno: "15",
        invoiceno: "5233",
        organization: "vikncodes",
        user: "abhi",
        gross: "qweerrt",
        discount: "50",
        total: "12844",
        status: "Paid",
      },
      {
        slno: "16",
        invoiceno: "5233",
        organization: "vikncodes",
        user: "abhi",
        gross: "qweerrt",
        discount: "50",
        total: "12844",
        status: "Paid",
      },
      {
        slno: "17",
        invoiceno: "5233",
        organization: "vikncodes",
        user: "abhi",
        gross: "qweerrt",
        discount: "50",
        total: "12844",
        status: "Paid",
      },
      {
        slno: "18",
        invoiceno: "5233",
        organization: "vikncodes",
        user: "abhi",
        gross: "qweerrt",
        discount: "50",
        total: "12844",
        status: "Paid",
      },
      {
        slno: "19",
        invoiceno: "5233",
        organization: "vikncodes",
        user: "abhi",
        gross: "qweerrt",
        discount: "50",
        total: "12844",
        status: "Paid",
      },
      {
        slno: "20",
        invoiceno: "5233",
        organization: "vikncodes",
        user: "abhi",
        gross: "qweerrt",
        discount: "50",
        total: "12844",
        status: "Paid",
      },
      {
        slno: "21",
        invoiceno: "5233",
        organization: "vikncodes",
        user: "abhi",
        gross: "qweerrt",
        discount: "50",
        total: "12844",
        status: "Paid",
      },
      {
        slno: "22",
        invoiceno: "5233",
        organization: "vikncodes",
        user: "abhi",
        gross: "qweerrt",
        discount: "50",
        total: "12844",
        status: "Paid",
      },
      {
        slno: "23",
        invoiceno: "5233",
        organization: "vikncodes",
        user: "abhi",
        gross: "qweerrt",
        discount: "50",
        total: "12844",
        status: "Paid",
      },
      {
        slno: "24",
        invoiceno: "5233",
        organization: "vikncodes",
        user: "abhi",
        gross: "qweerrt",
        discount: "50",
        total: "12844",
        status: "Paid",
      },
      {
        slno: "25",
        invoiceno: "5233",
        organization: "vikncodes",
        user: "abhi",
        gross: "qweerrt",
        discount: "50",
        total: "12844",
        status: "Paid",
      },
      {
        slno: "26",
        invoiceno: "5233",
        organization: "vikncodes",
        user: "abhi",
        gross: "qweerrt",
        discount: "50",
        total: "12844",
        status: "Paid",
      },
      {
        slno: "27",
        invoiceno: "5233",
        organization: "vikncodes",
        user: "abhi",
        gross: "qweerrt",
        discount: "50",
        total: "12844",
        status: "Paid",
      },
      {
        slno: "28",
        invoiceno: "5233",
        organization: "vikncodes",
        user: "abhi",
        gross: "qweerrt",
        discount: "50",
        total: "12844",
        status: "Paid",
      },
      {
        slno: "29",
        invoiceno: "5233",
        organization: "vikncodes",
        user: "abhi",
        gross: "qweerrt",
        discount: "50",
        total: "12844",
        status: "Paid",
      },
      {
        slno: "30",
        invoiceno: "5233",
        organization: "vikncodes",
        user: "abhi",
        gross: "qweerrt",
        discount: "50",
        total: "12844",
        status: "Paid",
      },
    ],
  });

  //pagination=======================================

  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage, setItemsPerPage] = useState(22);

  const IndexofLastItem = currentPage * itemsPerPage;
  const indexOfFirstDish = IndexofLastItem - itemsPerPage;
  let PaginatedData = Invoicedata.data.slice(indexOfFirstDish, IndexofLastItem);
  console.log("page", PaginatedData);

  const ChangePage = (event, value) => {
    setCurrentPage(value);
  };

  const NumOfpages = Math.ceil(Invoicedata.data.length / itemsPerPage);
  return (
    <TableContainer>
      <Table>
        <THead>
          <TableHeadRow>
            <TH> SI No </TH>
            <TH> Invoice No </TH>
            <TH> Organization </TH>
            <TH> User </TH>
            <TH> Gross </TH>
            <TH> Discount </TH>
            <TH> Total </TH>
            <TH> Status </TH>
          </TableHeadRow>
        </THead>
        <TBody>
          {PaginatedData.map((i) => (
            <TableBodyRow>
              <TD> {i.slno} </TD>
              <TD> {i.invoiceno} </TD>
              <TD> {i.organization} </TD>
              <TD> {i.user} </TD>
              <TD> {i.gross} </TD>
              <TD> {i.discount} </TD>

              <TD> {i.total} </TD>
              <TD>
                {" "}
                <StatusText status={i.status}>{i.status} </StatusText>
              </TD>
            </TableBodyRow>
          ))}
        </TBody>
      </Table>
      <PaginationContainer>
        <Pagination count={NumOfpages} onChange={ChangePage} />
      </PaginationContainer>
    </TableContainer>
  );
}

export default IndividualList;
const PaginationContainer = styled.div`
  width: 100%;
  display: flex;
  margin-top: 10px;
  justify-content: center;
`;
const StatusText = styled.span`
  color: ${({ status }) => (status === "Paid" ? "#005803" : "#870000")};
  font-size: 12px;
`;

const TableContainer = styled.div`
  margin-top: 15px;
`;
const TD = styled.td`
  padding: 5px 15px !important;
  text-align: left;
  padding: 0.5em 1em;
  border-bottom: 1px solid #ababab;
  vertical-align: middle;
  font-size: 12px;

  &.cursor {
    cursor: pointer;
  }
`;
const TableBodyRow = styled.tr`
  :hover {
    background-color: rgba(0, 0, 0, 0.04);
  }
`;
const Table = styled.table`
  border-radius: 15px;
  width: 100%;
  background: #fff;
  border-spacing: unset;
`;

const THead = styled.thead`
  box-shadow: 0 0 0 1px #c6c6c6;
  border-radius: 3px;
  background-color: black;
  color: white;
`;
const TableHeadRow = styled.tr``;
const TBody = styled.tbody``;
const TH = styled.th`
  padding: 5px 15px;
  font-weight: normal;
  text-align: left;
  font-size: 14px;
`;
