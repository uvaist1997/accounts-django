import React from "react";
import styled from "styled-components/macro";
import CloseIcon from "@mui/icons-material/Close";
import { Button, Stack } from "@mui/material";
import IconButton from "@mui/material/IconButton";
import TextField from "@mui/material/TextField";
import { useState } from "react";

import TextareaAutosize from "@mui/material/TextareaAutosize";
import { Autocomplete } from "@mui/material";
import { DesktopDatePicker, LocalizationProvider } from "@mui/x-date-pickers";
import { AdapterDateFns } from "@mui/x-date-pickers/AdapterDateFns";

function Addenquiry({ addPopup, setAddPopup }) {
  const [age, setAge] = useState("");

  const [value, setValue] = React.useState(new Date("2014-08-18T21:11:54"));

  const DateChanger = (newValue) => {
    setValue(newValue);
  };
  const handleSelectChange = () => {
    console.log("select");
  };

  const [state, setState] = useState({
    data: ["jasmal", "uvais", "Abhi"],
    Projectlsd: [],
    ProjeID: "",
    contact_data: [
      {
        phone: "",
        work: "",
      },
    ],

    contact_email: [
      {
        email: "",
        work: "",
      },
    ],
  });

  const addContactData = () => {
    let contact_data = [...state.contact_data];
    contact_data.push({
      phone: "",
      work: "",
    });
    setState({
      ...state,
      contact_data,
    });
  };

  return (
    <Container addpopup={addPopup}>
      <div>
        <Header>
          <AddenquiryTxt>Add Enquiry</AddenquiryTxt>
          <IconButton>
            <CloseIcon onClick={(e) => setAddPopup(false)} />
          </IconButton>
        </Header>

        <Form>
          <DetailBlock>
            <TextContainer>
              <Label for="data">Date</Label>
              <DateBox>
                <LocalizationProvider
                  dateAdapter={AdapterDateFns}
                  className="dateprovider"
                >
                  <Stack spacing={3}>
                    <DesktopDatePicker
                      inputFormat="MM/dd/yyyy"
                      value={value}
                      onChange={DateChanger}
                      renderInput={(params) => <TextField {...params} />}
                    />
                  </Stack>
                </LocalizationProvider>
              </DateBox>
            </TextContainer>
          </DetailBlock>

          <TextContainer>
            <Label for="organization">Organization</Label>

            <CustomeAutocomplete
              size="small"
              id="combo-box-demo"
              options={state.data}
              // getOptionLabel={(option) => option.username || ""}
              onInputChange={(event, value, reason) => {}}
              onChange={(e, v) => handleSelectChange("ReportUserID", v)}
              renderInput={(params) => <TextField size="small" {...params} />}
            />
          </TextContainer>

          <TextContainer>
            <Label for="phone">Phone</Label>

            <CustomTextField id="outlined-basic" variant="outlined" />
          </TextContainer>
          <TextContainer>
            <Label for="email">Email</Label>

            <CustomTextField id="outlined-basic" variant="outlined" />
          </TextContainer>
          <TextContainer>
            <Label for="reason">Reason</Label>

            <CustomTextField id="outlined-basic" variant="outlined" />
          </TextContainer>
          <LabelTextContainer>
            <LabelContainer>
              <Label for="description">Description</Label>

              <CustomTextArea
                maxRows={4}
                aria-label="maximum height"
                style={{ width: "100%" }}
              />
            </LabelContainer>
          </LabelTextContainer>

          {/* Add mail================================================ */}
        </Form>

        <ButtonsContaier>
          <SaveButton onClick={(e) => setAddPopup(false)}>Save</SaveButton>
        </ButtonsContaier>
      </div>
    </Container>
  );
}

export default Addenquiry;

const DateBox = styled.div`
  background-color: #e9e9e9 !important ;
  border: unset !important;
  outline: unset !important;
  &.css-1u3bzj6-MuiFormControl-root-MuiTextField-root {
    width: 100% !important;
    margin-top: 5px;
  }

  .css-1d3z3hw-MuiOutlinedInput-notchedOutline {
    border: none !important;
  }

  .css-nxo287-MuiInputBase-input-MuiOutlinedInput-input {
    padding: 3.5px 14px !important;
    /* font-size: 15px !important; */
  }
  .css-i4bv87-MuiSvgIcon-root {
    font-size: 1.3rem !important;
  }
`;
const CustomTextArea = styled(TextareaAutosize)`
  height: 60px !important;
  overflow: unset !important ;
  padding: 10px 10px;
  outline: unset !important ;
  border: unset !important;
  background-color: #e9e9e9 !important ;
  ::-webkit-scrollbar {
    display: none;
  }
`;

const ButtonsContaier = styled.div`
  margin-top: 10px;
  display: flex;
  justify-content: space-between;
`;
const SaveButton = styled(Button)`
  && {
    background: #009e15;
    color: #fff;
    width: 100%;
    border-radius: 2px;
    padding: 5px 45px;
    text-transform: capitalize;
    &:hover {
      background: #009e15;
    }
  }
`;
const CancelButton = styled(Button)`
  && {
    background: #1e1e1e;
    color: #fff;
    border-radius: 2px;
    padding: 5px 45px;
    text-transform: capitalize;

    &:hover {
      background: #1e1e1e;
    }
  }
`;

const SearchButton = styled(Button)`
  .css-1d6wzja-MuiButton-startIcon {
    margin-right: 5px !important ;
  }
  && {
    background: rgb(255 255 255);

    color: #024987;
    border-radius: 4px;
    padding: 6px 157px 4px 12px;
    text-transform: capitalize;
    &:hover {
      background: rgb(255 255 255);
    }
  }
`;
const AddMorePlusContainer = styled.div`
  width: 100%;
`;
const AddMorContainer = styled.div`
  display: flex;
  gap: 10px;
  margin-top: 3px;
  cursor: pointer;
  color: #024987;
`;
const SelectBox1 = styled.div`
  padding-top: 30px;
  width: 48%;
  .css-1yk1gt9-MuiInputBase-root-MuiOutlinedInput-root-MuiSelect-root {
    font-size: 0.9rem !important;
  }

  .css-1869usk-MuiFormControl-root {
    width: 100% !important;
  }
  .css-1869usk-MuiFormControl-root {
    margin: unset !important;
  }
  .MuiOutlinedInput-notchedOutline {
    border-color: #d4d4d4 !important;

    border-width: 1px !important ;
    outline: unset !important;
  }

  div div div {
    padding: 6px;
  }

  em {
    font-style: normal !important;
  }
`;

const LabelContainer = styled.div`
  width: 100%;
`;
const CustomSelectContainer = styled(LabelContainer)`
  display: flex;
  align-items: end;
`;

const TextContainer = styled.div`
  margin-top: 8px;
`;
const LabelTextContainer = styled(TextContainer)`
  display: flex;
  gap: 5px;
  justify-content: space-between;
`;
const AddMoreCard = styled(LabelTextContainer)`
  /* display: ${({ addMorePhone }) => (!addMorePhone ? "none" : "")}; */
  margin: unset;
`;

const AddMoreEmail = styled(LabelTextContainer)`
  /* display: ${({ addEmail }) => (!addEmail ? "none" : "")}; */
`;
const CustomTextField = styled(TextField)`
  background-color: #e9e9e9 !important ;
  border: unset !important;
  outline: unset !important;
  &.css-1u3bzj6-MuiFormControl-root-MuiTextField-root {
    width: 100% !important;
    /* margin-top: 5px; */
  }
  .css-1t8l2tu-MuiInputBase-input-MuiOutlinedInput-input {
    padding: 3.5px 14px !important;
  }
  .css-1d3z3hw-MuiOutlinedInput-notchedOutline {
    border: none !important;
  }
`;

const CustomSelect = styled.div`
  padding-top: 5px;
  .css-1yk1gt9-MuiInputBase-root-MuiOutlinedInput-root-MuiSelect-root {
    font-size: 0.9rem !important;
  }

  .css-1869usk-MuiFormControl-root {
    width: 100% !important;
  }
  .css-1869usk-MuiFormControl-root {
    margin: unset !important;
  }
  .MuiOutlinedInput-notchedOutline {
    border-color: #d4d4d4 !important;

    border-width: 1px !important ;
    outline: unset !important;
  }

  div div div {
    padding: 6px;
  }

  em {
    font-style: normal !important;
  }
`;

const CustomeAutocomplete = styled(Autocomplete)`
  background-color: #e9e9e9 !important ;
  border: unset !important;
  outline: unset !important;
  &.css-1u3bzj6-MuiFormControl-root-MuiTextField-root {
    width: 100% !important;
    margin-top: 5px;
  }
  &.css-1auycx3-MuiAutocomplete-root
    .MuiOutlinedInput-root.MuiInputBase-sizeSmall
    .MuiAutocomplete-input {
    padding: 0px 4px 0px 4px !important;
  }

  .css-1d3z3hw-MuiOutlinedInput-notchedOutline {
    border: none !important;
  }
  &.css-1auycx3-MuiAutocomplete-root
    .MuiOutlinedInput-root.MuiInputBase-sizeSmall {
    padding: 4px !important;
  }
`;
const Label = styled.label`
  font-size: 12px;
  margin-top: 15px; ;
`;
const DetailBlock = styled.div`
  width: 100%;
`;
const OrganizationLabel = styled.p`
  width: 100px;
  font-size: 15px;
  cursor: pointer;
`;
const Projectname = styled(OrganizationLabel)`
  border: 1px solid #d8d8d8;
  border-radius: 2px;
  width: 100%;
  margin-top: 5px;
  .css-78trlr-MuiButtonBase-root-MuiIconButton-root {
    padding: 4px !important ;
  }
`;
const Form = styled.form`
  overflow-y: scroll;

  /* margin-top: 20px; */
  ::-webkit-scrollbar {
    display: none;
  }
`;
const AddenquiryTxt = styled.h4`
  font-size: 18px;
`;
const Header = styled.div`
  display: flex;
  align-items: center;
  justify-content: space-between;
`;
const Container = styled.div`
  z-index: 2;
  padding: 15px;
  width: 316px;

  box-shadow: 0px 2px 1px -1px rgb(0 0 0 / 20%),
    0px 1px 1px 0px rgb(0 0 0 / 14%), 0px 1px 3px 0px rgb(0 0 0 / 12%);
  position: absolute;
  border-radius: 2px;
  right: 22px;
  top: 216px;
  background: white;

  display: ${({ addpopup }) => (!addpopup ? "none" : "")};
`;
