import { FormControl, MenuItem, Pagination, Select } from "@mui/material";
import React, { useState } from "react";
import styled from "styled-components/macro";
import Typography from "@mui/material/Typography";
function ManualEnquiryList() {
  const [enquiryList, setEnquiryList] = useState({
    data: [
      {
        id: "1",
        date: "09 November 2021",
        time: "10:00 AM",
        user: "uvais",
        phone: "1234567654",
        email: "uvais",
        reason: "upgrade",
        message: "Product group deleted failed",
        status: "solved",
      },

      {
        id: "2",
        date: "09 june 2021",
        time: "10:00 AM",
        user: "jasmal",
        phone: "1234567898",
        email: "uvais",
        reason: "complaint",
        message: "Product group deleted failed",
        status: "pending",
      },

      {
        id: "3",
        date: "09 August 2021",
        time: "10:00 AM",
        user: "abhi",
        phone: "4321234567",
        email: "uvais",
        reason: "complaint",
        message: "Product group deleted failed",
        status: "decline",
      },
      {
        id: "4",
        date: "09 August 2021",
        time: "10:00 AM",
        user: "abhi",
        phone: "4321234567",
        email: "uvais",
        reason: "complaint",
        message: "Product group deleted failed",
        status: "pending",
      },
      {
        id: "5",
        date: "09 August 2021",
        time: "10:00 AM",
        user: "abhi",
        phone: "4321234567",
        email: "uvais",
        reason: "complaint",
        message: "Product group deleted failed",
        status: "pending",
      },
      {
        id: "6",
        date: "09 August 2021",
        time: "10:00 AM",
        user: "abhi",
        phone: "4321234567",
        email: "uvais",
        reason: "complaint",
        message: "Product group deleted failed",
        status: "pending",
      },
      {
        id: "7",
        date: "09 August 2021",
        time: "10:00 AM",
        user: "abhi",
        phone: "4321234567",
        email: "uvais",
        reason: "complaint",
        message: "Product group deleted failed",
        status: "decline",
      },
      {
        id: "8",
        date: "09 August 2021",
        time: "10:00 AM",
        user: "abhi",
        phone: "4321234567",
        email: "uvais",
        reason: "complaint",
        message: "Product group deleted failed",
        status: "decline",
      },
      {
        id: "9",
        date: "09 August 2021",
        time: "10:00 AM",
        user: "abhi",
        phone: "4321234567",
        email: "uvais",
        reason: "complaint",
        message: "Product group deleted failed",
        status: "decline",
      },
      {
        id: "10",
        date: "09 August 2021",
        time: "10:00 AM",
        user: "abhi",
        phone: "4321234567",
        email: "uvais",
        reason: "complaint",
        message: "Product group deleted failed",
        status: "decline",
      },
      {
        id: "11",
        date: "09 August 2021",
        time: "10:00 AM",
        user: "abhi",
        phone: "4321234567",
        email: "uvais",
        reason: "complaint",
        message: "Product group deleted failed",
        status: "decline",
      },
      {
        id: "12",
        date: "09 August 2021",
        time: "10:00 AM",
        user: "abhi",
        phone: "4321234567",
        email: "uvais",
        reason: "complaint",
        message: "Product group deleted failed",
        status: "decline",
      },
      {
        id: "13",
        date: "09 August 2021",
        time: "10:00 AM",
        user: "abhi",
        phone: "4321234567",
        email: "uvais",
        reason: "complaint",
        message: "Product group deleted failed",
        status: "decline",
      },
      {
        id: "14",
        date: "09 August 2021",
        time: "10:00 AM",
        user: "abhi",
        phone: "4321234567",
        email: "uvais",
        reason: "complaint",
        message: "Product group deleted failed",
        status: "decline",
      },
      {
        id: "15",
        date: "09 August 2021",
        time: "10:00 AM",
        user: "abhi",
        phone: "4321234567",
        email: "uvais",
        reason: "complaint",
        message: "Product group deleted failed",
        status: "decline",
      },
      {
        id: "16",
        date: "09 August 2021",
        time: "10:00 AM",
        user: "abhi",
        phone: "4321234567",
        email: "uvais",
        reason: "complaint",
        message: "Product group deleted failed",
        status: "decline",
      },
      {
        id: "17",
        date: "09 August 2021",
        time: "10:00 AM",
        user: "abhi",
        phone: "4321234567",
        email: "uvais",
        reason: "complaint",
        message: "Product group deleted failed",
        status: "decline",
      },
      {
        id: "18",
        date: "09 August 2021",
        time: "10:00 AM",
        user: "abhi",
        phone: "4321234567",
        email: "uvais",
        reason: "complaint",
        message: "Product group deleted failed",
        status: "decline",
      },
      {
        id: "19",
        date: "09 August 2021",
        time: "10:00 AM",
        user: "abhi",
        phone: "4321234567",
        email: "uvais",
        reason: "complaint",
        message: "Product group deleted failed",
        status: "decline",
      },
      {
        id: "20",
        date: "09 August 2021",
        time: "10:00 AM",
        user: "abhi",
        phone: "4321234567",
        email: "uvais",
        reason: "complaint",
        message: "Product group deleted failed",
        status: "decline",
      },
      {
        id: "21",
        date: "09 August 2021",
        time: "10:00 AM",
        user: "abhi",
        phone: "4321234567",
        email: "uvais",
        reason: "complaint",
        message: "Product group deleted failed",
        status: "decline",
      },
      {
        id: "22",
        date: "09 August 2021",
        time: "10:00 AM",
        user: "abhi",
        phone: "4321234567",
        email: "uvais",
        reason: "complaint",
        message: "Product group deleted failed",
        status: "decline",
      },
      {
        id: "23",
        date: "09 August 2021",
        time: "10:00 AM",
        user: "abhi",
        phone: "4321234567",
        email: "uvais",
        reason: "complaint",
        message: "Product group deleted failed",
        status: "decline",
      },
      {
        id: "24",
        date: "09 August 2021",
        time: "10:00 AM",
        user: "abhi",
        phone: "4321234567",
        email: "uvais",
        reason: "complaint",
        message: "Product group deleted failed",
        status: "decline",
      },
      {
        id: "25",
        date: "09 August 2021",
        time: "10:00 AM",
        user: "abhi",
        phone: "4321234567",
        email: "uvais",
        reason: "complaint",
        message: "Product group deleted failed",
        status: "decline",
      },
      {
        id: "26",
        date: "09 August 2021",
        time: "10:00 AM",
        user: "abhi",
        phone: "4321234567",
        email: "uvais",
        reason: "complaint",
        message: "Product group deleted failed",
        status: "decline",
      },
      {
        id: "27",
        date: "09 August 2021",
        time: "10:00 AM",
        user: "abhi",
        phone: "4321234567",
        email: "uvais",
        reason: "complaint",
        message: "Product group deleted failed",
        status: "solved",
      },
    ],
  });
  const handleChange = (index) => (event) => {
    let data = [...enquiryList.data];

    if (currentPage != 1) {
      index = index + 10 * (currentPage - 1);
    }
    data[index]["status"] = event.target.value;
    setEnquiryList({ data });
  };
  //pagination=================================
  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage, setItemsPerPage] = useState(10);
  const values = Math.ceil(enquiryList.data.length / itemsPerPage);
  const lastIndex = currentPage * itemsPerPage;
  const firstIndex = lastIndex - itemsPerPage;
  const items = enquiryList.data.slice(firstIndex, lastIndex);

  const Pagechange = (event, value) => {
    setCurrentPage(value);
  };

  return (
    <TableContainer>
      <Table>
        <THead>
          <TableHeadRow>
            <TH> ID </TH>
            <TH> Date & Time </TH>
            <TH> User </TH>
            <TH> Phone </TH>
            <TH> Email Addresss</TH>
            <TH> Reason</TH>
            <TH> Message </TH>
            <TH style={{ width: "199px" }}>Status</TH>
          </TableHeadRow>
        </THead>
        <TBody>
          {items.map((i, index) => (
            <TableBodyRow>
              <TD> {i.id} </TD>
              <TD>
                <span style={{ fontSize: "13px" }}>{i.date} </span>
                <h4 style={{ fontSize: "13px" }}>{i.time} </h4>
              </TD>
              <TD> {i.user} </TD>
              <TD> {i.phone} </TD>
              <TD> {i.email} </TD>
              <TD> {i.reason} </TD>
              <TD> {i.message} </TD>

              <TD style={{ padding: "5px 6px !important " }}>
                <SelectBox1 status={i.status}>
                  <FormControl sx={{ m: 1, minWidth: 115 }}>
                    <Select
                      value={i.status}
                      onChange={handleChange(index)}
                      MenuProps={{
                        disableScrollLock: true,
                      }}
                    >
                      <MenuItem value={"solved"}>Solved</MenuItem>

                      <MenuItem value={"pending"}>Pending</MenuItem>
                      <MenuItem value={"decline"}>Declined</MenuItem>
                    </Select>
                  </FormControl>
                </SelectBox1>
              </TD>
            </TableBodyRow>
          ))}
        </TBody>
      </Table>
      <PagenationContainer>
        <Pagination count={values} onChange={Pagechange} />
      </PagenationContainer>
    </TableContainer>
  );
}
export default ManualEnquiryList;
const PagenationContainer = styled.div`
  width: 100%;
  display: flex;
  margin-top: 10px;
  justify-content: center;
`;
const SelectBox1 = styled.div`
  .css-1yk1gt9-MuiInputBase-root-MuiOutlinedInput-root-MuiSelect-root {
    font-size: 12px !important ;

    background-color: ${({ status }) =>
      status === "solved"
        ? "#009a05"
        : status === "pending"
        ? "#9A0000"
        : status === "decline"
        ? "black"
        : null};

    color: white;
  }
  .css-hfutr2-MuiSvgIcon-root-MuiSelect-icon {
    color: white !important;
  }
  .css-bpeome-MuiSvgIcon-root-MuiSelect-icon {
    color: white !important;
  }
  .css-1869usk-MuiFormControl-root {
    min-width: 175px !important;
    margin: unset !important;
    @media (min-width: 1920px) {
      width: 250px;
    }
  }
  .MuiOutlinedInput-notchedOutline {
    border: unset;

    border-width: 1px !important ;

    outline: unset !important;
  }

  div div div {
    padding: 6px;
  }

  em {
    font-style: normal !important;
    font-family: unset !important;
  }

  .css-11u53oe-MuiSelect-select-MuiInputBase-input-MuiOutlinedInput-input.css-11u53oe-MuiSelect-select-MuiInputBase-input-MuiOutlinedInput-input.css-11u53oe-MuiSelect-select-MuiInputBase-input-MuiOutlinedInput-input {
    padding-left: 12px !important;
  }
  .css-38aidw-MuiFormControl-root {
    margin: unset !important;
  }
`;
const TableContainer = styled.div`
  margin-top: 15px;
`;
const TD = styled.td`
  padding: 5px 15px;
  text-align: left;
  font-size: 13px;
  padding: 0.5em 1em;
  border-bottom: 1px solid #ababab;
  vertical-align: middle;

  &.cursor {
    cursor: pointer;
  }
`;
const TableBodyRow = styled.tr`
  :hover {
    background-color: rgba(0, 0, 0, 0.04);
  }
`;
const Table = styled.table`
  border-radius: 15px;
  width: 100%;
  background: #fff;
  border-spacing: unset;
`;

const THead = styled.thead`
  box-shadow: 0 0 0 1px #c6c6c6;
  border-radius: 3px;
  background-color: black;
  color: white;
`;
const TableHeadRow = styled.tr``;
const TBody = styled.tbody``;
const TH = styled.th`
  padding: 5px 15px;
  font-weight: normal;
  text-align: left;
  font-size: 14px;
`;
