import React, { useState } from "react";
import PropTypes from "prop-types";
import Tabs from "@mui/material/Tabs";
import Tab from "@mui/material/Tab";
import Typography from "@mui/material/Typography";
import Box from "@mui/material/Box";
import styled from "styled-components/macro";
import {
  Autocomplete,
  Button,
  FormControl,
  MenuItem,
  Select,
  TextField,
} from "@mui/material";
import DatePicker from "../../Components/DatePicker";
import CreateButton from "../../Components/CreateButton";
import WebEnquiryLiist from "./WebEnquiryLiist.js";
import ManualEnquiryList from "./ManualEnquiryList";
import Addenquiry from "./Addenquiry";
function TabPanel(props) {
  const { children, value, index, ...other } = props;

  return (
    <div
      role="tabpanel"
      hidden={value !== index}
      id={`simple-tabpanel-${index}`}
      aria-labelledby={`simple-tab-${index}`}
      {...other}
    >
      {value === index && (
        <Box sx={{ p: 3 }}>
          <Typography>{children}</Typography>
        </Box>
      )}
    </div>
  );
}

TabPanel.propTypes = {
  children: PropTypes.node,
  index: PropTypes.number.isRequired,
  value: PropTypes.number.isRequired,
};

function a11yProps(index) {
  return {
    id: `simple-tab-${index}`,
    "aria-controls": `simple-tabpanel-${index}`,
  };
}

function Enquiry() {
  const [value, setValue] = React.useState(0);
  const [state, setState] = useState({
    data: ["uvais", "jasmal", "abhi"],
  });
  const handle = (event, newValue) => {
    setValue(newValue);
  };
  const [age, setAge] = useState("");
  const handleChange = (event) => {
    setAge(event.target.value);
  };
  const handleSelectChange = () => {
    console.log("select");
  };
  const [addPopup, setAddPopup] = useState(false);
  return (
    <Container>
      <ToggleContainer>
        <Box sx={{ width: "100%" }}>
          <Box sx={{ borderColor: "divider" }}>
            <Tabs
              value={value}
              onChange={handle}
              aria-label="basic tabs example"
            >
              <Tab
                className="tab1"
                label="Website Enquiries "
                {...a11yProps(0)}
              />

              <Tab label="Manual Enquiries" {...a11yProps(1)} />
            </Tabs>
          </Box>
          <TabPanel value={value} index={0}>
            <BoxContainer>
              <AllBoxesContainer>
                <DatePickerContainer>
                  <DatePicker />
                </DatePickerContainer>
                <SubContainer>
                  <LabelTxt>User</LabelTxt>

                  <Field1>
                    <EditContainer>
                      <SelectBox1>
                        <CustomeAutocomplete
                          size="small"
                          id="combo-box-demo"
                          options={state.data}
                          // getOptionLabel={(option) => option.username || ""}
                          onInputChange={(event, value, reason) => {}}
                          onChange={(e, v) =>
                            handleSelectChange("ReportUserID", v)
                          }
                          renderInput={(params) => (
                            <TextField size="small" {...params} />
                          )}
                        />
                      </SelectBox1>
                    </EditContainer>
                  </Field1>
                </SubContainer>
                <SubContainer>
                  <LabelTxt>Type</LabelTxt>

                  <Field1>
                    <EditContainer>
                      <SelectBox1>
                        <CustomeAutocomplete
                          size="small"
                          id="combo-box-demo"
                          options={state.data}
                          // getOptionLabel={(option) => option.username || ""}
                          onInputChange={(event, value, reason) => {}}
                          onChange={(e, v) =>
                            handleSelectChange("ReportUserID", v)
                          }
                          renderInput={(params) => (
                            <TextField size="small" {...params} />
                          )}
                        />
                      </SelectBox1>
                    </EditContainer>
                  </Field1>
                </SubContainer>
                <SubContainer>
                  <LabelTxt>Status</LabelTxt>

                  <Field1>
                    <EditContainer>
                      <SelectBox1>
                        <FormControl sx={{ m: 1, minWidth: 120 }}>
                          <Select
                            value={age}
                            onChange={handleChange}
                            displayEmpty
                            defaultValue="Status"
                            MenuProps={{
                              disableScrollLock: true,
                            }}
                          >
                            <MenuItems value={10}>Ten</MenuItems>
                            <MenuItems value={20}>Twenty</MenuItems>
                            <MenuItems value={30}>Thirty</MenuItems>
                          </Select>
                        </FormControl>
                      </SelectBox1>
                    </EditContainer>
                  </Field1>
                </SubContainer>
                <SearchButton>Search</SearchButton>
              </AllBoxesContainer>
            </BoxContainer>
            <WebEnquiryLiist />
          </TabPanel>

          {/* second window|||||||||||||||||||||||================== */}

          <TabPanel value={value} index={1}>
            <SecondWindow>
              <BoxContainer>
                <AllBoxesContainer>
                  <DatePickerContainer>
                    <DatePicker />
                  </DatePickerContainer>
                  <SubContainer>
                    <LabelTxt>User</LabelTxt>

                    <Field1>
                      <EditContainer>
                        <SelectBox1>
                          <CustomeAutocomplete
                            size="small"
                            id="combo-box-demo"
                            options={state.data}
                            // getOptionLabel={(option) => option.username || ""}
                            onInputChange={(event, value, reason) => {}}
                            onChange={(e, v) =>
                              handleSelectChange("ReportUserID", v)
                            }
                            renderInput={(params) => (
                              <TextField size="small" {...params} />
                            )}
                          />
                        </SelectBox1>
                      </EditContainer>
                    </Field1>
                  </SubContainer>
                  <SubContainer>
                    <LabelTxt>Type</LabelTxt>

                    <Field1>
                      <EditContainer>
                        <SelectBox1>
                          <CustomeAutocomplete
                            size="small"
                            id="combo-box-demo"
                            options={state.data}
                            // getOptionLabel={(option) => option.username || ""}
                            onInputChange={(event, value, reason) => {}}
                            onChange={(e, v) =>
                              handleSelectChange("ReportUserID", v)
                            }
                            renderInput={(params) => (
                              <TextField size="small" {...params} />
                            )}
                          />
                        </SelectBox1>
                      </EditContainer>
                    </Field1>
                  </SubContainer>
                  <SubContainer>
                    <LabelTxt>Status</LabelTxt>

                    <Field1>
                      <EditContainer>
                        <SelectBox1>
                          <FormControl sx={{ m: 1, minWidth: 120 }}>
                            <Select
                              value={age}
                              onChange={handleChange}
                              displayEmpty
                              defaultValue="Status"
                              MenuProps={{
                                disableScrollLock: true,
                              }}
                            >
                              <MenuItems value={10}>Ten</MenuItems>
                              <MenuItems value={20}>Twenty</MenuItems>
                              <MenuItems value={30}>Thirty</MenuItems>
                            </Select>
                          </FormControl>
                        </SelectBox1>
                      </EditContainer>
                    </Field1>
                  </SubContainer>
                  <SearchButton>Search</SearchButton>
                </AllBoxesContainer>
              </BoxContainer>
              <CreateButtonContainer onClick={(e) => setAddPopup(!addPopup)}>
                <CreateButton label={"Create New"} />
              </CreateButtonContainer>
            </SecondWindow>
            <ManualEnquiryList />

            <Addenquiry addPopup={addPopup} setAddPopup={setAddPopup} />
          </TabPanel>
        </Box>
      </ToggleContainer>
    </Container>
  );
}

export default Enquiry;
const MenuItems = styled(MenuItem)`
  font-size: 13px !important;
`;
const SecondWindow = styled.div`
  display: flex;
  align-items: center;
  justify-content: space-between;
`;
const CreateButtonContainer = styled.div`
  position: relative;
  align-self: flex-end;
  margin-bottom: 3px;
`;

const DatePickerContainer = styled.div`
  align-self: end;
  margin-bottom: 5px;
`;
const Container = styled.div`
  .css-1h9z7r5-MuiButtonBase-root-MuiTab-root {
    padding: unset !important;
  }
  .css-heg063-MuiTabs-flexContainer {
    gap: 15px;
  }
`;
const ToggleContainer = styled.div`
  .css-19kzrtu {
    padding: unset !important ;
  }

  /* && {
    text-transform: capitalize !important;
  } */
  .css-1h9z7r5-MuiButtonBase-root-MuiTab-root {
    text-transform: capitalize !important;
    font-family: "Poppins", sans-serif !important;
    font-size: 25px;
    font-weight: bold;
  }
  .css-1h9z7r5-MuiButtonBase-root-MuiTab-root.Mui-selected {
    color: black;
  }
  .css-1aquho2-MuiTabs-indicator {
    background-color: black;
    height: 3px !important;
  }
`;

const BoxContainer = styled.div`
  .css-1auycx3-MuiAutocomplete-root
    .MuiOutlinedInput-root.MuiInputBase-sizeSmall {
    padding: 7px !important;
    width: 156px;
    @media (min-width: 1920px) {
      width: 250px;
    }
  }
  display: flex;
  align-items: center;
  gap: 5px;
  @media (min-width: 1920px) {
    display: flex;
    gap: 15px;
  }
  margin-top: 5px;
`;

const CustomeAutocomplete = styled(Autocomplete)`
  && {
    /* width: 150px; */
    margin-top: unset !important;
  }
  .css-1d3z3hw-MuiOutlinedInput-notchedOutline {
    outline: unset !important ;
    border-color: #d4d4d4 !important;
    border-width: 1px !important;
  }
  margin-top: 3px;
  button {
    padding: 0;
  }
  .css-19qh8xo-MuiInputBase-input-MuiOutlinedInput-input {
    height: 1rem !important;
  }
`;

const SelectBox1 = styled.div`
  .css-1869usk-MuiFormControl-root {
    min-width: 156px !important;
    margin: unset !important;
    @media (min-width: 1920px) {
      width: 250px;
    }
  }

  .css-1auycx3-MuiAutocomplete-root
    .MuiOutlinedInput-root
    .MuiAutocomplete-endAdornment {
    top: -1px !important;
  }
  .MuiOutlinedInput-notchedOutline {
    border-color: #d4d4d4 !important;
    border-width: 1px !important ;
    outline: unset !important;
  }

  div div div {
    padding: 3px;
  }
  .css-1auycx3-MuiAutocomplete-root
    .MuiOutlinedInput-root.MuiInputBase-sizeSmall
    .MuiAutocomplete-input {
    padding: 0px 4px 0px 6px;
  }

  em {
    font-style: normal !important;
    font-family: unset !important;
  }
  .css-11u53oe-MuiSelect-select-MuiInputBase-input-MuiOutlinedInput-input.css-11u53oe-MuiSelect-select-MuiInputBase-input-MuiOutlinedInput-input.css-11u53oe-MuiSelect-select-MuiInputBase-input-MuiOutlinedInput-input {
    padding-left: 12px !important;
  }
`;

const SearchButton = styled(Button)`
  && {
    background: #009e15;
    color: #fff;
    align-self: self-end;
    margin-bottom: 6px;
    border-radius: 4px;
    padding: 3px 32px;
    text-transform: capitalize;
    @media (min-width: 1920px) {
      width: 150px;
    }
    &:hover {
      background: #009e15;
    }
  }
`;
const AllBoxesContainer = styled.div`
  display: flex;
  align-items: center;
  width: 100%;
  gap: 10px;
`;
const SubContainer = styled.div``;

const LabelTxt = styled.label`
  font-size: 15px;
  color: black;
  width: 100%;
  padding-left: 1px;
`;
const Field1 = styled.div``;
const EditContainer = styled.div`
  display: flex;

  align-items: center;

  height: 41px;
`;
