import { FormControl, MenuItem, Pagination, Select } from "@mui/material";
import React, { useState } from "react";
import styled from "styled-components/macro";

function WebEnquiryLiist() {
  const [enquiryList, setEnquiryList] = useState({
    data: [
      {
        id: "1",
        date: "09 june 2021",
        time: "10:00 AM",
        user: "uvais",
        phone: "1234567654",
        email: "uvais@mail.com",
        reason: "upgrade",
        message: "Product group deleted failed",
        status: "solved",
      },

      {
        id: "2",
        date: "09 june 2021",
        time: "10:00 AM",
        user: "jasmal",
        phone: "1234567898",
        email: "uvais@mail.com",
        reason: "complaint",
        message: "Product group deleted failed",
        status: "pending",
      },
      {
        id: "3",
        date: "09 june 2021",
        time: "10:00 AM",
        user: "abhi",
        phone: "4321234567",
        email: "uvais@mail.com",
        reason: "complaint",
        message: "Product group deleted failed",
        status: "declined",
      },
      {
        id: "34",
        date: "09 june 2021",
        time: "10:00 AM",
        user: "abhi",
        phone: "4321234567",
        email: "uvais@mail.com",
        reason: "complaint",
        message: "Product group deleted failed",
        status: "declined",
      },
      {
        id: "5",
        date: "09 june 2021",
        time: "10:00 AM",
        user: "abhi",
        phone: "4321234567",
        email: "uvais@mail.com",
        reason: "complaint",
        message: "Product group deleted failed",
        status: "declined",
      },
      {
        id: "6",
        date: "09 june 2021",
        time: "10:00 AM",
        user: "abhi",
        phone: "4321234567",
        email: "uvais@mail.com",
        reason: "complaint",
        message: "Product group deleted failed",
        status: "declined",
      },
      {
        id: "7",
        date: "09 june 2021",
        time: "10:00 AM",
        user: "abhi",
        phone: "4321234567",
        email: "uvais@mail.com",
        reason: "complaint",
        message: "Product group deleted failed",
        status: "declined",
      },
      {
        id: "8",
        date: "09 june 2021",
        time: "10:00 AM",
        user: "abhi",
        phone: "4321234567",
        email: "uvais@mail.com",
        reason: "complaint",
        message: "Product group deleted failed",
        status: "declined",
      },
      {
        id: "9",
        date: "09 june 2021",
        time: "10:00 AM",
        user: "abhi",
        phone: "4321234567",
        email: "uvais@mail.com",
        reason: "complaint",
        message: "Product group deleted failed",
        status: "declined",
      },
      {
        id: "10",
        date: "09 june 2021",
        time: "10:00 AM",
        user: "abhi",
        phone: "4321234567",
        email: "uvais@mail.com",
        reason: "complaint",
        message: "Product group deleted failed",
        status: "declined",
      },
      {
        id: "11",
        date: "09 june 2021",
        time: "10:00 AM",
        user: "abhi",
        phone: "4321234567",
        email: "uvais@mail.com",
        reason: "complaint",
        message: "Product group deleted failed",
        status: "declined",
      },
      {
        id: "12",
        date: "09 june 2021",
        time: "10:00 AM",
        user: "abhi",
        phone: "4321234567",
        email: "uvais@mail.com",
        reason: "complaint",
        message: "Product group deleted failed",
        status: "declined",
      },
      {
        id: "13",
        date: "09 june 2021",
        time: "10:00 AM",
        user: "abhi",
        phone: "4321234567",
        email: "uvais@mail.com",
        reason: "complaint",
        message: "Product group deleted failed",
        status: "declined",
      },
      {
        id: "14",
        date: "09 june 2021",
        time: "10:00 AM",
        user: "abhi",
        phone: "4321234567",
        email: "uvais@mail.com",
        reason: "complaint",
        message: "Product group deleted failed",
        status: "declined",
      },
      {
        id: "15",
        date: "09 june 2021",
        time: "10:00 AM",
        user: "abhi",
        phone: "4321234567",
        email: "uvais@mail.com",
        reason: "complaint",
        message: "Product group deleted failed",
        status: "declined",
      },
      {
        id: "316",
        date: "09 june 2021",
        time: "10:00 AM",
        user: "abhi",
        phone: "4321234567",
        email: "uvais@mail.com",
        reason: "complaint",
        message: "Product group deleted failed",
        status: "declined",
      },
      {
        id: "17",
        date: "09 june 2021",
        time: "10:00 AM",
        user: "abhi",
        phone: "4321234567",
        email: "uvais@mail.com",
        reason: "complaint",
        message: "Product group deleted failed",
        status: "declined",
      },
      {
        id: "18",
        date: "09 june 2021",
        time: "10:00 AM",
        user: "abhi",
        phone: "4321234567",
        email: "uvais@mail.com",
        reason: "complaint",
        message: "Product group deleted failed",
        status: "declined",
      },
      {
        id: "19",
        date: "09 june 2021",
        time: "10:00 AM",
        user: "abhi",
        phone: "4321234567",
        email: "uvais@mail.com",
        reason: "complaint",
        message: "Product group deleted failed",
        status: "declined",
      },
      {
        id: "20",
        date: "09 june 2021",
        time: "10:00 AM",
        user: "abhi",
        phone: "4321234567",
        email: "uvais@mail.com",
        reason: "complaint",
        message: "Product group deleted failed",
        status: "declined",
      },
      {
        id: "21",
        date: "09 june 2021",
        time: "10:00 AM",
        user: "abhi",
        phone: "4321234567",
        email: "uvais@mail.com",
        reason: "complaint",
        message: "Product group deleted failed",
        status: "declined",
      },
      {
        id: "22",
        date: "09 june 2021",
        time: "10:00 AM",
        user: "abhi",
        phone: "4321234567",
        email: "uvais@mail.com",
        reason: "complaint",
        message: "Product group deleted failed",
        status: "declined",
      },
      {
        id: "23",
        date: "09 june 2021",
        time: "10:00 AM",
        user: "abhi",
        phone: "4321234567",
        email: "uvais@mail.com",
        reason: "complaint",
        message: "Product group deleted failed",
        status: "declined",
      },
      {
        id: "24",
        date: "09 june 2021",
        time: "10:00 AM",
        user: "abhi",
        phone: "4321234567",
        email: "uvais@mail.com",
        reason: "complaint",
        message: "Product group deleted failed",
        status: "declined",
      },
    ],
  });
  const [currentPage, setCurrentPage] = useState(1);
  const handleChange = (index) => (event) => {
    let data = [...enquiryList.data];
    if (currentPage != 1) {
      index = index + 10 * (currentPage - 1);
    }
    console.log(index);
    data[index]["status"] = event.target.value;
    console.log("=============================");
    console.log(data);
    setEnquiryList({ data });
  };

  //pagination=======================================

  const [itemsPerPage, setItemsPerPage] = useState(10);

  const IndexofLastItem = currentPage * itemsPerPage;
  const indexOfFirstDish = IndexofLastItem - itemsPerPage;
  let PaginatedData = enquiryList.data.slice(indexOfFirstDish, IndexofLastItem);
  console.log("PaginatedData>>>>>>>>>>>>>>>>>>>>>>>>");
  console.log(PaginatedData);
  const ChangePage = (event, value) => {
    setCurrentPage(value);
  };

  const NumOfpages = Math.ceil(enquiryList.data.length / itemsPerPage);
  return (
    <TableContainer>
      <Table>
        <THead>
          <TableHeadRow>
            <TH> ID </TH>
            <TH> Date & Time </TH>
            <TH> User </TH>
            <TH> Phone </TH>
            <TH> Email Addresss</TH>
            <TH> Reason</TH>
            <TH> Message </TH>
            <TH style={{ width: "199px" }}>Status</TH>
          </TableHeadRow>
        </THead>
        <TBody>
          {PaginatedData.map((i, index) => (
            <TableBodyRow>
              <TD> {i.id} </TD>
              <TD>
                <span style={{ fontSize: "13px" }}>{i.date} </span>
                <h4 style={{ fontSize: "13px" }}>{i.time} </h4>
              </TD>
              <TD> {i.user} </TD>
              <TD> {i.phone} </TD>
              <TD> {i.email} </TD>
              <TD> {i.reason} </TD>
              <TD> {i.message} </TD>

              <TD style={{ padding: "5px 6px !important " }}>
                <SelectBox1 status={i.status}>
                  <FormControl sx={{ m: 1, minWidth: 115 }}>
                    <Select
                      value={i.status}
                      onChange={handleChange(index)}
                      MenuProps={{
                        disableScrollLock: true,
                      }}
                    >
                      <MenuItems value={"solved"}>Solved</MenuItems>

                      <MenuItems value={"pending"}>Pending</MenuItems>
                      <MenuItems value={"declined"}>Declined</MenuItems>
                    </Select>
                  </FormControl>
                </SelectBox1>
              </TD>
            </TableBodyRow>
          ))}
        </TBody>
      </Table>
      <PaginationContainer>
        <Pagination count={NumOfpages} onChange={ChangePage} />
      </PaginationContainer>
    </TableContainer>
  );
}
export default WebEnquiryLiist;
const MenuItems = styled(MenuItem)`
  font-size: 13px !important;
`;
const PaginationContainer = styled.div`
  width: 100%;
  display: flex;
  margin-top: 10px;
  justify-content: center;
`;
const SelectBox1 = styled.div`
  .css-1yk1gt9-MuiInputBase-root-MuiOutlinedInput-root-MuiSelect-root {
    font-size: 12px !important ;

    background-color: ${({ status }) =>
      status === "solved"
        ? "#009a05"
        : status === "pending"
        ? "#9A0000"
        : status === "declined"
        ? "black"
        : null};
    /* background-color: #009a05; */
    color: white;
  }
  .css-hfutr2-MuiSvgIcon-root-MuiSelect-icon {
    color: white !important;
  }
  .css-bpeome-MuiSvgIcon-root-MuiSelect-icon {
    color: white !important;
  }
  .css-1869usk-MuiFormControl-root {
    min-width: 175px !important;
    margin: unset !important;
    @media (min-width: 1920px) {
      width: 250px;
    }
  }

  .MuiOutlinedInput-notchedOutline {
    border: unset;

    border-width: 1px !important ;

    outline: unset !important;
  }

  div div div {
    padding: 6px;
  }

  em {
    font-style: normal !important;
    font-family: unset !important;
  }

  .css-11u53oe-MuiSelect-select-MuiInputBase-input-MuiOutlinedInput-input.css-11u53oe-MuiSelect-select-MuiInputBase-input-MuiOutlinedInput-input.css-11u53oe-MuiSelect-select-MuiInputBase-input-MuiOutlinedInput-input {
    padding-left: 12px !important;
  }
  .css-38aidw-MuiFormControl-root {
    margin: unset !important;
  }
`;
const TableContainer = styled.div`
  margin-top: 15px;
`;
const TD = styled.td`
  padding: 5px 15px;
  text-align: left;
  font-size: 13px;
  padding: 0.5em 1em;
  border-bottom: 1px solid #ababab;
  vertical-align: middle;

  &.cursor {
    cursor: pointer;
  }
`;
const TableBodyRow = styled.tr`
  :hover {
    background-color: rgba(0, 0, 0, 0.04);
  }
`;
const Table = styled.table`
  border-radius: 15px;
  width: 100%;
  background: #fff;
  border-spacing: unset;
`;

const THead = styled.thead`
  box-shadow: 0 0 0 1px #c6c6c6;
  border-radius: 3px;
  background-color: black;
  color: white;
`;
const TableHeadRow = styled.tr``;
const TBody = styled.tbody``;
const TH = styled.th`
  padding: 5px 10px;
  font-weight: normal;
  text-align: left;
  font-size: 14px;
`;
