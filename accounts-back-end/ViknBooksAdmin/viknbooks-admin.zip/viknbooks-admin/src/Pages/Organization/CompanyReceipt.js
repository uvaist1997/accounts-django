import React, { useState } from "react";
import styled from "styled-components/macro";
import CreateButton from "../../Components/CreateButton";
import DatePicker from "../../Components/DatePicker";
import { IconButton, Menu, MenuItem } from "@mui/material";
import MoreVertIcon from "@mui/icons-material/MoreVert";
import SaveButton from "../../Components/SaveButton";
import {
  Autocomplete,
  Button,
  FormControl,
  Select,
  TextField,
} from "@mui/material";
import Pagination from "@mui/material/Pagination";
import CreateReceipt from "./CreateReceipt";
function CompanyReceipt() {
  const options = ["Edit", "Delete", "View"];
  const [anchorEl, setAnchorEl] = useState(null);
  const handle = (event, newValue) => {
    setValue(newValue);
  };
  const [value, setValue] = useState(0);
  const [show, setShow] = useState(true);
  const [age, setAge] = useState("");
  const open = Boolean(anchorEl);
  const [currentIndex, setCurrentIndex] = useState();
  const handleClick = (index) => (event) => {
    setAnchorEl(event.currentTarget);
    setCurrentIndex(index);
  };
  const handleClose = () => {
    setAnchorEl(null);
  };
  const handleChange = (event) => {
    setAge(event.target.value);
  };
  const ITEM_HEIGHT = 48;
  const [receipt, setReceipt] = useState({
    data: [
      {
        slno: "1",
        voucherNo: "14520",

        Organization: "vikncodes",
        paymentmode: "By Cash",
        discount: "10%",
        total: "198197",
      },

      {
        slno: "2",
        voucherNo: "6750",
        Organization: "vikncodes",
        paymentmode: "COD",
        discount: "10%",
        total: "7697",
      },
      {
        slno: "3",
        voucherNo: "145640",
        Organization: "vikncodes",
        paymentmode: "COD",
        discount: "10%",
        total: "8197",
      },
      {
        slno: "4",
        voucherNo: "145640",
        Organization: "vikncodes",
        paymentmode: "COD",
        discount: "10%",
        total: "8197",
      },
      {
        slno: "5",
        voucherNo: "145640",
        Organization: "vikncodes",
        paymentmode: "COD",
        discount: "10%",
        total: "8197",
      },
      {
        slno: "6",
        voucherNo: "145640",
        Organization: "vikncodes",
        paymentmode: "COD",
        discount: "10%",
        total: "8197",
      },
      {
        slno: "7",
        voucherNo: "145640",
        Organization: "vikncodes",
        paymentmode: "COD",
        discount: "10%",
        total: "8197",
      },
      {
        slno: "8",
        voucherNo: "145640",
        Organization: "vikncodes",
        paymentmode: "COD",
        discount: "10%",
        total: "8197",
      },
      {
        slno: "9",
        voucherNo: "145640",
        Organization: "vikncodes",
        paymentmode: "COD",
        discount: "10%",
        total: "8197",
      },
      {
        slno: "10",
        voucherNo: "145640",
        Organization: "vikncodes",
        paymentmode: "COD",
        discount: "10%",
        total: "8197",
      },
      {
        slno: "11",
        voucherNo: "145640",
        Organization: "vikncodes",
        paymentmode: "COD",
        discount: "10%",
        total: "8197",
      },
      {
        slno: "12",
        voucherNo: "145640",
        Organization: "vikncodes",
        paymentmode: "COD",
        discount: "10%",
        total: "8197",
      },
      {
        slno: "13",
        voucherNo: "145640",
        Organization: "vikncodes",
        paymentmode: "COD",
        discount: "10%",
        total: "8197",
      },
      {
        slno: "14",
        voucherNo: "145640",
        Organization: "vikncodes",
        paymentmode: "COD",
        discount: "10%",
        total: "8197",
      },
      {
        slno: "15",
        voucherNo: "145640",
        Organization: "vikncodes",
        paymentmode: "COD",
        discount: "10%",
        total: "8197",
      },
      {
        slno: "16",
        voucherNo: "145640",
        Organization: "vikncodes",
        paymentmode: "COD",
        discount: "10%",
        total: "8197",
      },
      {
        slno: "17",
        voucherNo: "145640",
        Organization: "vikncodes",
        paymentmode: "COD",
        discount: "10%",
        total: "8197",
      },
      {
        slno: "18",
        voucherNo: "145640",
        Organization: "vikncodes",
        paymentmode: "COD",
        discount: "10%",
        total: "8197",
      },
      {
        slno: "19",
        voucherNo: "145640",
        Organization: "vikncodes",
        paymentmode: "COD",
        discount: "10%",
        total: "8197",
      },
      {
        slno: "20",
        voucherNo: "145640",
        Organization: "vikncodes",
        paymentmode: "COD",
        discount: "10%",
        total: "8197",
      },
      {
        slno: "21",
        voucherNo: "145640",
        Organization: "vikncodes",
        paymentmode: "COD",
        discount: "10%",
        total: "8197",
      },
      {
        slno: "22",
        voucherNo: "145640",
        Organization: "vikncodes",
        paymentmode: "COD",
        discount: "10%",
        total: "8197",
      },
      {
        slno: "23",
        voucherNo: "145640",
        Organization: "vikncodes",
        paymentmode: "COD",
        discount: "10%",
        total: "8197",
      },
      {
        slno: "24",
        voucherNo: "145640",
        Organization: "vikncodes",
        paymentmode: "COD",
        discount: "10%",
        total: "8197",
      },
      {
        slno: "25",
        voucherNo: "145640",
        Organization: "vikncodes",
        paymentmode: "COD",
        discount: "10%",
        total: "8197",
      },
      {
        slno: "26",
        voucherNo: "145640",
        Organization: "vikncodes",
        paymentmode: "COD",
        discount: "10%",
        total: "8197",
      },
      {
        slno: "28",
        voucherNo: "145640",
        Organization: "vikncodes",
        paymentmode: "COD",
        discount: "10%",
        total: "8197",
      },
      {
        slno: "29",
        voucherNo: "145640",
        Organization: "vikncodes",
        paymentmode: "COD",
        discount: "10%",
        total: "8197",
      },
      {
        slno: "30",
        voucherNo: "145640",
        Organization: "vikncodes",
        paymentmode: "COD",
        discount: "10%",
        total: "8197",
      },
    ],
  });

  //pagination=======================================

  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage, setItemsPerPage] = useState(18);

  const IndexofLastItem = currentPage * itemsPerPage;
  const indexOfFirstDish = IndexofLastItem - itemsPerPage;
  let PaginatedData = receipt.data.slice(indexOfFirstDish, IndexofLastItem);

  const ChangePage = (event, value) => {
    setCurrentPage(value);
  };

  const NumOfpages = Math.ceil(receipt.data.length / itemsPerPage);
  return (
    <Container>
      {show ? (
        <>
          <Heading>
            <LeftContainer>
              <ReceiptsTxt>Receipts</ReceiptsTxt>
              <BoxContainer>
                <DatePicker />
              </BoxContainer>
            </LeftContainer>

            <CreateButtonContainer onClick={() => setShow(!show)}>
              <CreateButton label={"Add New"} />
            </CreateButtonContainer>
          </Heading>

          <TableContainer>
            <Table>
              <THead>
                <TableHeadRow>
                  <TH> SI No </TH>
                  <TH> Voucher No </TH>
                  <TH> Organization </TH>
                  <TH>Payment Mode </TH>
                  <TH> Discount </TH>
                  <TH> Total </TH>

                  <TH></TH>
                </TableHeadRow>
              </THead>
              <TBody>
                {PaginatedData.map((i, index) => (
                  <TableBodyRow>
                    <TD>{i.slno}</TD>
                    <TD>{i.voucherNo}</TD>
                    <TD>{i.Organization}</TD>
                    <TD>{i.paymentmode}</TD>
                    <TD>{i.discount}</TD>
                    <TD>{i.total}</TD>

                    <TD style={{ textAlign: "right" }}>
                      <RightSide>
                        <IconButton
                          aria-label="more"
                          // id={index}
                          aria-controls={open ? "long-menu" : undefined}
                          aria-expanded={open ? "true" : undefined}
                          aria-haspopup="true"
                          onClick={handleClick(index)}
                        >
                          <MoreVertIcon />
                        </IconButton>

                        {index === currentIndex ? (
                          <Menus
                            // id="long-menu"
                            disableScrollLock={true}
                            MenuListProps={
                              {
                                // "aria-labelledby": ` ${index}`,
                              }
                            }
                            anchorEl={anchorEl}
                            open={open}
                            onClose={handleClose}
                            PaperProps={{
                              style: {
                                maxHeight: ITEM_HEIGHT * 4.5,
                                width: "20ch",
                              },
                            }}
                          >
                            {options.map((option) => (
                              <MenuItem
                                key={option}
                                selected={option === "Edit"}
                                onClick={handleClose}
                              >
                                {option}
                              </MenuItem>
                            ))}
                          </Menus>
                        ) : null}
                      </RightSide>
                    </TD>
                  </TableBodyRow>
                ))}
              </TBody>
            </Table>

            <PaginationContainer>
              <Pagination count={NumOfpages} onChange={ChangePage} />
            </PaginationContainer>
          </TableContainer>
        </>
      ) : (
        //    Add Receipt........................
        <>
          <CreateReceipt />
        </>
      )}
    </Container>
  );
}

export default CompanyReceipt;

const PaginationContainer = styled.div`
  width: 100%;
  display: flex;
  margin-top: 10px;
  justify-content: center;
`;
const Container = styled.div``;
const Heading = styled.div`
  width: 100%;
  display: flex;
  justify-content: space-between;
`;
const LeftContainer = styled.div`
  display: flex;
  gap: 18px;
  align-items: center;
`;
const ReceiptsTxt = styled.h2`
  font-size: 19px;
  letter-spacing: 1px; ;
`;

const CreateReceiptTxt = styled(ReceiptsTxt)``;
const CreateButtonContainer = styled.div`
  position: relative;
`;
const SaveButtonContainer = styled(CreateButtonContainer)``;

const BoxContainer = styled.div`
  .css-1auycx3-MuiAutocomplete-root
    .MuiOutlinedInput-root.MuiInputBase-sizeSmall {
    padding: 7px !important;
    width: 156px;
    @media (min-width: 1920px) {
      width: 250px;
    }
  }
  display: flex;
  align-items: center;
  gap: 5px;
  @media (min-width: 1920px) {
    display: flex;
    gap: 15px;
  }
`;

const Menus = styled(Menu)`
  && {
    .css-1poimk-MuiPaper-root-MuiMenu-paper-MuiPaper-root-MuiPopover-paper {
      width: 17ch !important;
      left: 1212px !important;
      @media (width: 1309.09px) {
        left: 1083px !important;
      }
      @media (width: 1920px) {
        left: 1687px !important;
      }
      @media (width: 1600px) {
        left: 1371px !important;
      }
      @media (width: 1800px) {
        left: 98rem !important;
      }
      ::-webkit-scrollbar {
        display: none !important;
      }
    }
  }
`;
const RightSide = styled.div`
  height: 100%;
  svg {
    font-size: 1.1rem !important ;
    color: black !important;
  }
  .css-78trlr-MuiButtonBase-root-MuiIconButton-root {
    padding: unset !important;
  }
  .MuiPaper-root {
    box-shadow: none !important;
  }
`;

const TableContainer = styled.div`
  margin-top: 15px;
`;
const TD = styled.td`
  font-size: 12px;
  padding: 5px 15px !important;
  text-align: left;

  border-bottom: 1px solid #ababab;
  vertical-align: middle;

  &.cursor {
    cursor: pointer;
  }
`;
const TableBodyRow = styled.tr`
  :hover {
    background-color: rgba(0, 0, 0, 0.04);
  }
`;
const Table = styled.table`
  border-radius: 15px;
  width: 100%;
  background: #fff;
  border-spacing: unset;
`;

const THead = styled.thead`
  box-shadow: 0 0 0 1px #c6c6c6;
  border-radius: 3px;
  background-color: black;
  color: white;
`;
const TableHeadRow = styled.tr``;
const TBody = styled.tbody``;
const TH = styled.th`
  padding: 5px 15px;
  font-weight: normal;
  text-align: left;
  font-size: 14px;
`;
