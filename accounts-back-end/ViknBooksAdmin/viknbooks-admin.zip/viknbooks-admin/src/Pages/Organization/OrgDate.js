import React, { useState } from "react";
import ReactDOM from "react-dom";
import DateRangePicker from "@wojtekmaj/react-daterange-picker";
import styled from "styled-components/macro";
function OrgDate() {
  const [date, setDate] = useState([new Date(), new Date()]);

  const onChange = (date) => setDate(date);
  return (
    <DateContainer>
      <DateRangePicker onChange={onChange} value={date} />
    </DateContainer>
  );
}

export default OrgDate;
const DateContainer = styled.div`
  && {
    font-size: 10px;
    .react-daterange-picker__button {
      padding: 0px 2px;
    }
    .react-daterange-picker {
      /* width: 20px !important; */
      width: 97%;
      position: unset !important;
    }
    .react-daterange-picker__inputGroup {
      /* height: 25px; */
    }
    .react-daterange-picker__inputGroup__input {
      outline: none;
    }

    .react-daterange-picker__wrapper {
      background-color: rgb(248, 213, 213) !important;
      border: unset;
      padding: 5px;

      border-radius: 2px;
    }
  }
  .react-daterange-picker__calendar {
    inset: 42% auto auto 16px !important;
  }
  .react-calendar__month-view__weekdays {
    font-size: 10px;
  }
  .react-daterange-picker,
  .react-daterange-picker *,
  .react-daterange-picker *:before,
  .react-daterange-picker *:after {
    text-decoration: none !important;
  }
  .react-calendar__tile--active {
    background-color: rgb(248, 213, 213) !important;
  }
  .react-calendar__tile--now:enabled:hover,
  .react-calendar__tile--now:enabled:focus {
    background-color: rgb(84, 71, 160) !important;
    color: white;
  }
  .react-calendar__tile--hasActive {
    background-color: rgb(84, 71, 160) !important;
    color: white;
  }
  .react-calendar__tile--now {
    background-color: rgb(84, 71, 160) !important;
    color: white;
  }
  .react-daterange-picker__calendar .react-calendar {
    padding: 8px;
  }
`;
