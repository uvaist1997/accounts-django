import React, { useRef, useState, useEffect, useLayoutEffect } from "react";
import styled from "styled-components/macro";
import SaveButton from "../../Components/SaveButton";
import { SnackbarProvider, useSnackbar } from "notistack";
import DatePicker from "../../Components/DatePicker";
import {
  Autocomplete,
  FormControl,
  MenuItem,
  Select,
  TextField,
} from "@mui/material";

import Box from "@mui/material/Box";
import Fab from "@mui/material/Fab";
import AddIcon from "@mui/icons-material/Add";
import PercentIcon from "@mui/icons-material/Percent";
import { DesktopDatePicker, LocalizationProvider } from "@mui/x-date-pickers";
import { AdapterDateFns } from "@mui/x-date-pickers/AdapterDateFns";
function CreateInvoice() {
  const { enqueueSnackbar } = useSnackbar();
  const handleClickVariant = (variant) => () => {
    // variant could be success, error, warning, info, or default
    enqueueSnackbar(" Saved Successfully !", { variant });
  };
  const messagesEndRef = useRef(null);
  const [state, setState] = useState({
    data: ["uvais", "jasmal", "abhi"],
    serviceData: [
      {
        upgrade: "",
        downgrade: "",
        users: "",
        services: "",
        validity: "",
      },
    ],
  });

  const scrollToBottom = () => {
    messagesEndRef.current.scrollIntoView({
      behavior: "smooth",
      block: "end",
      inline: "nearest",
    });
  };
  useEffect(scrollToBottom, [state.serviceData]);
  const addService = () => {
    let serviceData = [...state.serviceData];
    serviceData.push({
      upgrade: "",
      downgrade: "",
      users: "",
      services: "",
      validity: "",
    });
    setState({
      ...state,
      serviceData,
    });
  };
  const [days, setDays] = useState("day");

  const [age, setAge] = useState();
  const [services, setServices] = useState("upgrade");
  const handleChange = (event) => {
    setServices(event.target.value);
  };
  const handleSelectChange = () => {
    console.log("select");
  };
  const ReadallData = (e) => {
    sessionStorage(e.target.value);
  };
  const ReadallDays = (e) => {
    setDays(e.target.value);
  };
  const DateChange = (newValue) => {
    setValue(newValue);
  };
  const [value, setValue] = React.useState(new Date("2014-08-18T21:11:54"));

  const [show, setShow] = useState();
  return (
    <>
      <Heading>
        <LeftContainer>
          <CreateInvoiceTxt>Create Invoices</CreateInvoiceTxt>
        </LeftContainer>
        <SnackbarProvider maxSnack={3}>
          <SaveButtonContainer onClick={handleClickVariant("success")}>
            <SaveButton label={"Save"} />
          </SaveButtonContainer>
        </SnackbarProvider>
      </Heading>
      <AllBoxesContainer>
        <DateContainer>
          <Label>Date </Label>

          <DateBox>
            <LocalizationProvider dateAdapter={AdapterDateFns}>
              <DesktopDatePicker
                inputFormat="MM/dd/yyyy"
                value={value}
                onChange={DateChange}
                renderInput={(params) => <TextField {...params} />}
              />
            </LocalizationProvider>
          </DateBox>
        </DateContainer>
        <SubContainer>
          <LabelTxt>Invoice No</LabelTxt>

          <Field1>
            <EditContainer>
              <CustomTextField id="outlined-basic" variant="outlined" />
            </EditContainer>
          </Field1>
        </SubContainer>
        <SubContainer>
          <LabelTxt>Organization</LabelTxt>

          <Field1>
            <EditContainer>
              <SelectBox1>
                <CustomTextField id="outlined-basic" variant="outlined" />
              </SelectBox1>
            </EditContainer>
          </Field1>
        </SubContainer>
        <SubContainer>
          <LabelTxt>User</LabelTxt>

          <Field1>
            <EditContainer>
              <CustomeAutocomplete
                size="small"
                id="combo-box-demo"
                options={state.data}
                // getOptionLabel={(option) => option.username || ""}
                onInputChange={(event, value, reason) => {}}
                onChange={(e, v) => handleSelectChange("ReportUserID", v)}
                renderInput={(params) => <TextField size="small" {...params} />}
              />
            </EditContainer>
          </Field1>
        </SubContainer>

        <SubContainer>
          <LabelTxt>Referal</LabelTxt>

          <Field1>
            <EditContainer>
              <CustomTextField id="outlined-basic" variant="outlined" />
            </EditContainer>
          </Field1>
        </SubContainer>
      </AllBoxesContainer>

      <BodyContainer>
        <MainContainer>
          {state.serviceData.map((i) => (
            <Row>
              <DateContainer>
                <NameTxt>Service</NameTxt>

                <SelectBox1>
                  <FormControl sx={{ m: 1, minWidth: 120 }}>
                    <Select
                      value={services}
                      onChange={handleChange}
                      displayEmpty
                      defaultValue="Status"
                      MenuProps={{ disableScrollLock: true }}
                    >
                      {/* <MenuItem value=""><em>Status</em></MenuItem> */}
                      <MenuItem value={"upgrade"}>Upgrade</MenuItem>
                      <MenuItem value={"downgrade"}>Downgrade</MenuItem>
                      <MenuItem value={"users"}>Users</MenuItem>
                      <MenuItem value={"validity"}>Validity</MenuItem>
                      <MenuItem value={"service"}>Service</MenuItem>
                    </Select>
                  </FormControl>
                </SelectBox1>
              </DateContainer>
              {services === "upgrade" || services === "downgrade" ? (
                <ChangebleContainer>
                  <DateContainer>
                    <NameTxt>Edition</NameTxt>

                    <SelectBox1>
                      <FormControl sx={{ m: 1, minWidth: 120 }}>
                        <Select
                          MenuProps={{ disableScrollLock: true }}
                          value={age}
                          onChange={ReadallData}
                          displayEmpty
                          defaultValue="Status"
                        >
                          <MenuItem value="">{/* <em>Status</em> */}</MenuItem>
                          <MenuItem value={10}>Professional</MenuItem>
                        </Select>
                      </FormControl>
                    </SelectBox1>
                  </DateContainer>
                  <DateContainer>
                    <NameTxt>Rate</NameTxt>
                    <TextFieldContainer>
                      <CustomTextField2
                        id="outlined-basic"
                        variant="outlined"
                      />
                    </TextFieldContainer>
                  </DateContainer>
                  <DateContainer>
                    <NameTxt>Discount</NameTxt>
                    <TextFieldContainer>
                      <CustomTextField3
                        id="outlined-basic"
                        variant="outlined"
                      />

                      <CustomTextField2
                        id="outlined-basic"
                        variant="outlined"
                      />
                      <PercentageIcon />
                    </TextFieldContainer>
                  </DateContainer>

                  <MultiContainer>
                    <MultiplicationContainer>
                      <NumberTxt>Rs.&nbsp;&nbsp;1500</NumberTxt>
                      <span> &nbsp;× &nbsp;</span>
                      <NumberTxt>1</NumberTxt>
                    </MultiplicationContainer>

                    <AmountContainer>
                      <AmountTxt>Amount</AmountTxt>
                      <NumberTxt>Rs.&nbsp;1500</NumberTxt>
                    </AmountContainer>
                  </MultiContainer>
                </ChangebleContainer>
              ) : services === "users" ? (
                <ChangebleContainer>
                  <DateContainer>
                    <NameTxt>Rate</NameTxt>

                    <EditContainer>
                      <CustomTextField_Rate
                        id="outlined-basic"
                        variant="outlined"
                      />
                    </EditContainer>
                  </DateContainer>
                  <DateContainer>
                    <NameTxt>No of users</NameTxt>
                    <TextFieldContainer>
                      <CustomTextField2
                        id="outlined-basic"
                        variant="outlined"
                      />
                    </TextFieldContainer>
                  </DateContainer>
                  <DateContainer>
                    <NameTxt>Discount</NameTxt>
                    <TextFieldContainer>
                      <CustomTextField3
                        id="outlined-basic"
                        variant="outlined"
                      />

                      <CustomTextField2
                        id="outlined-basic"
                        variant="outlined"
                      />
                      <PercentageIcon />
                    </TextFieldContainer>
                  </DateContainer>
                  <MultiplicationContainer>
                    <NumberTxt>Rs.&nbsp;&nbsp;1500</NumberTxt>
                    <span> &nbsp;× &nbsp;</span>
                    <NumberTxt>1</NumberTxt>
                  </MultiplicationContainer>

                  <AmountContainer>
                    <AmountTxt>Amount</AmountTxt>
                    <NumberTxt>Rs.&nbsp;1500</NumberTxt>
                  </AmountContainer>
                </ChangebleContainer>
              ) : services === "validity" ? (
                <ChangebleContainer>
                  <DateContainer>
                    <NameTxt>In</NameTxt>

                    <SelectBox2>
                      <FormControl sx={{ m: 1, minWidth: 120 }}>
                        <Select
                          value={days}
                          onChange={ReadallDays}
                          displayEmpty
                        >
                          <MenuItem value={"day"}>Days</MenuItem>
                          <MenuItem value={"month"}>Month</MenuItem>
                          <MenuItem value={"year"}>Year</MenuItem>
                        </Select>
                      </FormControl>
                    </SelectBox2>
                  </DateContainer>
                  <DateContainer>
                    <NameTxt>Rate</NameTxt>

                    <EditContainer>
                      <CustomTextField_Rate2
                        id="outlined-basic"
                        variant="outlined"
                      />
                    </EditContainer>
                  </DateContainer>
                  <DateContainer>
                    <NameTxt>No of days</NameTxt>
                    <TextFieldContainer>
                      <CustomTextField2
                        id="outlined-basic"
                        variant="outlined"
                      />
                    </TextFieldContainer>
                  </DateContainer>
                  <DateContainer>
                    <NameTxt>Discount</NameTxt>
                    <TextFieldContainer>
                      <CustomTextField3
                        id="outlined-basic"
                        variant="outlined"
                      />

                      <CustomTextField2
                        id="outlined-basic"
                        variant="outlined"
                      />
                      <PercentageIcon />
                    </TextFieldContainer>
                  </DateContainer>
                  <MultiplicationContainer>
                    <NumberTxt>Rs.&nbsp;&nbsp;1500</NumberTxt>
                    <span> &nbsp;× &nbsp;</span>
                    <NumberTxt>1</NumberTxt>
                  </MultiplicationContainer>

                  <AmountContainer>
                    <AmountTxt>Amount</AmountTxt>
                    <NumberTxt>Rs.&nbsp;1500</NumberTxt>
                  </AmountContainer>
                </ChangebleContainer>
              ) : services == "service" ? (
                <ChangebleContainer>
                  <DateContainer>
                    <NameTxt>Description</NameTxt>

                    <CustomTextField_Rate
                      id="outlined-basic"
                      variant="outlined"
                      placeholder="Service Description"
                    />
                  </DateContainer>
                  <DateContainer>
                    <NameTxt>Rate</NameTxt>
                    <TextFieldContainer>
                      <CustomTextField2
                        id="outlined-basic"
                        variant="outlined"
                      />
                    </TextFieldContainer>
                  </DateContainer>
                  <DateContainer>
                    <NameTxt>Discount</NameTxt>
                    <TextFieldContainer>
                      <CustomTextField3
                        id="outlined-basic"
                        variant="outlined"
                      />

                      <CustomTextField2
                        id="outlined-basic"
                        variant="outlined"
                      />
                      <PercentageIcon />
                    </TextFieldContainer>
                  </DateContainer>
                  <MultiplicationContainer>
                    <NumberTxt>Rs.&nbsp;&nbsp;1500</NumberTxt>
                    <span> &nbsp;× &nbsp;</span>
                    <NumberTxt>1</NumberTxt>
                  </MultiplicationContainer>

                  <AmountContainer>
                    <AmountTxt>Amount</AmountTxt>
                    <NumberTxt>Rs.&nbsp;1500</NumberTxt>
                  </AmountContainer>
                </ChangebleContainer>
              ) : (
                ""
              )}
            </Row>
          ))}
        </MainContainer>
        <div style={{ height: "10px" }} ref={messagesEndRef} />
      </BodyContainer>
      <PlusBtn onClick={() => addService()}>
        <Box sx={{ "& > :not(style)": { m: 1 } }}>
          <Fab size="small" aria-label="add">
            <AddIcon />
          </Fab>
        </Box>
      </PlusBtn>
    </>
  );
}

export default function IntegrationNotistack() {
  return (
    <SnackbarProvider maxSnack={3}>
      <CreateInvoice />
    </SnackbarProvider>
  );
}

const ChangebleContainer = styled.div`
  display: flex;
  align-items: center;
  /* gap: 20px; */
  width: 100%;

  display: flex;
  justify-content: space-between;
`;
const PlusBtn = styled.div`
  display: flex;
  justify-content: flex-end;
  padding-right: 5px;
  background-color: white;
  .css-12m9wit-MuiButtonBase-root-MuiFab-root:hover {
    background-color: #2979ff !important;
  }

  .css-12m9wit-MuiButtonBase-root-MuiFab-root {
    background-color: #2979ff;
    border-radius: 4px;
    color: white !important;
    width: 35px !important;
    height: 35px !important;
  }
`;

const MainContainer = styled.div`
  :last-child {
    margin-bottom: 50px;
  }
`;
const Amoun__t = styled.div`
  display: flex;
  gap: 30px;
`;
const MultiplicationContainer = styled.div`
  display: flex;
  align-items: center;
`;

const AmountContainer = styled.div`
  display: flex;
  flex-direction: column;
  margin-right: 10px;
`;
const PercentageIcon = styled(PercentIcon)`
  && {
    font-size: 1rem !important;
  }
  position: absolute;
  top: 8px;
  right: 109px;
  @media (min-width: 1920px) {
    right: 128px;
  }
`;

const TextFieldContainer = styled.div`
  display: flex;
  gap: 10px;
  position: relative;
  /* @media (min-width: 1920px) {
    gap: 18px;
  } */
`;

const Row = styled.div`
  display: flex;
  padding: 10px;

  align-items: center;
  margin-top: 10px;
  :nth-child(1) {
    margin-top: unset;
  }

  :nth-child(-1) {
    background-color: red;
  }
  /* gap: 10px; */

  background-color: white;
  gap: 33px;
`;

const BodyContainer = styled.div`
  padding: 10px;
  background-color: #f1f1f1;
  margin-top: 10px;
  height: 45vh;
  border-radius: 3px;
  overflow-y: scroll;
  ::-webkit-scrollbar {
    display: none;
  }
`;
const DateContainer = styled.div`
  display: flex;
  flex-direction: column;
`;

const Label = styled.label`
  font-size: 15px;
  padding-left: 1px;
`;

const NameTxt = styled(Label)`
  font-size: 10px;
  font-weight: 500;
`;

const NumberTxt = styled(Label)`
  font-size: 13px;
`;

const AmountTxt = styled(Label)`
  font-size: 12px;
`;
const DateBox = styled.div`
  && {
    width: 163px;
    border-radius: 2px;
    margin-left: -11px;
  }
  .css-nxo287-MuiInputBase-input-MuiOutlinedInput-input {
    padding: 3.5px 13px !important;
  }
  .css-1d3z3hw-MuiOutlinedInput-notchedOutline {
    border: unset !important;
  }
`;

const CustomeAutocomplete = styled(Autocomplete)`
  &.css-1auycx3-MuiAutocomplete-root
    .MuiOutlinedInput-root.MuiInputBase-sizeSmall
    .MuiAutocomplete-input {
    padding: 1px 10px;
  }
  && {
    min-width: 167px;
    margin-top: unset !important;

    @media (min-width: 1920px) {
      min-width: 245px;
    }

    @media (max-width: 1920px) {
      width: 244px;
    }
  }
  .css-1d3z3hw-MuiOutlinedInput-notchedOutline {
    outline: unset !important ;
    border-color: #d4d4d4 !important;
    border-width: 1px !important;
  }
  margin-top: 3px;
  button {
    padding: 0;
  }
  .css-19qh8xo-MuiInputBase-input-MuiOutlinedInput-input {
    height: 1rem !important;
  }
`;

const SelectBox1 = styled.div`
  .css-1869usk-MuiFormControl-root {
    /* min-width: 199px !important; */
    min-width: 120px !important;
    margin: unset !important;
    @media (min-width: 1920px) {
      width: 227px;
    }
  }
  .css-1auycx3-MuiAutocomplete-root
    .MuiOutlinedInput-root
    .MuiAutocomplete-endAdornment {
    top: -1px !important;
  }
  .MuiOutlinedInput-notchedOutline {
    border-color: #d4d4d4 !important;
    border-width: 1px !important ;
    outline: unset !important;
  }

  div div div {
    padding: 4px 10px;
    font: none !important;
    font-size: 11px;
  }

  em {
    font-style: normal !important;
    font-family: unset !important;
  }
  .css-11u53oe-MuiSelect-select-MuiInputBase-input-MuiOutlinedInput-input.css-11u53oe-MuiSelect-select-MuiInputBase-input-MuiOutlinedInput-input.css-11u53oe-MuiSelect-select-MuiInputBase-input-MuiOutlinedInput-input {
    padding-left: 12px !important;
  }
`;

const SelectBox2 = styled(SelectBox1)`
  .css-1869usk-MuiFormControl-root {
    /* min-width: 199px !important; */
    min-width: 100px !important;
    margin: unset !important;
    @media (min-width: 1920px) {
      width: 140px;
    }
  }
`;

const AllBoxesContainer = styled.div`
  display: flex;
  align-items: center;
  width: 100%;
  gap: 10px;
  margin-top: 10px;
`;
const SubContainer = styled.div``;

const LabelTxt = styled.label`
  font-size: 15px;
  color: black;
  width: 100%;
  padding-left: 1px;
`;
const Field1 = styled.div``;
const EditContainer = styled.div`
  display: flex;

  align-items: center;
`;

const Heading = styled.div`
  width: 100%;
  display: flex;
  justify-content: space-between;
`;
const LeftContainer = styled.div`
  display: flex;
  gap: 18px;
  align-items: center;
`;

const CreateInvoiceTxt = styled.h2`
  font-size: 19px;
  letter-spacing: 1px; ;
`;
const SaveButtonContainer = styled.div``;
const CustomTextField = styled(TextField)`
  && {
    /* min-width: 150px; */
  }
  border: unset !important;
  outline: unset !important;
  &.css-1u3bzj6-MuiFormControl-root-MuiTextField-root {
    border-radius: 2px;
  }
  .css-1t8l2tu-MuiInputBase-input-MuiOutlinedInput-input {
    padding: 3.5px 30px 3.5px 14px !important;
  }
  .css-1d3z3hw-MuiOutlinedInput-notchedOutline {
    border-color: #d4d4d4 !important;
    border-width: 1px !important;
  }
`;

// const CustomTextField2 = styled(CustomTextField)`
//   && {
//     min-width: 100px;
//   }
// `;
const CustomTextField2 = styled(TextField)`
  border: unset !important;
  outline: unset !important;

  &.css-1u3bzj6-MuiFormControl-root-MuiTextField-root {
    border-radius: 2px;
  }
  .css-1t8l2tu-MuiInputBase-input-MuiOutlinedInput-input {
    padding: 5.6px 10px 5.6px 10px !important;
    font-size: 12px !important;
    &::-webkit-input-placeholder {
      font-size: 10px;
    }
  }
  .fXHxYA
    .css-1t8l2tu-MuiInputBase-input-MuiOutlinedInput-input:-moz-placeholder {
    font-size: 12px;
  }
  .css-1t8l2tu-MuiInputBase-input-MuiOutlinedInput-input::placeholder {
    font-size: 12px !important;
  }
  .css-1d3z3hw-MuiOutlinedInput-notchedOutline {
    border-color: #d4d4d4 !important;
    border-width: 1px !important;
  }
  && {
    width: 90px !important;

    @media (min-width: 1920px) {
      width: 105px !important;
    }
  }
`;
const CustomTextField3 = styled(CustomTextField)`
  .css-1t8l2tu-MuiInputBase-input-MuiOutlinedInput-input {
    font-size: 12px;
    padding: 5.6px 30px 5.6px 10px !important;
  }
  &.css-1u3bzj6-MuiFormControl-root-MuiTextField-root {
    width: 90px !important;
    @media (min-width: 1920px) {
      width: 105px !important;
    }
  }
`;

const CustomTextField_Rate = styled(CustomTextField)`
  .css-1t8l2tu-MuiInputBase-input-MuiOutlinedInput-input {
    font-size: 12px;
    padding: 5.6px 10px 5.6px 10px !important;
  }
  && {
    width: 150px !important;
    @media (min-width: 1920px) {
      width: 257px !important;
    }
  }
`;
const CustomTextField_Rate2 = styled(CustomTextField)`
  && {
    width: 100px !important;
    @media (min-width: 1920px) {
      width: 140px !important;
    }
  }
  .css-1t8l2tu-MuiInputBase-input-MuiOutlinedInput-input {
    font-size: 12px;

    padding: 5.6px 10px 5.6px 10px !important;
  }
`;

const MultiContainer = styled.div`
  display: flex;
  gap: 40px;
`;
