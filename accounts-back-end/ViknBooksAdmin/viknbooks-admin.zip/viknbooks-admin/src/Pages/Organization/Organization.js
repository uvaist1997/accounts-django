import React, { useEffect, useRef, useState } from "react";
import FilterListIcon from "@mui/icons-material/FilterList";
import styled from "styled-components/macro";
import Button from "@mui/material/Button";
import CreateButton from "../../Components/CreateButton";
import Card from "@mui/material/Card";
import CardContent from "@mui/material/CardContent";
import Autocomplete from "@mui/material/Autocomplete";
import FormGroup from "@mui/material/FormGroup";
import FormControlLabel from "@mui/material/FormControlLabel";
import Checkbox from "@mui/material/Checkbox";
import Box from "@mui/material/Box";
import TextField from "@mui/material/TextField";

import OrganizationTable from "./OrganizationTable";
import OrgDate from "./OrgDate";

function Organization() {
  const [anchorEl, setAnchorEl] = React.useState(null);
  const open = Boolean(anchorEl);
  const handleClick = (event) => {
    setAnchorEl(event.currentTarget);
  };

  const [state, setState] = useState({
    data: ["uvais", "jasmal", "abhi"],
  });
  const handleSelectChange = () => {
    // console.log("select");
  };

  const handleClose = () => {
    setAnchorEl(null);
  };
  const options = [
    "None",
    "Atria",
    "Callisto",
    "Dione",
    "Ganymede",
    "Hangouts Call",
    "Luna",

    "Umbriel",
  ];
  const ITEM_HEIGHT = 48;

  const countries = [
    { code: "ZM", label: "Zambia", phone: "260" },
    { code: "ZW", label: "Zimbabwe", phone: "263" },
  ];

  const [show, setShow] = useState(false);
  // outside click
  function useOutsideAlerter(ref) {
    useEffect(() => {
      /**
       * Alert if clicked on outside of element
       */
      function handleClickOutside(event) {
        if (ref.current && !ref.current.contains(event.target)) {
          setShow(false);
          // setOption(false);
          // alert("You clicked outside of me!");
        }
      }

      // Bind the event listener
      document.addEventListener("mousedown", handleClickOutside);
      return () => {
        // Unbind the event listener on clean up
        document.removeEventListener("mousedown", handleClickOutside);
      };
    }, [ref]);
  }

  const wrapperRef = useRef(null);
  useOutsideAlerter(wrapperRef);

  //check===============
  const [check, setCheck] = useState({
    checkValue: "",
    partnerPopup: false,
    ExpirydatePopup: false,
    productPopup: false,
    countryPopup: false,
  });
  const handleCheck = (e) => {
    setCheck({ ...check, checkValue: e.target.name });

    if (e.target.name === "expiryDate") {
      setCheck({ ...check, ExpirydatePopup: !check.ExpirydatePopup });
    } else if (e.target.name === "product") {
      setCheck({ ...check, productPopup: !check.productPopup });

      console.log(check.productPopup);
    } else if (e.target.name === "partner") {
      setCheck({ ...check, partnerPopup: !check.partnerPopup });
      console.log(check.partnerPopup);
    } else if (e.target.name === "country") {
      setCheck({ ...check, countryPopup: !check.countryPopup });
    } else {
      console.log("==============");
    }
  };
  console.log(check);
  return (
    <Container>
      <Heading>
        <LeftContainer>
          <BlogTxt>Organization</BlogTxt>

          <FilterButton onClick={(e) => setShow(!show)}>
            <ButtonContainer>
              <Filter__Icon />
              <FilterTxt> Filter</FilterTxt>
            </ButtonContainer>
          </FilterButton>

          <SubContainer>
            <Field1>
              <EditContainer>
                <CustomTextField
                  id="outlined-basic"
                  variant="outlined"
                  placeholder="Search..."
                />
              </EditContainer>
            </Field1>
          </SubContainer>
        </LeftContainer>

        <CreateButtonContainer>
          <CreateButton label={"Create New"} />
        </CreateButtonContainer>
      </Heading>

      <PopupContainer show={show} ref={wrapperRef}>
        <Card sx={{ maxWidth: 345 }} hideBackdrop={false}>
          <CardContent>
            <FormCardContainer>
              <FormGroup>
                <FormControlLabel
                  control={
                    <Checkbox
                      // defaultChecked
                      checked={check.ExpirydatePopup ? true : false}
                      name="expiryDate"
                      onChange={handleCheck}
                    />
                  }
                  label="Expiry date"
                />
                {check.ExpirydatePopup ? <OrgDate /> : null}

                <FormControlLabel
                  control={
                    <Checkbox
                      // defaultChecked
                      checked={check.countryPopup ? true : false}
                      name="country"
                      onChange={handleCheck}
                    />
                  }
                  label="Country"
                />
                {check.countryPopup ? (
                  <SearchSelectContainer>
                    <Autocomplete
                      id="country-select-demo"
                      sx={{ width: 300 }}
                      options={countries}
                      autoHighlight
                      // getOptionLabel={(option) => option.label}
                      renderOption={(props, option) => (
                        <Box
                          component="li"
                          sx={{ "& > img": { mr: 2, flexShrink: 0 } }}
                          {...props}
                          style={{ fontSize: "12px" }}
                          menuIsOpen={true}
                          // onClick={() => setShow(true)}
                        >
                          <img
                            loading="lazy"
                            width="20"
                            src={`https://flagcdn.com/w20/${option.code.toLowerCase()}.png`}
                            srcSet={`https://flagcdn.com/w40/${option.code.toLowerCase()}.png 2x`}
                            alt=""
                          />
                          {option.label} ({option.code}) +{option.phone}
                        </Box>
                      )}
                      renderInput={(params) => (
                        <TextField
                          {...params}
                          inputProps={{
                            ...params.inputProps,
                            autoComplete: "new-password",
                            placeholder: "Select Country",
                          }}
                        />
                      )}
                    />
                  </SearchSelectContainer>
                ) : null}
                <FormControlLabel
                  control={
                    <Checkbox
                      // defaultChecked
                      checked={check.productPopup ? true : false}
                      name="product"
                      onChange={handleCheck}
                    />
                  }
                  label="Product"
                />
                {check.productPopup ? (
                  <CustomeAutocomplete
                    size="small"
                    id="combo-box-demo"
                    options={state.data}
                    // getOptionLabel={(option) => option.username || ""}
                    onInputChange={(event, value, reason) => {}}
                    onChange={(e, v) => handleSelectChange("ReportUserID", v)}
                    renderInput={(params) => (
                      <TextField
                        size="small"
                        {...params}
                        placeholder="Select product"
                      />
                    )}
                  />
                ) : null}

                <FormControlLabel
                  control={
                    <Checkbox
                      // defaultChecked
                      name="partner"
                      checked={check.partnerPopup ? true : false}
                      onChange={handleCheck}
                    />
                  }
                  label="Partner"
                />

                {check.partnerPopup ? (
                  <CustomeAutocomplete
                    size="small"
                    id="combo-box-demo"
                    options={state.data}
                    // getOptionLabel={(option) => option.username || ""}
                    onInputChange={(event, value, reason) => {}}
                    onChange={(e, v) => handleSelectChange("ReportUserID", v)}
                    renderInput={(params) => (
                      <TextField
                        size="small"
                        {...params}
                        style={{ fontSize: "12px" }}
                        placeholder="Select partner"
                      />
                    )}
                  />
                ) : null}
              </FormGroup>
            </FormCardContainer>
          </CardContent>
        </Card>
      </PopupContainer>

      <div>
        <OrganizationTable />
      </div>
    </Container>
  );
}

export default Organization;

const EditContainer = styled.div`
  display: flex;

  align-items: center;
`;
const Field1 = styled.div``;

const CustomTextField = styled(TextField)`
  && {
    /* min-width: 150px; */
  }
  border: unset !important;
  outline: unset !important;
  &.css-1u3bzj6-MuiFormControl-root-MuiTextField-root {
    border-radius: 2px;
  }
  .css-1t8l2tu-MuiInputBase-input-MuiOutlinedInput-input {
    padding: 6.5px 30px 6.5px 14px !important;
    font-size: 13px !important;
  }
  .css-1d3z3hw-MuiOutlinedInput-notchedOutline {
    border-color: #d4d4d4 !important;
    border-width: 1px !important;
  }
`;
const SubContainer = styled.div``;
const FormCardContainer = styled.div`
  .css-j204z7-MuiFormControlLabel-root .MuiFormControlLabel-label {
    font-size: 13px;
  }
  .css-j204z7-MuiFormControlLabel-root {
    width: 100%;
  }
  .css-i4bv87-MuiSvgIcon-root {
    /* color: white !important; */
    fill: unset !important ;
    font-size: 1.3rem !important;
  }
`;
const SearchSelectContainer = styled.div`
  && {
    border: unset !important ;
    width: 100%;
    margin-top: 5px;
    .css-viou3o-MuiAutocomplete-root
      .MuiOutlinedInput-root
      .MuiAutocomplete-input {
      padding: 5.5px 9px 5.5px 8px;
    }

    .css-wb57ya-MuiFormControl-root-MuiTextField-root {
      width: 69%;
    }
  }
  .css-1d3z3hw-MuiOutlinedInput-notchedOutline {
    border: none !important;
  }
  input::placeholder {
    font-size: 12px !important;
  }
  .css-viou3o-MuiAutocomplete-root
    .MuiAutocomplete-inputRoot
    .MuiAutocomplete-input {
    font-size: 13px;
  }
  & {
    background-color: #f0f0f0;
  }
  .css-1sumxir-MuiFormLabel-root-MuiInputLabel-root.Mui-focused {
    color: black !important;
  }
  .css-1d3z3hw-MuiOutlinedInput-notchedOutline {
    outline: unset !important ;
    border-color: #d4d4d4 !important;
    border-width: 1px !important;
  }

  .css-14s5rfu-MuiFormLabel-root-MuiInputLabel-root {
    top: -5px !important;
    font-size: 13px;
    line-height: unset !important ;
  }
  /* .css-viou3o-MuiAutocomplete-root {
    width: 100%;
  } */
  .css-viou3o-MuiAutocomplete-root .MuiOutlinedInput-root {
    padding: unset !important;
  }
  .css-154xyx0-MuiInputBase-root-MuiOutlinedInput-root:hover
    .MuiOutlinedInput-notchedOutline {
    border: unset !important;
    border-width: 1px !important;
    outline: unset !important;
  }
  .css-wb57ya-MuiFormControl-root-MuiTextField-root {
    border: unset !important ;
  }
  .css-viou3o-MuiAutocomplete-root {
    width: 300px;
  }
`;
const CustomeAutocomplete = styled(Autocomplete)`
  && {
    border: unset !important ;
  }
  .css-1d3z3hw-MuiOutlinedInput-notchedOutline {
    border: none !important;
  }
  input::placeholder {
    font-size: 12px !important;
  }
  .css-viou3o-MuiAutocomplete-root
    .MuiAutocomplete-inputRoot
    .MuiAutocomplete-input {
    font-size: 13px;
  }
  &.css-1auycx3-MuiAutocomplete-root
    .MuiOutlinedInput-root.MuiInputBase-sizeSmall {
    padding: 3px;
  }
  & {
    background-color: #f0f0f0;
  }
  .css-1sumxir-MuiFormLabel-root-MuiInputLabel-root.Mui-focused {
    color: black !important;
  }
  .css-1d3z3hw-MuiOutlinedInput-notchedOutline {
    outline: unset !important ;
    border-color: #d4d4d4 !important;
    border-width: 1px !important;
  }

  .css-14s5rfu-MuiFormLabel-root-MuiInputLabel-root {
    top: -5px !important;
    font-size: 13px;
    line-height: unset !important ;
  }
  .css-viou3o-MuiAutocomplete-root {
    width: 100%;
  }
  .css-viou3o-MuiAutocomplete-root .MuiOutlinedInput-root {
    padding: unset !important;
  }
  .css-154xyx0-MuiInputBase-root-MuiOutlinedInput-root:hover
    .MuiOutlinedInput-notchedOutline {
    border: unset !important;
    border-width: 1px !important;
    outline: unset !important;
  }
  .css-wb57ya-MuiFormControl-root-MuiTextField-root {
    border: unset !important ;
  }
  &.css-1auycx3-MuiAutocomplete-root
    .MuiOutlinedInput-root.MuiInputBase-sizeSmall
    .MuiAutocomplete-input {
    padding: 0px 4px 0px 6px !important;
  }
`;
const PopupContainer = styled.div`
  transform: ${({ show }) => (show ? "translateY(0)" : "translateY(-200%)")};
  /* height: ${({ show }) => (show ? "auto" : "0px")}; */
  transition: all 500ms cubic-bezier(0.25, 0.25, 0, 1.2);
  && {
    max-width: 240px;
  }
  .css-46bh2p-MuiCardContent-root:last-child {
    padding-bottom: 16px;
  }
  position: absolute;
  min-width: 240px;
  top: 126px;
  left: 416px;
`;
const FilterTxt = styled.span`
  font-size: 13px;
`;
const ButtonContainer = styled.div`
  display: flex;
  align-items: center;

  gap: 20px;
`;
const Filter__Icon = styled(FilterListIcon)``;
const FilterButton = styled(Button)`
  && {
    color: #000000 !important;
    border: 1px solid #d4d4d4 !important;
    text-transform: unset !important ;
    font-size: 13px !important;
    height: 32px;
    padding: 5px 18px 5px 10px;
  }
`;

const CreateButtonContainer = styled.div`
  position: relative;
`;
const Container = styled.div``;
const LeftContainer = styled.div`
  display: flex;
  gap: 18px;
  align-items: center;
`;

const Heading = styled.div`
  width: 100%;
  display: flex;
  justify-content: space-between;
`;
const BlogTxt = styled.h2`
  font-size: 27px;
  letter-spacing: 1px; ;
`;
