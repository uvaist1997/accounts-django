import React, { useState } from "react";
import styled from "styled-components/macro";

import { IconButton, Menu, MenuItem } from "@mui/material";

import MoreVertIcon from "@mui/icons-material/MoreVert";
import Pagination from "@mui/material/Pagination";

function UsersList() {
  const options = ["Edit", "Delete", "Block"];
  const [anchorEl, setAnchorEl] = useState(null);
  const open = Boolean(anchorEl);
  const [currentIndex, setCurrentIndex] = useState();
  const handleClick = (index) => (event) => {
    setAnchorEl(event.currentTarget);
    setCurrentIndex(index);

    console.log("index", index);
  };
  const handleClose = () => {
    setAnchorEl(null);
  };
  const ITEM_HEIGHT = 48;
  const [countryList, setCountryList] = useState({
    data: [
      {
        slno: "1",
        username: "uvai",
        name: "uvais T",
        email: "uvais@mail.com",
        phone: "987654431",
        country: "10001",
        state: "Kerala",
        expiryDate: "12-12-2021",
        status: "Active",
      },
      {
        slno: "2",
        username: "uvai",
        name: "uvais T",
        email: "uvais@mail.com",
        phone: "987654431",
        country: "10001",
        state: "Kerala",
        expiryDate: "12-12-2021",
        status: "Active",
      },
      {
        slno: "3",
        username: "uvai",
        name: "uvais T",
        email: "uvais@mail.com",
        phone: "987654431",
        country: "10001",
        state: "Kerala",
        expiryDate: "12-12-2021",
        status: "Active",
      },
      {
        slno: "4",
        username: "uvai",
        name: "uvais T",
        email: "uvais@mail.com",
        phone: "987654431",
        country: "10001",
        state: "Kerala",
        expiryDate: "12-12-2021",
        status: "Active",
      },
      {
        slno: "5",
        username: "uvai",
        name: "uvais T",
        email: "uvais@mail.com",
        phone: "987654431",
        country: "10001",
        state: "Kerala",
        expiryDate: "12-12-2021",
        status: "Active",
      },
      {
        slno: "6",
        username: "uvai",
        name: "uvais T",
        email: "uvais@mail.com",
        phone: "987654431",
        country: "10001",
        state: "Kerala",
        expiryDate: "12-12-2021",
        status: "Active",
      },
      {
        slno: "7",
        username: "uvai",
        name: "uvais T",
        email: "uvais@mail.com",
        phone: "987654431",
        country: "10001",
        state: "Kerala",
        expiryDate: "12-12-2021",
        status: "Active",
      },
      {
        slno: "8",
        username: "uvai",
        name: "uvais T",
        email: "uvais@mail.com",
        phone: "987654431",
        country: "10001",
        state: "Kerala",
        expiryDate: "12-12-2021",
        status: "Active",
      },
      {
        slno: "9",
        username: "uvai",
        name: "uvais T",
        email: "uvais@mail.com",
        phone: "987654431",
        country: "10001",
        state: "Kerala",
        expiryDate: "12-12-2021",
        status: "Active",
      },
      {
        slno: "10",
        username: "uvai",
        name: "uvais T",
        email: "uvais@mail.com",
        phone: "987654431",
        country: "10001",
        state: "Kerala",
        expiryDate: "12-12-2021",
        status: "Active",
      },
      {
        slno: "11",
        username: "uvai",
        name: "uvais T",
        email: "uvais@mail.com",
        phone: "987654431",
        country: "10001",
        state: "Kerala",
        expiryDate: "12-12-2021",
        status: "Active",
      },
      {
        slno: "12",
        username: "uvai",
        name: "uvais T",
        email: "uvais@mail.com",
        phone: "987654431",
        country: "10001",
        state: "Kerala",
        expiryDate: "12-12-2021",
        status: "Active",
      },
      {
        slno: "13",
        username: "uvai",
        name: "uvais T",
        email: "uvais@mail.com",
        phone: "987654431",
        country: "10001",
        state: "Kerala",
        expiryDate: "12-12-2021",
        status: "Active",
      },
      {
        slno: "14",
        username: "uvai",
        name: "uvais T",
        email: "uvais@mail.com",
        phone: "987654431",
        country: "10001",
        state: "Kerala",
        expiryDate: "12-12-2021",
        status: "Active",
      },
      {
        slno: "15",
        username: "uvai",
        name: "uvais T",
        email: "uvais@mail.com",
        phone: "987654431",
        country: "10001",
        state: "Kerala",
        expiryDate: "12-12-2021",
        status: "Active",
      },
      {
        slno: "16",
        username: "uvai",
        name: "uvais T",
        email: "uvais@mail.com",
        phone: "987654431",
        country: "10001",
        state: "Kerala",
        expiryDate: "12-12-2021",
        status: "Active",
      },
      {
        slno: "17",
        username: "uvai",
        name: "uvais T",
        email: "uvais@mail.com",
        phone: "987654431",
        country: "10001",
        state: "Kerala",
        expiryDate: "12-12-2021",
        status: "Active",
      },
      {
        slno: "18",
        username: "uvai",
        name: "uvais T",
        email: "uvais@mail.com",
        phone: "987654431",
        country: "10001",
        state: "Kerala",
        expiryDate: "12-12-2021",
        status: "Active",
      },
      {
        slno: "19",
        username: "uvai",
        name: "uvais T",
        email: "uvais@mail.com",
        phone: "987654431",
        country: "10001",
        state: "Kerala",
        expiryDate: "12-12-2021",
        status: "Active",
      },
      {
        slno: "20",
        username: "uvai",
        name: "uvais T",
        email: "uvais@mail.com",
        phone: "987654431",
        country: "10001",
        state: "Kerala",
        expiryDate: "12-12-2021",
        status: "Active",
      },
      {
        slno: "21",
        username: "uvai",
        name: "uvais T",
        email: "uvais@mail.com",
        phone: "987654431",
        country: "10001",
        state: "Kerala",
        expiryDate: "12-12-2021",
        status: "Active",
      },
      {
        slno: "22",
        username: "uvai",
        name: "uvais T",
        email: "uvais@mail.com",
        phone: "987654431",
        country: "10001",
        state: "Kerala",
        expiryDate: "12-12-2021",
        status: "Active",
      },
      {
        slno: "23",
        username: "uvai",
        name: "uvais T",
        email: "uvais@mail.com",
        phone: "987654431",
        country: "10001",
        state: "Kerala",
        expiryDate: "12-12-2021",
        status: "Active",
      },
      {
        slno: "24",
        username: "uvai",
        name: "uvais T",
        email: "uvais@mail.com",
        phone: "987654431",
        country: "10001",
        state: "Kerala",
        expiryDate: "12-12-2021",
        status: "Active",
      },
      {
        slno: "25",
        username: "uvai",
        name: "uvais T",
        email: "uvais@mail.com",
        phone: "987654431",
        country: "10001",
        state: "Kerala",
        expiryDate: "12-12-2021",
        status: "Active",
      },
      {
        slno: "26",
        username: "uvai",
        name: "uvais T",
        email: "uvais@mail.com",
        phone: "987654431",
        country: "10001",
        state: "Kerala",
        expiryDate: "12-12-2021",
        status: "Active",
      },
      {
        slno: "27",
        username: "uvai",
        name: "uvais T",
        email: "uvais@mail.com",
        phone: "987654431",
        country: "10001",
        state: "Kerala",
        expiryDate: "12-12-2021",
        status: "Active",
      },
      {
        slno: "28",
        username: "uvai",
        name: "uvais T",
        email: "uvais@mail.com",
        phone: "987654431",
        country: "10001",
        state: "Kerala",
        expiryDate: "12-12-2021",
        status: "Active",
      },
      {
        slno: "29",
        username: "uvai",
        name: "uvais T",
        email: "uvais@mail.com",
        phone: "987654431",
        country: "10001",
        state: "Kerala",
        expiryDate: "12-12-2021",
        status: "Active",
      },
      {
        slno: "30",
        username: "uvai",
        name: "uvais T",
        email: "uvais@mail.com",
        phone: "987654431",
        country: "10001",
        state: "Kerala",
        expiryDate: "12-12-2021",
        status: "Active",
      },
      {
        slno: "31",
        username: "uvai",
        name: "uvais T",
        email: "uvais@mail.com",
        phone: "987654431",
        country: "10001",
        state: "Kerala",
        expiryDate: "12-12-2021",
        status: "Active",
      },
    ],
  });
  //pagination=======================================

  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage, setItemsPerPage] = useState(18);

  const IndexofLastItem = currentPage * itemsPerPage;
  const indexOfFirstDish = IndexofLastItem - itemsPerPage;
  let PaginatedData = countryList.data.slice(indexOfFirstDish, IndexofLastItem);
  console.log("page", PaginatedData);

  const ChangePage = (event, value) => {
    setCurrentPage(value);
  };

  const NumOfpages = Math.ceil(countryList.data.length / itemsPerPage);

  return (
    <TableContainer>
      <Table>
        <THead>
          <TableHeadRow>
            <TH> SI No </TH>
            <TH> Username </TH>
            <TH> Name </TH>
            <TH> E-mail </TH>
            <TH>Phone </TH>
            <TH> Country </TH>
            <TH> State</TH>

            <TH>Expiry Date</TH>
            <TH>Status</TH>
            <TH></TH>
          </TableHeadRow>
        </THead>
        <TBody>
          {PaginatedData.map((i, index) => (
            <TableBodyRow>
              <TD>{i.slno}</TD>

              <TD>{i.username}</TD>
              <TD>{i.name}</TD>
              <TD>{i.email}</TD>
              <TD>{i.phone}</TD>
              <TD>{i.country}</TD>
              <TD>{i.state}</TD>
              <TD>{i.expiryDate}</TD>
              <TD>
                <Indicator>
                  <LoginSpan></LoginSpan>
                  <span> {i.status}</span>
                </Indicator>
              </TD>

              <TD style={{ textAlign: "right" }}>
                <RightSide>
                  <IconButton
                    id={index}
                    aria-label="more"
                    aria-controls={open ? "long-menu" : undefined}
                    aria-expanded={open ? "true" : undefined}
                    aria-haspopup="true"
                    onClick={handleClick(index)}
                  >
                    <MoreVertIcon />
                  </IconButton>
                  {currentIndex === index ? (
                    <Menus
                      onOpen={Boolean(anchorEl)}
                      // id="long-menu"
                      MenuListProps={
                        {
                          // "aria-labelledby": ` ${index}`,
                        }
                      }
                      disableScrollLock={true}
                      anchorEl={anchorEl}
                      open={open}
                      onClose={handleClose}
                      PaperProps={{
                        style: {
                          maxHeight: ITEM_HEIGHT * 4.5,
                          width: "20ch",
                        },
                      }}
                    >
                      {options.map((option) => (
                        <MenuItem
                          key={option}
                          selected={option === "Edit"}
                          onClick={handleClose}
                        >
                          {option}
                        </MenuItem>
                      ))}
                    </Menus>
                  ) : null}
                </RightSide>
              </TD>
            </TableBodyRow>
          ))}
        </TBody>
      </Table>
      <PaginationContainer>
        <Pagination count={NumOfpages} onChange={ChangePage} />
      </PaginationContainer>
    </TableContainer>
  );
}

export default UsersList;

const PaginationContainer = styled.div`
  width: 100%;
  display: flex;
  margin-top: 10px;
  justify-content: center;
`;
const Indicator = styled.div`
  display: flex;
  align-items: center;
  gap: 5px;
`;
const Menus = styled(Menu)`
  .css-1poimk-MuiPaper-root-MuiMenu-paper-MuiPaper-root-MuiPopover-paper {
    ::-webkit-scrollbar {
      display: none !important;
    }
  }
  && {
    .css-1poimk-MuiPaper-root-MuiMenu-paper-MuiPaper-root-MuiPopover-paper {
      width: 17ch !important;
      left: 1212px !important;

      @media (width: 1309.09px) {
        left: 1083px !important;
      }
      @media (width: 1920px) {
        left: 1687px !important;
      }
      @media (width: 1600px) {
        left: 1371px !important;
      }
      @media (width: 1800px) {
        left: 98rem !important;
      }
    }
    .css-kk1bwy-MuiButtonBase-root-MuiMenuItem-root {
      font-size: 12px;
    }
  }
`;
const RightSide = styled.div`
  height: 100%;

  svg {
    font-size: 1.1rem !important ;
    color: black !important;
  }
  .css-78trlr-MuiButtonBase-root-MuiIconButton-root {
    padding: unset !important;
  }
  .MuiPaper-root {
    box-shadow: none !important;
    width: 19ch !important;
  }
`;

const TableContainer = styled.div`
  margin-top: 15px;
`;
const TD = styled.td`
  font-size: 12px;

  text-align: left;

  border-bottom: 1px solid #ababab;
  vertical-align: middle;
  @media (min-width: 1309.09px) {
    padding: 5px 6px;
  }

  &.cursor {
    cursor: pointer;
  }
`;
const TableBodyRow = styled.tr`
  :hover {
    background-color: rgba(0, 0, 0, 0.04);
  }
`;
const Table = styled.table`
  border-radius: 15px;
  width: 100%;
  background: #fff;
  border-spacing: unset;
`;
const LoginSpan = styled.span`
  width: 12px;
  height: 12px;

  border-radius: 50%;
  background-image: linear-gradient(132deg, #059200, #046700);
`;
const THead = styled.thead`
  box-shadow: 0 0 0 1px #c6c6c6;
  border-radius: 3px;
  background-color: black;
  color: white;
`;
const TableHeadRow = styled.tr``;
const TBody = styled.tbody``;
const TH = styled.th`
  padding: 5px 15px;
  font-weight: normal;
  text-align: left;
  font-size: 14px;

  @media (min-width: 1309.09px) {
    padding: 6px 4px;
    font-size: 13px;
  }
`;
