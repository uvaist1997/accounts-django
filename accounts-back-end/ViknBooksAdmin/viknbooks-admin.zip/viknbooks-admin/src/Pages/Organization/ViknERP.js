import React, { useState } from "react";
import styled from "styled-components/macro";
import Avatar from "@mui/material/Avatar";
import ExpandMoreIcon from "@mui/icons-material/ExpandMore";
import Stack from "@mui/material/Stack";
import Box from "@mui/material/Box";
import { Button, IconButton, Tab, Tabs, Typography } from "@mui/material";
import CreateButton from "../../Components/CreateButton";
import UsersList from "./UsersList";
import CompanyInvoice from "./CompanyInvoice";
import { Receipt } from "@mui/icons-material";
import CompanyReceipt from "./CompanyReceipt";
import ViknERPDeviceList from "./ViknERPDeviceList";
function ViknERP() {
  const [showList, setShowList] = useState(false);
  const [list, setList] = useState([
    "uvais",
    "jasmal",
    "savaad farook",
    "savaad farook",
  ]);
  function TabPanel(props) {
    const { children, value, index, ...other } = props;

    return (
      <div
        role="tabpanel"
        hidden={value !== index}
        id={`simple-tabpanel-${index}`}
        aria-labelledby={`simple-tab-${index}`}
        {...other}
      >
        {value === index && (
          <Box sx={{ p: 3 }}>
            <Typography>{children}</Typography>
          </Box>
        )}
      </div>
    );
  }

  // TabPanel.propTypes = {
  //   children: PropTypes.node,
  //   index: PropTypes.number.isRequired,
  //   value: PropTypes.number.isRequired,
  // };

  function a11yProps(index) {
    return {
      id: `simple-tab-${index}`,
      "aria-controls": `simple-tabpanel-${index}`,
    };
  }

  const [value, setValue] = React.useState(0);

  const handleChange = (event, newValue) => {
    setValue(newValue);
  };
  return (
    <Container>
      <Heading>
        <ApplicationTxt>Organization-Vikncodes LLP</ApplicationTxt>

        <CreateButtonContainer onClick={(e) => setShowList(!showList)}>
          <EditContainer>
            <Stack direction="row" spacing={2}>
              <Avatar src="/broken-image.jpg" />

              <NameTxtContainer>
                <PatrnerTxt>Partner</PatrnerTxt>

                <NameTxt>Savaadfarooque</NameTxt>
              </NameTxtContainer>
              <IconContainer>
                <ExpandMoreIcon />
              </IconContainer>
            </Stack>
          </EditContainer>
        </CreateButtonContainer>

        <Popup showList={showList}>
          {list.map((i) => (
            <NamePopup onClick={(e) => setShowList(false)}>{i}</NamePopup>
          ))}
        </Popup>
      </Heading>

      <MainSubContainer>
        <LeftContainer>
          <HeaderContainer>
            <div>
              <ImageContainer>
                <ImgLogo src="../../Images/Icons/viknERP.svg" />
              </ImageContainer>
            </div>

            <HeadingTxtContainer>
              <ProductTxt>Product</ProductTxt>
              <CompanyNameContainer>
                <CompanyTxt>ViknERP</CompanyTxt>

                <LoginSpanContainer>
                  <LoginSpan></LoginSpan>
                  <LoggedInTxt>Logged In</LoggedInTxt>
                </LoginSpanContainer>
              </CompanyNameContainer>
            </HeadingTxtContainer>
          </HeaderContainer>

          <div>
            <LiteEdition variant="outlined">Lite Edition</LiteEdition>
          </div>

          <DetailsContainer>
            <RegisteredUserContainer>
              <PhoneTxt>Email :</PhoneTxt>
              <Emailtext>Email</Emailtext>
            </RegisteredUserContainer>
            <RegisteredUserContainer>
              <PhoneTxt>Phone :</PhoneTxt>
              <Emailtext>phone</Emailtext>
            </RegisteredUserContainer>
          </DetailsContainer>

          <RegisteredUser>
            <RegisteredParts>
              <LeftContainer2>
                <RegisteredUserContainer>
                  <EmailTxt>Registered User :</EmailTxt>
                </RegisteredUserContainer>
                <RegisteredUserContainer>
                  <EmailTxt>Registered Date :</EmailTxt>
                </RegisteredUserContainer>
                <RegisteredUserContainer>
                  <EmailTxt>No of Users :</EmailTxt>
                </RegisteredUserContainer>{" "}
                <RegisteredUserContainer>
                  <EmailTxt>Active Plan :</EmailTxt>
                </RegisteredUserContainer>{" "}
                <RegisteredUserContainer>
                  <EmailTxt>Plan Expire on :</EmailTxt>
                </RegisteredUserContainer>
                <RegisteredUserContainer>
                  <EmailTxt>AMC :</EmailTxt>
                </RegisteredUserContainer>
                <RegisteredUserContainer>
                  <EmailTxt>AMC Expire on :</EmailTxt>
                </RegisteredUserContainer>
              </LeftContainer2>
              <RightContainer2>
                <RegisteredUserContainer>
                  <RegisteredEmailTxt>Savaadfarooque</RegisteredEmailTxt>
                </RegisteredUserContainer>{" "}
                <RegisteredUserContainer>
                  <RegisteredEmailTxt>26/3/2022</RegisteredEmailTxt>
                </RegisteredUserContainer>{" "}
                <RegisteredUserContainer>
                  <RegisteredEmailTxt>5 Users</RegisteredEmailTxt>
                </RegisteredUserContainer>{" "}
                <RegisteredUserContainer>
                  <RegisteredEmailTxt>Lite</RegisteredEmailTxt>
                </RegisteredUserContainer>{" "}
                <RegisteredUserContainer>
                  <RegisteredEmailTxt>26/3/2022</RegisteredEmailTxt>
                </RegisteredUserContainer>{" "}
                <RegisteredUserContainer>
                  <RegisteredEmailTxt>Free</RegisteredEmailTxt>
                </RegisteredUserContainer>{" "}
                <RegisteredUserContainer>
                  <RegisteredEmailTxt>26/3/2022</RegisteredEmailTxt>
                </RegisteredUserContainer>
              </RightContainer2>
            </RegisteredParts>
          </RegisteredUser>

          <RevenueContainer>
            <Emailtext>Total</Emailtext>

            <RevenueTxtContainer>
              <RevenueTxt>Revenue</RevenueTxt>
              <AmountTxt>Rs.24678</AmountTxt>
            </RevenueTxtContainer>
          </RevenueContainer>

          <AddOnsContainer>
            <RevenueTxt>Add ons</RevenueTxt>
            <CardScroll>
              <RassayButton>
                <SmallCard>
                  <Card1>
                    <Rassasy2>
                      <RassasyContainer>
                        <ImgLogo src="../../Images/Icons/Union.svg" />
                      </RassasyContainer>
                      <h4 style={{ fontSize: "15px" }}>Duba Sales</h4>
                    </Rassasy2>
                    <FreeTxt>Free</FreeTxt>
                  </Card1>
                </SmallCard>
              </RassayButton>
              <RassayButton>
                <SmallCard>
                  <Card1>
                    <Rassasy2>
                      <RassasyContainer>
                        <ImgLogo src="../../Images/Icons/Union.svg" />
                      </RassasyContainer>
                      <h4 style={{ fontSize: "15px" }}>Duba Sales</h4>
                    </Rassasy2>
                    <FreeTxt>Free</FreeTxt>
                  </Card1>
                </SmallCard>
              </RassayButton>
              <RassayButton>
                <SmallCard>
                  <Card1>
                    <Rassasy2>
                      <RassasyContainer>
                        <ImgLogo src="../../Images/Icons/Union.svg" />
                      </RassasyContainer>
                      <h4 style={{ fontSize: "15px" }}>Duba Sales</h4>
                    </Rassasy2>
                    <FreeTxt>Free</FreeTxt>
                  </Card1>
                </SmallCard>
              </RassayButton>
              <RassayButton>
                <SmallCard>
                  <Card1>
                    <Rassasy2>
                      <RassasyContainer>
                        <ImgLogo src="../../Images/Icons/Union.svg" />
                      </RassasyContainer>
                      <h4 style={{ fontSize: "15px" }}>Duba Sales</h4>
                    </Rassasy2>
                    <FreeTxt>Free</FreeTxt>
                  </Card1>
                </SmallCard>{" "}
              </RassayButton>
              <RassayButton>
                <SmallCard>
                  <Card1>
                    <Rassasy2>
                      <RassasyContainer>
                        <ImgLogo src="../../Images/Icons/Union.svg" />
                      </RassasyContainer>
                      <h4 style={{ fontSize: "15px" }}>Duba Sales</h4>
                    </Rassasy2>
                    <FreeTxt>Free</FreeTxt>
                  </Card1>
                </SmallCard>{" "}
              </RassayButton>
              <RassayButton>
                <SmallCard>
                  <Card1>
                    <Rassasy2>
                      <RassasyContainer>
                        <ImgLogo src="../../Images/Icons/Union.svg" />
                      </RassasyContainer>
                      <h4 style={{ fontSize: "15px" }}>Duba Sales</h4>
                    </Rassasy2>
                    <FreeTxt>Free</FreeTxt>
                  </Card1>
                </SmallCard>{" "}
              </RassayButton>
              <RassayButton>
                <SmallCard>
                  <Card1>
                    <Rassasy2>
                      <RassasyContainer>
                        <ImgLogo src="../../Images/Icons/Union.svg" />
                      </RassasyContainer>
                      <h4 style={{ fontSize: "15px" }}>Duba Sales</h4>
                    </Rassasy2>
                    <FreeTxt>Free</FreeTxt>
                  </Card1>
                </SmallCard>{" "}
              </RassayButton>
              <RassayButton>
                <SmallCard>
                  <Card1>
                    <Rassasy2>
                      <RassasyContainer>
                        <ImgLogo src="../../Images/Icons/Union.svg" />
                      </RassasyContainer>
                      <h4 style={{ fontSize: "15px" }}>Duba Sales</h4>
                    </Rassasy2>
                    <FreeTxt>Free</FreeTxt>
                  </Card1>
                </SmallCard>{" "}
              </RassayButton>

              <RassayButton>
                <SmallCard>
                  <Card1>
                    <Rassasy2>
                      <RassasyContainer>
                        <ImgLogo src="../../Images/Icons/Union.svg" />
                      </RassasyContainer>
                      <h4 style={{ fontSize: "15px" }}>Duba Sales</h4>
                    </Rassasy2>
                    <FreeTxt>Free</FreeTxt>
                  </Card1>
                </SmallCard>
              </RassayButton>
            </CardScroll>
          </AddOnsContainer>
        </LeftContainer>

        <RightContainer>
          <Box sx={{ borderColor: "divider" }}>
            <Tabs
              value={value}
              onChange={handleChange}
              aria-label="basic tabs example"
            >
              <Tab label="Devices" {...a11yProps(0)} />
              <Tab label="Users" {...a11yProps(1)} />
              <Tab label="Invoices" {...a11yProps(2)} />
              <Tab label="Receipts" {...a11yProps(3)} />
            </Tabs>
          </Box>

          <Device>
            <TabPanel value={value} index={0}>
              <Heading>
                <UsersTxt>Devices</UsersTxt>
                <CreateBTNContainer>
                  <CreateButton label={"Add New"} />
                </CreateBTNContainer>
              </Heading>
              <ViknERPDeviceList />
            </TabPanel>
          </Device>

          <Users>
            <TabPanel value={value} index={1}>
              <Heading>
                <UsersTxt>Users</UsersTxt>
                <CreateBTNContainer>
                  <CreateButton label={"Add New"} />
                </CreateBTNContainer>
              </Heading>

              <div>
                <UsersList />
              </div>
            </TabPanel>
          </Users>

          {/* Invoice section========================== */}

          <Invoice>
            <TabPanel value={value} index={2}>
              <CompanyInvoice />
            </TabPanel>
          </Invoice>

          {/* Recipt Section======================= */}
          <ReceiptsContainer>
            <TabPanel value={value} index={3}>
              <CompanyReceipt />
            </TabPanel>
          </ReceiptsContainer>
        </RightContainer>
      </MainSubContainer>
    </Container>
  );
}

export default ViknERP;

const Popup = styled.div`
  position: absolute;
  overflow-y: scroll;
  ::-webkit-scrollbar {
    display: none;
  }
  right: 24px;
  border-radius: 4px;
  background-color: white;
  z-index: 3;
  top: 131px;
  min-width: 191px;
  display: ${({ showList }) => (!showList ? "none" : "")};

  box-shadow: rgba(0, 0, 0, 0.05) 0px 6px 24px 0px,
    rgba(0, 0, 0, 0.08) 0px 0px 0px 1px;
  max-height: 150px;
`;
const NamePopup = styled.li`
  font-size: 12px;
  list-style: none;
  margin: 5px;
  padding: 5px 5px;

  cursor: pointer;
  :hover {
    background-color: rgba(0, 0, 0, 0.04);
  }
`;
const Users = styled.div`
  margin-top: 10px;
  .css-19kzrtu {
    padding: unset !important ;
  }
`;

const Invoice = styled(Users)``;
const CreateBTNContainer = styled.div`
  position: relative;
`;

const Device = styled(Users)`
  margin-top: 10px;
  .css-19kzrtu {
    padding: unset !important ;
  }
`;
const UsersTxt = styled.h2`
  font-size: 19px;
  letter-spacing: 1px; ;
`;

const ReceiptsContainer = styled(Users)``;
const CardScroll = styled.div`
  overflow-x: scroll;

  ::-webkit-scrollbar {
    display: none;
  }
  height: 250px;
  margin-top: 20px;
  @media (min-width: 1920px) {
    height: 535px;
  }
`;
const Rassasy2 = styled.div`
  display: flex;
  align-items: center;
  gap: 10px;
`;
const Card1 = styled.div`
  display: flex;
  align-items: center;
  justify-content: space-between;
`;

const RassasyContainer = styled.div`
  width: 35px;
  height: 35px;
`;
const SmallCard = styled.div`
  width: 100%;
  margin-top: 10px;
  :nth-child(1) {
    margin-top: unset;
  }
`;

const RevenueTxtContainer = styled.div`
  display: flex;
  justify-content: space-between;
`;
const RevenueTxt = styled.h4`
  font-size: 15px;
  font-weight: bold;
`;

const AmountTxt = styled(RevenueTxt)`
  color: #175800;
  font-weight: normal;
`;
const LeftContainer2 = styled.div`
  width: 50%;
`;
const RightContainer2 = styled(LeftContainer2)``;
const RegisteredParts = styled.div`
  display: flex;
  /* gap: px; */
`;

const RegisteredUserContainer = styled.div`
  margin-top: 10px;
  display: flex;
  gap: 10px;

  :nth-child(1) {
    margin-top: unset;
  }
`;

const RegisteredUser = styled.div`
  padding: 10px 15px;
  background-color: #fbfbfb;
  border-radius: 2px;
`;

const AddOnsContainer = styled(RegisteredUser)`
  height: 300px;
  margin-top: 10px;
  @media (min-width: 1920px) {
    height: 600px;
  }
`;

const RevenueContainer = styled(RegisteredUser)`
  margin-top: 10px;
`;
const DetailsContainer = styled.div`
  padding: 10px 15px;
`;

const Emailtext = styled.span`
  color: #b2b2b2;
  font-size: 13px;
`;

const RegisteredEmailTxt = styled(Emailtext)`
  color: black;
`;
const FreeTxt = styled(RegisteredEmailTxt)`
  color: #175800;
`;

const PhoneTxt = styled.span`
  font-size: 13px;
  font-weight: bold;
`;

const EmailTxt = styled(PhoneTxt)`
  color: #a83900;
`;
const LiteEdition = styled(Button)`
  && {
    margin-top: 15px;
    width: 100%;
    border-radius: 27px !important;
    border-color: #ffc400 !important;
    color: black !important;
    text-transform: capitalize;
    font-family: "Poppins", sans-serif !important;
    padding: 3px 15px !important;
  }
`;
const LoginSpanContainer = styled.div`
  display: flex;
  gap: 10px;
  align-items: center;
`;
const LoginSpan = styled.span`
  width: 14px;
  height: 14px;
  border-radius: 50%;
  background-image: linear-gradient(132deg, #059200, #046700);
`;
const CompanyTxt = styled.h4`
  /* font-weight: normal; */
  font-size: 15px; ;
`;
const ImgLogo = styled.img`
  width: 100%;
  height: 100%;
  object-fit: contain;
`;

const ImageContainer = styled.div`
  width: 45px;
  height: 45px;
`;

const ProductTxt = styled.span`
  color: #6b6b6b;
  font-size: 12px;
`;

const LoggedInTxt = styled.span`
  font-size: 12px;
`;

const CompanyNameContainer = styled.div`
  display: flex;
  justify-content: space-between;
`;
const HeadingTxtContainer = styled.div`
  display: flex;
  width: 100%;
  flex-direction: column;
`;
const HeaderContainer = styled.div`
  display: flex;
  gap: 5px;
  align-items: center;
`;
const MainSubContainer = styled.div`
  margin-top: 20px;
  display: flex; ;
`;
const LeftContainer = styled.div`
  width: 25%;
`;

const RightContainer = styled.div`
  margin-left: 15px;
  width: 75%;
  .css-1aquho2-MuiTabs-indicator {
    display: none;
  }

  .css-1h9z7r5-MuiButtonBase-root-MuiTab-root.Mui-selected {
    color: white !important;

    text-transform: capitalize !important ;
    font-family: "Poppins", sans-serif;
    background-color: black;
  }

  .css-1h9z7r5-MuiButtonBase-root-MuiTab-root {
    text-transform: capitalize !important ;
    font-family: "Poppins", sans-serif;
    min-height: 34px !important;
    min-width: 134px;
    border-radius: 4px;

    color: black;
    padding: unset !important;
    background-color: #e5e5e5;
  }
  .css-heg063-MuiTabs-flexContainer {
    gap: 10px;
  }
`;
const EditContainer = styled(Button)`
  &.css-1e6y48t-MuiButtonBase-root-MuiButton-root:hover {
    background-color: #d4d4d4 !important;
  }
  .css-1e6y48t-MuiButtonBase-root-MuiButton-root {
    padding: 1px 8px !important;
  }
  && {
    /* background: rgba(0, 0, 0, 0.04) !important; */

    color: black !important;
    text-transform: unset !important;
    width: 100%;
    /* justify-content: left; */
    border-radius: 2px;

    /* display: flex;
    justify-content: space-between; */

    align-items: center;
    border-radius: 4px;
    height: 41px;

    /* border: 1px solid #d4d4d4; */
    svg {
    }
  }
`;

const RassayButton = styled(EditContainer)``;

const PatrnerTxt = styled.span`
  font-size: 9px;
  color: #828282;
  margin-left: 1px;
  text-align: left;
`;
const IconContainer = styled.div`
  display: flex;
  align-self: flex-end;
  margin-bottom: 3px;
  color: black;
`;
const NameTxt = styled.h4`
  font-size: 13px;
  margin-top: -5px;
  font-weight: normal;
`;
const Container = styled.div``;
const Heading = styled.div`
  width: 100%;
  display: flex;
  justify-content: space-between;
  align-items: center;
`;
const ApplicationTxt = styled.h2`
  font-size: 25px;
  letter-spacing: 1px; ;
`;
const CreateButtonContainer = styled.div`
  .css-2s90m6-MuiAvatar-root {
    align-self: flex-end;
  }
  .css-2s90m6-MuiAvatar-root {
    align-items: center;
    width: 32px !important;
    height: 32px !important;
  }
  .css-10mi8st-MuiSvgIcon-root-MuiAvatar-fallback {
    width: 75% !important;
    height: 75% !important;
  }
  cursor: pointer;
  display: flex;
  /* gap: 5px; */
  .css-e53awj-MuiStack-root > :not(style) + :not(style) {
    margin-left: 3px !important;
  }
`;

const NameTxtContainer = styled.div`
  display: flex;
  flex-direction: column;
`;
