import {
  Autocomplete,
  FormControl,
  MenuItem,
  Select,
  TextareaAutosize,
  TextField,
} from "@mui/material";
import { DesktopDatePicker, LocalizationProvider } from "@mui/x-date-pickers";
import React, { useState } from "react";
import styled from "styled-components/macro";
import SaveButton from "../../Components/SaveButton";
import { AdapterDateFns } from "@mui/x-date-pickers/AdapterDateFns";
import PercentIcon from "@mui/icons-material/Percent";

import { SnackbarProvider, useSnackbar } from "notistack";

function CreateReceipt() {
  const { enqueueSnackbar } = useSnackbar();
  const [anchorEl, setAnchorEl] = useState(null);

  const [age, setAge] = useState("");
  const open = Boolean(anchorEl);
  const [values, setValue] = useState(new Date("2014-08-18T21:11:54"));

  const handleChange = (event) => {
    setAge(event.target.value);
  };

  const DateChange = (newValue) => {
    setValue(newValue);
  };
  const [state, setState] = useState({
    data: ["uvais", "jasmal", "abhi"],
  });
  const handleSelectChange = () => {
    console.log("select");
  };

  const handleClickVariant = (variant) => () => {
    // variant could be success, error, warning, info, or default
    enqueueSnackbar(" Saved Successfully !", { variant });
  };

  return (
    <>
      <Heading>
        <LeftContainer>
          <CreateReceiptTxt>Create Receipts</CreateReceiptTxt>
        </LeftContainer>
        <SnackbarProvider maxSnack={3}>
          <SaveButtonContainer onClick={handleClickVariant("success")}>
            <SaveButton label={"Save"} />
          </SaveButtonContainer>
        </SnackbarProvider>
      </Heading>

      <Payment>
        <PaymentContainer>
          <Label>Payment Mode :</Label>
          <SelectBox1>
            <FormControl sx={{ m: 1, minWidth: 120 }}>
              <Select
                MenuProps={{ disableScrollLock: true }}
                value={age}
                onChange={handleChange}
                displayEmpty
                defaultValue="Status"
              >
                <MenuItem value=""></MenuItem>
                <MenuItem value={10}>Ten</MenuItem>
                <MenuItem value={20}>Twenty</MenuItem>
                <MenuItem value={30}>Thirty</MenuItem>
              </Select>
            </FormControl>
          </SelectBox1>
        </PaymentContainer>
        <PaymentContainer>
          <Label>Payment Mode :</Label>

          <VoucherTxt>VIKN-00023-UI</VoucherTxt>
        </PaymentContainer>

        <VoucherDateContainer>
          <Label>Voucher Date :</Label>

          <DateBox>
            <LocalizationProvider dateAdapter={AdapterDateFns}>
              <DesktopDatePicker
                inputFormat="MM/dd/yyyy"
                value={values}
                onChange={DateChange}
                renderInput={(params) => <TextField {...params} />}
              />
            </LocalizationProvider>
          </DateBox>
        </VoucherDateContainer>
        <SearchSelectContainer>
          <CustomeAutocomplete
            size="small"
            id="combo-box-demo"
            options={state.data}
            // getOptionLabel={(option) => option.username || ""}
            onInputChange={(event, value, reason) => {}}
            onChange={(e, v) => handleSelectChange("ReportUserID", v)}
            renderInput={(params) => <TextField size="small" {...params} />}
          />
          <Balance>
            <PaymentContainer>
              <BalanceTxt>Balance :</BalanceTxt>
              <BalanceTxt>$ 2344566</BalanceTxt>
            </PaymentContainer>
            <PaymentContainer>
              <BalanceTxt>As of on:</BalanceTxt>
              <BalanceTxt>abcd</BalanceTxt>
            </PaymentContainer>
          </Balance>
        </SearchSelectContainer>

        <PaymentContainer>
          <Label for="amount">Amount :</Label>
          <CustomTextField id="outlined-basic" variant="outlined" />
        </PaymentContainer>
        <PaymentContainer>
          <Label for="reference">Reference No :</Label>
          <CustomTextField id="outlined-basic" variant="outlined" />
        </PaymentContainer>

        <PaymentContainer>
          <Label for="discount">Discount :</Label>

          <TextFieldContainer>
            <CustomTextField2 id="outlined-basic" variant="outlined" />

            <CustomTextField3 id="outlined-basic" variant="outlined" />
            <PercentageIcon />
          </TextFieldContainer>
        </PaymentContainer>
        <PaymentContainer>
          <CustomTextArea
            defaultValue="Notes(Optional)"
            maxRows={4}
            aria-label="maximum height"
            style={{ width: "100%" }}
          />
        </PaymentContainer>
        <TotalAmount>
          <Total>
            <Label>Total Amount</Label>
            <Label>-</Label>
            <Label>0.00</Label>
          </Total>
        </TotalAmount>
      </Payment>
    </>
  );
}

export default function IntegrationNotistack() {
  return (
    <SnackbarProvider maxSnack={3}>
      <CreateReceipt />
    </SnackbarProvider>
  );
}

const Total = styled.div`
  display: flex;
  align-items: center;
  justify-content: space-between;
  width: 63%;
  padding: 0px 10px;
`;

const CustomTextArea = styled(TextareaAutosize)`
  height: 88px !important;
  overflow: unset !important ;
  padding: 10px 10px;
  outline: unset !important ;
  border: unset !important;
  background-color: #efefef !important ;
  ::-webkit-scrollbar {
    display: none;
  }
`;
const TextFieldContainer = styled.div`
  display: flex;
  gap: 5px;
  position: relative;
`;

const PercentageIcon = styled(PercentIcon)`
  && {
    font-size: 1rem !important;
  }
  position: absolute;
  top: 8px;
  right: 235px;
`;

const CustomTextField = styled(TextField)`
  background-color: #efefef !important ;
  border: unset !important;
  outline: unset !important;
  &.css-1u3bzj6-MuiFormControl-root-MuiTextField-root {
    width: 335px !important;
  }
  .css-1t8l2tu-MuiInputBase-input-MuiOutlinedInput-input {
    padding: 3.5px 30px 3.5px 14px !important;
  }
  .css-1d3z3hw-MuiOutlinedInput-notchedOutline {
    border: none !important;
  }
`;
const CustomTextField2 = styled(CustomTextField)`
  &.css-1u3bzj6-MuiFormControl-root-MuiTextField-root {
    width: 105px !important;
  }
`;

const CustomTextField3 = styled(CustomTextField2)`
  &.css-1u3bzj6-MuiFormControl-root-MuiTextField-root {
    width: 225px !important;
  }
`;
const Balance = styled.div`
  padding: 2px;
`;

const SearchSelectContainer = styled.div`
  background-color: #efefef;
  padding: 10px;
  display: flex;
  flex-direction: column;
  gap: 8px;
  border-radius: 2px;
`;

const CustomeAutocomplete = styled(Autocomplete)`
  && {
    /* width: 150px; */
    margin-top: unset !important;
    background-color: white !important;
  }
  .css-1d3z3hw-MuiOutlinedInput-notchedOutline {
    outline: unset !important ;
    border-color: #d4d4d4 !important;
    border: none !important;
    margin-top: 3px;
  }
  button {
    padding: 0;
  }
  .css-19qh8xo-MuiInputBase-input-MuiOutlinedInput-input {
    height: 1rem !important;
  }
  .css-154xyx0-MuiInputBase-root-MuiOutlinedInput-root {
    border-radius: 2px !important ;
  }
`;
const DateBox = styled.div`
  && {
    background-color: #efefef;
    width: 163px;

    border-radius: 2px;
  }
  .css-nxo287-MuiInputBase-input-MuiOutlinedInput-input {
    padding: 5.5px 13px !important;
  }
  .css-1d3z3hw-MuiOutlinedInput-notchedOutline {
    border: unset !important;
  }
  svg {
    fill: unset !important;
  }
`;
const VoucherTxt = styled.span`
  width: 335px;
  padding: 3px 10px;
  font-size: 15px;
  border-radius: 2px;
  background: #efefef;
`;
const Payment = styled.div`
  display: flex;
  flex-direction: column;
  margin-top: 15px;
  width: 56%;
  gap: 10px;
`;
const PaymentContainer = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
`;

const TotalAmount = styled(PaymentContainer)`
  display: flex;
  justify-content: flex-end;
  width: 100%;
`;

const Label = styled.label`
  font-size: 13px;
`;

const BalanceTxt = styled.span`
  font-size: 13px;
`;

const VoucherDateContainer = styled.div`
  display: flex;
  gap: 61px;
  @media (min-width: 1920px) {
    gap: 261px;
  }
`;
const SaveButtonContainer = styled.div``;
const Container = styled.div``;
const Heading = styled.div`
  width: 100%;
  display: flex;
  justify-content: space-between;
`;
const LeftContainer = styled.div`
  display: flex;
  gap: 18px;
  align-items: center;
`;

const CreateReceiptTxt = styled.h2`
  font-size: 19px;
  letter-spacing: 1px; ;
`;
const SelectBox1 = styled.div`
  &.css-1u3bzj6-MuiFormControl-root-MuiTextField-root {
    width: 100% !important;
    margin-top: 5px;
  }
  .kyHogC .css-1869usk-MuiFormControl-root {
    border-radius: 2px !important;
  }
  .css-1t8l2tu-MuiInputBase-input-MuiOutlinedInput-input {
    padding: 3.5px 14px !important;
  }
  .css-1d3z3hw-MuiOutlinedInput-notchedOutline {
    border: none !important;
  }
  .css-1869usk-MuiFormControl-root {
    min-width: 335px !important;
    margin: unset !important;
    background-color: #e9e9e9 !important ;
    @media (min-width: 1920px) {
      width: 250px;
    }
  }
  .css-1auycx3-MuiAutocomplete-root
    .MuiOutlinedInput-root
    .MuiAutocomplete-endAdornment {
    top: -1px !important;
  }
  .MuiOutlinedInput-notchedOutline {
    border-color: #d4d4d4 !important;
    border-width: 1px !important ;
    border-radius: 2px !important ;
    outline: unset !important;
  }

  div div div {
    padding: 3px;
  }

  em {
    font-style: normal !important;
    font-family: unset !important;
  }
  .css-11u53oe-MuiSelect-select-MuiInputBase-input-MuiOutlinedInput-input.css-11u53oe-MuiSelect-select-MuiInputBase-input-MuiOutlinedInput-input.css-11u53oe-MuiSelect-select-MuiInputBase-input-MuiOutlinedInput-input {
    padding-left: 12px !important;
    border: unset !important;
    outline: unset !important;
    background: #efefef !important;
  }
`;
