import React, { useState } from "react";
import styled from "styled-components/macro";

import { IconButton, Menu, MenuItem, TableSortLabel } from "@mui/material";

import MoreVertIcon from "@mui/icons-material/MoreVert";

import { useNavigate } from "react-router-dom";
import Pagination from "@mui/material/Pagination";
function OrganizationTable() {
  const navigate = useNavigate();
  const [organizationList, setOrganizationList] = useState({
    data: [
      {
        slno: "1",
        companyname: "Viknbooks",
        username: "uvais T",
        regDate: "12-13-2013",
        phone: "9876543212",
        email: "vikncodes@gmail.com",
        expiresOn: "26-12-2012",
        partner: "jasmal",
      },
      {
        slno: "2",
        companyname: "ViknErp",
        username: "jasmal",
        regDate: "12-15-2013",
        phone: "9873549212",
        email: "codes@gmail.com",
        expiresOn: "12-12-2012",
        partner: "habeeb",
      },
      {
        slno: "3",
        companyname: "Codes",
        username: "abhi",
        regDate: "12-13-2073",
        phone: "9876543000",
        email: "vikncodes@gmail.com",
        expiresOn: "16-12-2012",
        partner: "jasmal",
      },
      {
        slno: "4",
        companyname: "Codes",
        username: "abhi",
        regDate: "12-13-2073",
        phone: "9876543000",
        email: "vikncodes@gmail.com",
        expiresOn: "24-12-2012",
        partner: "jasmal",
      },
      {
        slno: "5",
        companyname: "Codes",
        username: "abhi",
        regDate: "23-13-2073",
        phone: "9876543000",
        email: "vikncodes@gmail.com",
        expiresOn: "12-12-2012",
        partner: "jasmal",
      },
      {
        slno: "6",
        companyname: "Codes",
        username: "abhi",
        regDate: "12-13-2073",
        phone: "9876543000",
        email: "vikncodes@gmail.com",
        expiresOn: "22-12-2012",
        partner: "jasmal",
      },
      {
        slno: "7",
        companyname: "Codes",
        username: "abhi",
        regDate: "12-13-2073",
        phone: "9876543000",
        email: "vikncodes@gmail.com",
        expiresOn: "21-12-2012",
        partner: "jasmal",
      },
      {
        slno: "8",
        companyname: "Codes",
        username: "abhi",
        regDate: "12-13-2073",
        phone: "9876543000",
        email: "vikncodes@gmail.com",
        expiresOn: "29-12-2012",
        partner: "jasmal",
      },
      {
        slno: "9",
        companyname: "Codes",
        username: "abhi",
        regDate: "19-13-2073",
        phone: "9876543000",
        email: "vikncodes@gmail.com",
        expiresOn: "12-12-2012",
        partner: "jasmal",
      },
      {
        slno: "10",
        companyname: "Codes",
        username: "abhi",
        regDate: "12-13-2073",
        phone: "9876543000",
        email: "vikncodes@gmail.com",
        expiresOn: "18-12-2012",
        partner: "jasmal",
      },
      {
        slno: "11",
        companyname: "Codes",
        username: "abhi",
        regDate: "12-13-2073",
        phone: "9876543000",
        email: "vikncodes@gmail.com",
        expiresOn: "17-12-2012",
        partner: "jasmal",
      },
      {
        slno: "12",
        companyname: "Codes",
        username: "abhi",
        regDate: "12-13-2073",
        phone: "9876543000",
        email: "vikncodes@gmail.com",
        expiresOn: "17-12-2012",
        partner: "jasmal",
      },
      {
        slno: "13",
        companyname: "Codes",
        username: "abhi",
        regDate: "12-13-2073",
        phone: "9876543000",
        email: "vikncodes@gmail.com",
        expiresOn: "16-12-2012",
        partner: "jasmal",
      },
      {
        slno: "14",
        companyname: "Codes",
        username: "abhi",
        regDate: "12-13-2073",
        phone: "9876543000",
        email: "vikncodes@gmail.com",
        expiresOn: "15-12-2012",
        partner: "jasmal",
      },
      {
        slno: "15",
        companyname: "Codes",
        username: "abhi",
        regDate: "12-13-2073",
        phone: "9876543000",
        email: "vikncodes@gmail.com",
        expiresOn: "14-12-2012",
        partner: "jasmal",
      },
      {
        slno: "16",
        companyname: "Codes",
        username: "abhi",
        regDate: "13-13-2073",
        phone: "9876543000",
        email: "vikncodes@gmail.com",
        expiresOn: "12-12-2012",
        partner: "jasmal",
      },
      {
        slno: "17",
        companyname: "Codes",
        username: "abhi",
        regDate: "12-13-2073",
        phone: "9876543000",
        email: "vikncodes@gmail.com",
        expiresOn: "11-12-2012",
        partner: "jasmal",
      },
      {
        slno: "18",
        companyname: "Codes",
        username: "abhi",
        regDate: "12-13-2073",
        phone: "9876543000",
        email: "vikncodes@gmail.com",
        expiresOn: "10-12-2012",
        partner: "jasmal",
      },
      {
        slno: "19",
        companyname: "Codes",
        username: "abhi",
        regDate: "12-13-2073",
        phone: "9876543000",
        email: "vikncodes@gmail.com",
        expiresOn: "9-12-2012",
        partner: "jasmal",
      },
      {
        slno: "20",
        companyname: "Codes",
        username: "abhi",
        regDate: "12-13-2073",
        phone: "9876543000",
        email: "vikncodes@gmail.com",
        expiresOn: "8-12-2012",
        partner: "jasmal",
      },
      {
        slno: "321",
        companyname: "Codes",
        username: "abhi",
        regDate: "12-13-2073",
        phone: "9876543000",
        email: "vikncodes@gmail.com",
        expiresOn: "7-12-2012",
        partner: "jasmal",
      },
      {
        slno: "22",
        companyname: "Codes",
        username: "abhi",
        regDate: "12-13-2073",
        phone: "9876543000",
        email: "vikncodes@gmail.com",
        expiresOn: "6-12-2012",
        partner: "jasmal",
      },
      {
        slno: "23",
        companyname: "Codes",
        username: "abhi",
        regDate: "12-13-2073",
        phone: "9876543000",
        email: "vikncodes@gmail.com",
        expiresOn: "5-12-2012",
        partner: "jasmal",
      },
      {
        slno: "24",
        companyname: "Codes",
        username: "abhi",
        regDate: "12-13-2073",
        phone: "9876543000",
        email: "vikncodes@gmail.com",
        expiresOn: "4-12-2012",
        partner: "jasmal",
      },
      {
        slno: "25",
        companyname: "Codes",
        username: "abhi",
        regDate: "12-13-2073",
        phone: "9876543000",
        email: "vikncodes@gmail.com",
        expiresOn: "17-12-2012",
        partner: "jasmal",
      },
      {
        slno: "26",
        companyname: "Codes",
        username: "abhi",
        regDate: "12-13-2073",
        phone: "9876543000",
        email: "vikncodes@gmail.com",
        expiresOn: "12-10-2012",
        partner: "jasmal",
      },
      {
        slno: "27",
        companyname: "Codes",
        username: "abhi",
        regDate: "12-13-2073",
        phone: "9876543000",
        email: "vikncodes@gmail.com",
        expiresOn: "2-12-2012",
        partner: "jasmal",
      },
      {
        slno: "28",
        companyname: "Codes",
        username: "abhi",
        regDate: "12-13-2073",
        phone: "9876543000",
        email: "vikncodes@gmail.com",
        expiresOn: "12-11-2012",
        partner: "jasmal",
      },
      {
        slno: "29",
        companyname: "Codes",
        username: "abhi",
        regDate: "12-13-2553",
        phone: "9876543000",
        email: "vikncodes@gmail.com",
        expiresOn: "12-12-2582",
        partner: "jasmal",
      },
    ],
  });

  const [rotate, setRotate] = useState({
    arrow1: true,
    arrow2: true,
  });

  const options = ["Edit", "Delete", "View"];
  const [anchorEl, setAnchorEl] = useState(null);
  const open = Boolean(anchorEl);

  const [currentIndex, setCurrentIndex] = useState(0);
  const handleClick = (index) => (event) => {
    setAnchorEl(event.currentTarget);
    setCurrentIndex(index);
  };
  const handleClose = () => {
    setAnchorEl(null);
  };
  const ITEM_HEIGHT = 48;

  const createSortHandler = () => {
    // setRotate((rotate.arrow2 = false));
    setRotate({
      ...rotate,
      arrow2: !rotate.arrow2,
    });
  };

  const createSort = () => {
    setRotate({ ...rotate, arrow1: !rotate.arrow1 });
  };

  const SelectOrganization = (organizationName) => {
    if (organizationName === "Viknbooks") {
      navigate("/viknbooks");
    } else if (organizationName === "ViknErp") {
      navigate("/vikn-erp");
    } else return;
  };

  //pagination=======================================
  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage, setItemsPerPage] = useState(18);

  const IndexofLastItem = currentPage * itemsPerPage;
  const indexOfFirstDish = IndexofLastItem - itemsPerPage;
  let PaginatedData = organizationList.data.slice(
    indexOfFirstDish,
    IndexofLastItem
  );

  const ChangePage = (event, value) => {
    setCurrentPage(value);
  };

  const NumOfpages = Math.ceil(organizationList.data.length / itemsPerPage);

  return (
    <TableContainer>
      <Table>
        <THead>
          <TableHeadRow>
            <TH> SI No</TH>
            <TH>Company Name</TH>
            <TH>Username</TH>
            <TH>
              Reg-Date
              <ArrowReg
                rotate={rotate.arrow2}
                active={true}
                direction="asc"
                onClick={(e) => createSortHandler()}
              ></ArrowReg>
            </TH>
            <TH>Phone No</TH>
            <TH>Email Address</TH>
            <TH>
              Expires-On
              <Arrow
                rotate={rotate.arrow1}
                active={true}
                direction="asc"
                onClick={(e) => createSort()}
              ></Arrow>
            </TH>

            <TH>Partner</TH>
            <TH></TH>
          </TableHeadRow>
        </THead>
        <TBody>
          {PaginatedData.map((i, index) => (
            <TableBodyRow>
              <TD onClick={(e) => SelectOrganization(i.companyname)}>
                {i.slno}
              </TD>
              <TD onClick={(e) => SelectOrganization(i.companyname)}>
                {i.companyname}
              </TD>
              <TD onClick={(e) => SelectOrganization(i.companyname)}>
                {i.username}
              </TD>
              <TD onClick={(e) => SelectOrganization(i.companyname)}>
                {i.regDate}
              </TD>
              <TD onClick={(e) => SelectOrganization(i.companyname)}>
                {i.phone}
              </TD>
              <TD onClick={(e) => SelectOrganization(i.companyname)}>
                {i.email}
              </TD>
              <TD>{i.expiresOn}</TD>
              <TD onClick={(e) => SelectOrganization(i.companyname)}>
                {i.partner}
              </TD>
              <TD style={{ textAlign: "right" }}>
                <RightSide>
                  <IconButton
                    aria-label="more"
                    id={index}
                    aria-controls={open ? "long-menu" : undefined}
                    aria-expanded={open ? "true" : undefined}
                    aria-haspopup="true"
                    onClick={handleClick(index)}

                    // onOpen={handleClick(index)}
                  >
                    <MoreVertIcon />
                  </IconButton>
                  {index === currentIndex ? (
                    <Menus
                      disableScrollLock={true}
                      onOpen={Boolean(anchorEl)}
                      id="long-menu"
                      MenuListProps={
                        {
                          // "aria-labelledby": ` ${index}`,
                        }
                      }
                      anchorEl={anchorEl}
                      open={open}
                      keepMounted
                      onClose={handleClose}
                      PaperProps={{
                        style: {
                          maxHeight: ITEM_HEIGHT * 4.5,
                          width: "20ch",
                        },
                      }}
                    >
                      {options.map((option) => (
                        <MenuItem
                          key={option}
                          selected={option === "Edit"}
                          onClick={handleClose}
                        >
                          {option}
                        </MenuItem>
                      ))}
                    </Menus>
                  ) : null}
                </RightSide>
              </TD>
            </TableBodyRow>
          ))}
        </TBody>
      </Table>{" "}
      <PaginationContainer>
        <Pagination count={NumOfpages} onChange={ChangePage} />
      </PaginationContainer>
    </TableContainer>
  );
}

export default OrganizationTable;
const PaginationContainer = styled.div`
  width: 100%;
  display: flex;
  margin-top: 10px;
  justify-content: center;
`;
const Menus = styled(Menu)`
  && {
    .css-1poimk-MuiPaper-root-MuiMenu-paper-MuiPaper-root-MuiPopover-paper {
      width: 17ch !important;
      left: 1212px !important;
      @media (width: 1309.09px) {
        left: 1083px !important;
      }
      @media (width: 1920px) {
        left: 1687px !important;
      }
      @media (width: 1600px) {
        left: 1371px !important;
      }
      @media (width: 1800px) {
        left: 98rem !important;
      }
      ::-webkit-scrollbar {
        display: none !important;
      }
    }
  }
`;
const RightSide = styled.div`
  height: 100%;
  svg {
    font-size: 1.1rem !important ;
    color: black !important;
  }
  .css-78trlr-MuiButtonBase-root-MuiIconButton-root {
    padding: unset !important;
  }
  .MuiPaper-root {
    box-shadow: unset !important;
  }
`;

const Arrow = styled(TableSortLabel)`
  svg {
    color: white !important;
    transform: ${({ rotate }) => (rotate ? `rotate(180deg)` : ` rotate(0deg)`)};
  }
`;
const ArrowReg = styled(TableSortLabel)`
  svg {
    color: white !important;
    transform: ${({ rotate }) => (rotate ? `rotate(180deg)` : ` rotate(0deg)`)};
  }
`;
const TableContainer = styled.div`
  margin-top: 15px;
`;
const TD = styled.td`
  padding: 5px 15px !important;
  text-align: left;
  padding: 0.5em 1em;
  cursor: pointer;
  font-size: 12px;

  border-bottom: 1px solid #ababab;
  vertical-align: middle;

  &.cursor {
    cursor: pointer;
  }
`;

const TableBodyRow = styled.tr`
  :hover {
    background-color: rgba(0, 0, 0, 0.04);
  }
`;
const Table = styled.table`
  border-radius: 15px;
  width: 100%;
  background: #fff;
  border-spacing: unset;
`;

const THead = styled.thead`
  box-shadow: 0 0 0 1px #c6c6c6;
  border-radius: 3px;
  background-color: black;
  color: white;
`;
const TableHeadRow = styled.tr``;
const TBody = styled.tbody``;
const TH = styled.th`
  padding: 5px 15px;
  font-weight: normal;
  text-align: left;
  font-size: 14px;
`;
