import React, { useState } from "react";
import styled from "styled-components/macro";
import CreateButton from "../../Components/CreateButton";
import DatePicker from "../../Components/DatePicker";
import { IconButton, Menu, MenuItem, TextField } from "@mui/material";
import CreateInvoice from "./CreateInvoice";
import PercentIcon from "@mui/icons-material/Percent";
import MoreVertIcon from "@mui/icons-material/MoreVert";
import Pagination from "@mui/material/Pagination";
function CompanyInvoice() {
  const options = ["Edit", "Delete", "View"];
  const [anchorEl, setAnchorEl] = useState(null);
  const open = Boolean(anchorEl);
  const [show, setShow] = useState(true);

  const [currentIndex, setCurrentIndex] = useState();
  const handleClick = (index) => (event) => {
    setAnchorEl(event.currentTarget);
    setCurrentIndex(index);
  };
  const handleClose = () => {
    setAnchorEl(null);
  };
  const ITEM_HEIGHT = 48;

  const [invoice, setInvoice] = useState({
    data: [
      {
        slno: "11",
        voucherNo: "1020",
        Organization: "vikncodes",
        billdiscount: "10",
        total: "1123198197",
      },

      {
        slno: "12",
        voucherNo: "1520",
        Organization: "vikncodes",
        billdiscount: "30",
        total: "198197",
      },
      {
        slno: "13",
        voucherNo: "15540",
        Organization: "vikncodes",
        billdiscount: "80",
        total: "98698",
      },
      {
        slno: "14",
        voucherNo: "15540",
        Organization: "vikncodes",
        billdiscount: "80",
        total: "98698",
      },
      {
        slno: "15",
        voucherNo: "15540",
        Organization: "vikncodes",
        billdiscount: "80",
        total: "98698",
      },
      {
        slno: "16",
        voucherNo: "15540",
        Organization: "vikncodes",
        billdiscount: "80",
        total: "98698",
      },
      {
        slno: "17",
        voucherNo: "15540",
        Organization: "vikncodes",
        billdiscount: "80",
        total: "98698",
      },
      {
        slno: "18",
        voucherNo: "15540",
        Organization: "vikncodes",
        billdiscount: "80",
        total: "98698",
      },
      {
        slno: "19",
        voucherNo: "15540",
        Organization: "vikncodes",
        billdiscount: "80",
        total: "98698",
      },
      {
        slno: "10",
        voucherNo: "15540",
        Organization: "vikncodes",
        billdiscount: "80",
        total: "98698",
      },
      {
        slno: "11",
        voucherNo: "15540",
        Organization: "vikncodes",
        billdiscount: "80",
        total: "98698",
      },
      {
        slno: "12",
        voucherNo: "15540",
        Organization: "vikncodes",
        billdiscount: "80",
        total: "98698",
      },
      {
        slno: "13",
        voucherNo: "15540",
        Organization: "vikncodes",
        billdiscount: "80",
        total: "98698",
      },
      {
        slno: "14",
        voucherNo: "15540",
        Organization: "vikncodes",
        billdiscount: "80",
        total: "98698",
      },
      {
        slno: "15",
        voucherNo: "15540",
        Organization: "vikncodes",
        billdiscount: "80",
        total: "98698",
      },
      {
        slno: "16",
        voucherNo: "15540",
        Organization: "vikncodes",
        billdiscount: "80",
        total: "98698",
      },
      {
        slno: "17",
        voucherNo: "15540",
        Organization: "vikncodes",
        billdiscount: "80",
        total: "98698",
      },
      {
        slno: "18",
        voucherNo: "15540",
        Organization: "vikncodes",
        billdiscount: "80",
        total: "98698",
      },
      {
        slno: "19",
        voucherNo: "15540",
        Organization: "vikncodes",
        billdiscount: "80",
        total: "98698",
      },
      {
        slno: "20",
        voucherNo: "15540",
        Organization: "vikncodes",
        billdiscount: "80",
        total: "98698",
      },
      {
        slno: "21",
        voucherNo: "15540",
        Organization: "vikncodes",
        billdiscount: "80",
        total: "98698",
      },
      {
        slno: "22",
        voucherNo: "15540",
        Organization: "vikncodes",
        billdiscount: "80",
        total: "98698",
      },
      {
        slno: "23",
        voucherNo: "15540",
        Organization: "vikncodes",
        billdiscount: "80",
        total: "98698",
      },
      {
        slno: "24",
        voucherNo: "15540",
        Organization: "vikncodes",
        billdiscount: "80",
        total: "98698",
      },
      {
        slno: "25",
        voucherNo: "15540",
        Organization: "vikncodes",
        billdiscount: "80",
        total: "98698",
      },
      {
        slno: "26",
        voucherNo: "15540",
        Organization: "vikncodes",
        billdiscount: "80",
        total: "98698",
      },
      {
        slno: "27",
        voucherNo: "15540",
        Organization: "vikncodes",
        billdiscount: "80",
        total: "98698",
      },
      {
        slno: "28",
        voucherNo: "15540",
        Organization: "vikncodes",
        billdiscount: "80",
        total: "98698",
      },
      {
        slno: "29",
        voucherNo: "15540",
        Organization: "vikncodes",
        billdiscount: "80",
        total: "98698",
      },
      {
        slno: "30",
        voucherNo: "15540",
        Organization: "vikncodes",
        billdiscount: "80",
        total: "98698",
      },
      {
        slno: "31",
        voucherNo: "15540",
        Organization: "vikncodes",
        billdiscount: "80",
        total: "98698",
      },
      {
        slno: "32",
        voucherNo: "15540",
        Organization: "vikncodes",
        billdiscount: "80",
        total: "98698",
      },
      {
        slno: "33",
        voucherNo: "15540",
        Organization: "vikncodes",
        billdiscount: "80",
        total: "98698",
      },
      {
        slno: "34",
        voucherNo: "15540",
        Organization: "vikncodes",
        billdiscount: "80",
        total: "98698",
      },
      {
        slno: "35",
        voucherNo: "15540",
        Organization: "vikncodes",
        billdiscount: "80",
        total: "98698",
      },
      {
        slno: "36",
        voucherNo: "15540",
        Organization: "vikncodes",
        billdiscount: "80",
        total: "98698",
      },
      {
        slno: "37",
        voucherNo: "15540",
        Organization: "vikncodes",
        billdiscount: "80",
        total: "98698",
      },
    ],
  }); //pagination=======================================

  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage, setItemsPerPage] = useState(18);

  const IndexofLastItem = currentPage * itemsPerPage;
  const indexOfFirstDish = IndexofLastItem - itemsPerPage;
  let PaginatedData = invoice.data.slice(indexOfFirstDish, IndexofLastItem);
  console.log("page", PaginatedData);

  const ChangePage = (event, value) => {
    setCurrentPage(value);
  };

  const NumOfpages = Math.ceil(invoice.data.length / itemsPerPage);

  return (
    <Container>
      {show ? (
        <>
          <Heading>
            <LeftContainer>
              <InvoiceTxt>Invoices</InvoiceTxt>
              <BoxContainer>
                <DatePicker />
              </BoxContainer>
            </LeftContainer>

            <CreateButtonContainer onClick={() => setShow(!show)}>
              <CreateButton label={"Add New"} />
            </CreateButtonContainer>
          </Heading>

          <TableContainer>
            <Table>
              <THead>
                <TableHeadRow>
                  <TH> SI No </TH>
                  <TH> Voucher No </TH>
                  <TH> Organization </TH>
                  <TH> Bill Discount </TH>
                  <TH> Total </TH>

                  <TH></TH>
                </TableHeadRow>
              </THead>
              <TBody>
                {PaginatedData.map((i, index) => (
                  <TableBodyRow>
                    <TD>{i.slno}</TD>
                    <TD>{i.voucherNo}</TD>
                    <TD>{i.Organization}</TD>
                    <TD>{i.billdiscount}</TD>
                    <TD>{i.total}</TD>

                    <TD style={{ textAlign: "right" }}>
                      <RightSide>
                        <IconButton
                          aria-label="more"
                          id={index}
                          aria-controls={open ? "long-menu" : undefined}
                          aria-expanded={open ? "true" : undefined}
                          aria-haspopup="true"
                          onClick={handleClick(index)}
                        >
                          <MoreVertIcon />
                        </IconButton>

                        {currentIndex === index ? (
                          <Menus
                            // id="long-menu"
                            MenuListProps={
                              {
                                // "aria-labelledby": ` ${index}`,
                              }
                            }
                            disableScrollLock={true}
                            anchorEl={anchorEl}
                            open={open}
                            onClose={handleClose}
                            PaperProps={{
                              style: {
                                maxHeight: ITEM_HEIGHT * 4.5,
                                width: "20ch",
                              },
                            }}
                          >
                            {options.map((option) => (
                              <MenuItem
                                key={option}
                                selected={option === "Edit"}
                                onClick={handleClose}
                              >
                                {option}
                              </MenuItem>
                            ))}
                          </Menus>
                        ) : null}
                      </RightSide>
                    </TD>
                  </TableBodyRow>
                ))}
              </TBody>
            </Table>
            <PaginationContainer>
              <Pagination count={NumOfpages} onChange={ChangePage} />
            </PaginationContainer>
          </TableContainer>
        </>
      ) : (
        //    Add Invoice........................
        <>
          <CreateInvoice />
          <AddInvoiceContainer>
            <BottomRightContainer>
              <BottomLeftContainer>
                <AmountContainerleft>
                  <Label>Bill Discount : </Label>
                  <TextFieldContainer>
                    <CustomTextField3 id="outlined-basic" variant="outlined" />
                    <CustomTextField2 id="outlined-basic" variant="outlined" />
                    <PercentageIcon />
                  </TextFieldContainer>
                </AmountContainerleft>
              </BottomLeftContainer>

              <AmountContainerRight>
                <GridContainer>
                  <GridItem> Total TAX Amount </GridItem>
                  <GridItem> - </GridItem>
                  <GridItem> 0.00 </GridItem>
                  <GridItem> Net Total </GridItem>
                  <GridItem> - </GridItem>
                  <GridItem> 0.00 </GridItem>
                  <GridItem style={{ fontWeight: "bold" }}>
                    Grand Total
                  </GridItem>
                  <GridItem></GridItem>
                  <GridItem style={{ fontWeight: "bold" }}> 0.00</GridItem>
                </GridContainer>
              </AmountContainerRight>
            </BottomRightContainer>
          </AddInvoiceContainer>
        </>
      )}
    </Container>
  );
}

export default CompanyInvoice;
const PaginationContainer = styled.div`
  width: 100%;
  display: flex;
  margin-top: 10px;
  justify-content: center;
`;
const BottomLeftContainer = styled.div`
  display: flex;
`;
const GridItem = styled.div`
  text-align: center;
  padding: 0px 30px;
  font-size: 13px;
`;
const GridContainer = styled.div`
  display: grid;
  grid-template-columns: auto auto auto;
  gap: 10px;

  padding: 10px;
`;
const AddInvoiceContainer = styled.div`
  background: white;
`;

const TextFieldContainer = styled.div`
  display: flex;
  gap: 10px;
  position: relative;
  /* @media (min-width: 1920px) {
    gap: 18px;
  } */
`;

const PercentageIcon = styled(PercentIcon)`
  && {
    font-size: 1rem !important;
  }
  position: absolute;
  top: 8px;
  right: 109px;
  @media (min-width: 1920px) {
    right: 128px;
  }
`;

const Label = styled.label`
  font-size: 13px;
  padding-right: 16px;
  font-size: 13px;
  margin-top: 5px;
`;
const CustomTextField = styled(TextField)`
  && {
    /* min-width: 150px; */
  }
  border: unset !important;
  outline: unset !important;
  &.css-1u3bzj6-MuiFormControl-root-MuiTextField-root {
    border-radius: 2px;
  }
  .css-1t8l2tu-MuiInputBase-input-MuiOutlinedInput-input {
    padding: 3.5px 30px 3.5px 14px !important;
  }
  .css-1d3z3hw-MuiOutlinedInput-notchedOutline {
    border-color: #d4d4d4 !important;
    border-width: 1px !important;
  }
`;

// const CustomTextField2 = styled(CustomTextField)`
//   && {
//     min-width: 100px;
//   }
// `;
const CustomTextField2 = styled(TextField)`
  border: unset !important;
  outline: unset !important;

  &.css-1u3bzj6-MuiFormControl-root-MuiTextField-root {
    border-radius: 2px;
  }
  .css-1t8l2tu-MuiInputBase-input-MuiOutlinedInput-input {
    padding: 5.6px 10px 5.6px 10px !important;
    font-size: 12px !important;
    &::-webkit-input-placeholder {
      font-size: 10px;
    }
  }
  .fXHxYA
    .css-1t8l2tu-MuiInputBase-input-MuiOutlinedInput-input:-moz-placeholder {
    font-size: 12px;
  }
  .css-1t8l2tu-MuiInputBase-input-MuiOutlinedInput-input::placeholder {
    font-size: 12px !important;
  }
  .css-1d3z3hw-MuiOutlinedInput-notchedOutline {
    border-color: #d4d4d4 !important;
    border-width: 1px !important;
  }
  && {
    width: 90px !important;

    @media (min-width: 1920px) {
      width: 105px !important;
    }
  }
`;
const CustomTextField3 = styled(CustomTextField)`
  .css-1t8l2tu-MuiInputBase-input-MuiOutlinedInput-input {
    font-size: 12px;
    padding: 5.6px 30px 5.6px 10px !important;
  }
  &.css-1u3bzj6-MuiFormControl-root-MuiTextField-root {
    width: 90px !important;
    @media (min-width: 1920px) {
      width: 105px !important;
    }
  }
`;
const AmountContainerRight = styled.div`
  /* width: 48%; */
`;
const AmountContainerleft = styled.div`
  /* width: 48%; */
  display: flex;
  gap: 10px;
  margin-top: 10px;
`;
const BottomRightContainer = styled.div`
  padding: 15px;

  justify-content: flex-end;
  display: flex;
`;

const Container = styled.div``;
const Heading = styled.div`
  width: 100%;
  display: flex;
  justify-content: space-between;
`;
const LeftContainer = styled.div`
  display: flex;
  gap: 18px;
  align-items: center;
`;
const InvoiceTxt = styled.h2`
  font-size: 19px;
  letter-spacing: 1px; ;
`;
const CreateButtonContainer = styled.div`
  position: relative;
`;

const BoxContainer = styled.div`
  .css-1auycx3-MuiAutocomplete-root
    .MuiOutlinedInput-root.MuiInputBase-sizeSmall {
    padding: 7px !important;
    width: 156px;
    @media (min-width: 1920px) {
      width: 250px;
    }
  }
  display: flex;
  align-items: center;
  gap: 5px;
  @media (min-width: 1920px) {
    display: flex;
    gap: 15px;
  }
`;

const Menus = styled(Menu)`
  .css-1poimk-MuiPaper-root-MuiMenu-paper-MuiPaper-root-MuiPopover-paper {
    width: 17ch !important;
    left: 1212px !important;

    @media (width: 1309.09px) {
      left: 1083px !important;
    }
    @media (width: 1920px) {
      left: 1687px !important;
    }
    @media (width: 1600px) {
      left: 1371px !important;
    }
    @media (width: 1800px) {
      left: 98rem !important;
    }
    ::-webkit-scrollbar {
      display: none !important;
    }
  }
`;
const RightSide = styled.div`
  height: 100%;
  svg {
    font-size: 1.1rem !important ;
    color: black !important;
  }
  .css-78trlr-MuiButtonBase-root-MuiIconButton-root {
    padding: unset !important;
  }
  .MuiPaper-root {
    box-shadow: none !important;
  }
`;

const TableContainer = styled.div`
  margin-top: 15px;
`;
const TD = styled.td`
  font-size: 12px;

  text-align: left;
  padding: 5px 15px;
  border-bottom: 1px solid #ababab;
  vertical-align: middle;

  &.cursor {
    cursor: pointer;
  }
`;
const TableBodyRow = styled.tr`
  :hover {
    background-color: rgba(0, 0, 0, 0.04);
  }
`;
const Table = styled.table`
  border-radius: 15px;
  width: 100%;
  background: #fff;
  border-spacing: unset;
`;

const THead = styled.thead`
  box-shadow: 0 0 0 1px #c6c6c6;
  border-radius: 3px;
  background-color: black;
  color: white;
`;
const TableHeadRow = styled.tr``;
const TBody = styled.tbody``;
const TH = styled.th`
  padding: 5px 15px;
  font-weight: normal;
  text-align: left;
  font-size: 14px;
`;
