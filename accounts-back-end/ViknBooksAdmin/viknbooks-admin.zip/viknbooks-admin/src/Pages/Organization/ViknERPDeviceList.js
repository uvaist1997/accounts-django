import React, { useState } from "react";
import styled from "styled-components/macro";

import { IconButton, Menu, MenuItem, TableSortLabel } from "@mui/material";

import MoreVertIcon from "@mui/icons-material/MoreVert";
import Pagination from "@mui/material/Pagination";
function ViknERPDeviceList() {
  const options = ["Edit", "Delete", "Block"];
  const [anchorEl, setAnchorEl] = useState(null);
  const open = Boolean(anchorEl);

  const handleClose = () => {
    setAnchorEl(null);
  };
  const ITEM_HEIGHT = 48;
  const [deviceList, setDeviceLIst] = useState({
    data: [
      {
        slno: "1",
        devicename: "hp",
        devicecode: "34422",
        ipaddress: "11:55:00:4",
        os: "vvvvvvv",

        expiryDate: "12-12-2021",
        status: "last active",
      },
      {
        slno: "2",
        devicename: "lenovo",
        devicecode: "14289",
        ipaddress: "11:55:09:4",
        os: "aaaaaa",

        expiryDate: "12-12-2021",
        status: "last active",
      },
      {
        slno: "3",
        devicename: "hp",
        devicecode: "3453453",
        ipaddress: "21:243:235:66",
        os: "nnnnnnn",

        expiryDate: "12-12-2021",
        status: "last active",
      },
      {
        slno: "4",
        devicename: "hp",
        devicecode: "3453453",
        ipaddress: "21:243:235:66",
        os: "nnnnnnn",

        expiryDate: "12-12-2021",
        status: "last active",
      },
      {
        slno: "5",
        devicename: "hp",
        devicecode: "3453453",
        ipaddress: "21:243:235:66",
        os: "nnnnnnn",

        expiryDate: "12-12-2021",
        status: "last active",
      },
      {
        slno: "6",
        devicename: "hp",
        devicecode: "3453453",
        ipaddress: "21:243:235:66",
        os: "nnnnnnn",

        expiryDate: "12-12-2021",
        status: "last active",
      },
      {
        slno: "7",
        devicename: "hp",
        devicecode: "3453453",
        ipaddress: "21:243:235:66",
        os: "nnnnnnn",

        expiryDate: "12-12-2021",
        status: "last active",
      },
      {
        slno: "8",
        devicename: "hp",
        devicecode: "3453453",
        ipaddress: "21:243:235:66",
        os: "nnnnnnn",

        expiryDate: "12-12-2021",
        status: "last active",
      },
      {
        slno: "9",
        devicename: "hp",
        devicecode: "3453453",
        ipaddress: "21:243:235:66",
        os: "nnnnnnn",

        expiryDate: "12-12-2021",
        status: "last active",
      },
      {
        slno: "10",
        devicename: "hp",
        devicecode: "3453453",
        ipaddress: "21:243:235:66",
        os: "nnnnnnn",

        expiryDate: "12-12-2021",
        status: "last active",
      },
      {
        slno: "11",
        devicename: "hp",
        devicecode: "3453453",
        ipaddress: "21:243:235:66",
        os: "nnnnnnn",

        expiryDate: "12-12-2021",
        status: "last active",
      },
      {
        slno: "12",
        devicename: "hp",
        devicecode: "3453453",
        ipaddress: "21:243:235:66",
        os: "nnnnnnn",

        expiryDate: "12-12-2021",
        status: "last active",
      },
      {
        slno: "13",
        devicename: "hp",
        devicecode: "3453453",
        ipaddress: "21:243:235:66",
        os: "nnnnnnn",

        expiryDate: "12-12-2021",
        status: "last active",
      },
      {
        slno: "14",
        devicename: "hp",
        devicecode: "3453453",
        ipaddress: "21:243:235:66",
        os: "nnnnnnn",

        expiryDate: "12-12-2021",
        status: "last active",
      },
      {
        slno: "15",
        devicename: "hp",
        devicecode: "3453453",
        ipaddress: "21:243:235:66",
        os: "nnnnnnn",

        expiryDate: "12-12-2021",
        status: "last active",
      },
      {
        slno: "16",
        devicename: "hp",
        devicecode: "3453453",
        ipaddress: "21:243:235:66",
        os: "nnnnnnn",

        expiryDate: "12-12-2021",
        status: "last active",
      },
      {
        slno: "17",
        devicename: "hp",
        devicecode: "3453453",
        ipaddress: "21:243:235:66",
        os: "nnnnnnn",

        expiryDate: "12-12-2021",
        status: "last active",
      },
      {
        slno: "18",
        devicename: "hp",
        devicecode: "3453453",
        ipaddress: "21:243:235:66",
        os: "nnnnnnn",

        expiryDate: "12-12-2021",
        status: "last active",
      },
      {
        slno: "19",
        devicename: "hp",
        devicecode: "3453453",
        ipaddress: "21:243:235:66",
        os: "nnnnnnn",

        expiryDate: "12-12-2021",
        status: "last active",
      },
      {
        slno: "20",
        devicename: "hp",
        devicecode: "3453453",
        ipaddress: "21:243:235:66",
        os: "nnnnnnn",

        expiryDate: "12-12-2021",
        status: "last active",
      },
      {
        slno: "21",
        devicename: "hp",
        devicecode: "3453453",
        ipaddress: "21:243:235:66",
        os: "nnnnnnn",

        expiryDate: "12-12-2021",
        status: "last active",
      },
    ],
  });

  //pagination=======================================
  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage, setItemsPerPage] = useState(17);

  const IndexofLastItem = currentPage * itemsPerPage;
  const indexOfFirstDish = IndexofLastItem - itemsPerPage;
  let PaginatedData = deviceList.data.slice(indexOfFirstDish, IndexofLastItem);

  console.log(PaginatedData);
  const ChangePage = (event, value) => {
    setCurrentPage(value);
  };

  const NumOfpages = Math.ceil(deviceList.data.length / itemsPerPage);
  const [currentIndex, setCurrentIndex] = useState();
  const handleClick = (index) => (event) => {
    setAnchorEl(event.currentTarget);
    setCurrentIndex(index);
  };
  return (
    <TableContainer>
      <Table>
        <THead>
          <TableHeadRow>
            <TH> SI No </TH>
            <TH> Device Name </TH>
            <TH> Device Code </TH>
            <TH> IP Address </TH>
            <TH>OS</TH>
            <TH> Expiry Date</TH>

            <TH>Status</TH>
            <TH></TH>
          </TableHeadRow>
        </THead>
        <TBody>
          {PaginatedData.map((i, index) => (
            <TableBodyRow>
              <TD>{i.slno}</TD>

              <TD>{i.devicename}</TD>
              <TD>{i.devicecode}</TD>
              <TD>{i.ipaddress}</TD>
              <TD>{i.os}</TD>
              <TD>{i.expiryDate}</TD>

              <TD>
                <Indicator>
                  <LoginSpan></LoginSpan>
                  <span> {i.status}</span>
                </Indicator>
              </TD>

              <TD style={{ textAlign: "right" }}>
                <RightSide>
                  <IconButton
                    aria-label="more"
                    id={index}
                    aria-controls={open ? "long-menu" : undefined}
                    aria-expanded={open ? "true" : undefined}
                    aria-haspopup="true"
                    onClick={handleClick(index)}
                  >
                    <MoreVertIcon />
                  </IconButton>

                  {currentIndex === index ? (
                    <Menus
                      // id="long-menu"
                      MenuListProps={
                        {
                          // "aria-labelledby": ` ${index}`,
                        }
                      }
                      anchorEl={anchorEl}
                      open={open}
                      onClose={handleClose}
                      PaperProps={{
                        style: {
                          maxHeight: ITEM_HEIGHT * 4.5,
                          width: "20ch",
                        },
                      }}
                    >
                      {options.map((option) => (
                        <MenuItem
                          key={option}
                          selected={option === "Edit"}
                          onClick={handleClose}
                        >
                          {option}
                        </MenuItem>
                      ))}
                    </Menus>
                  ) : null}
                </RightSide>
              </TD>
            </TableBodyRow>
          ))}
        </TBody>
      </Table>
      <PaginationContainer>
        <Pagination count={NumOfpages} onChange={ChangePage} />
      </PaginationContainer>
    </TableContainer>
  );
}

export default ViknERPDeviceList;

const PaginationContainer = styled.div`
  width: 100%;
  display: flex;
  margin-top: 10px;
  justify-content: center;
`;
const Indicator = styled.div`
  display: flex;
  align-items: center;
  gap: 5px;
`;
const Menus = styled(Menu)`
  && {
    .css-1poimk-MuiPaper-root-MuiMenu-paper-MuiPaper-root-MuiPopover-paper {
      width: 17ch !important;
      left: 1212px !important;
      @media (width: 1309.09px) {
        left: 1083px !important;
      }
      @media (width: 1920px) {
        left: 1687px !important;
      }
      @media (width: 1600px) {
        left: 1371px !important;
      }
      @media (width: 1800px) {
        left: 98rem !important;
      }
      ::-webkit-scrollbar {
        display: none !important;
      }
    }
  }
`;
const RightSide = styled.div`
  height: 100%;
  svg {
    font-size: 1.1rem !important ;
    color: black !important;
  }
  .css-78trlr-MuiButtonBase-root-MuiIconButton-root {
    padding: unset !important;
  }
  .MuiPaper-root {
    box-shadow: none !important;
  }
`;

const TableContainer = styled.div`
  margin-top: 15px;
`;
const TD = styled.td`
  font-size: 12px;
  padding: 5px 15px !important;
  text-align: left;

  border-bottom: 1px solid #ababab;
  vertical-align: middle;

  &.cursor {
    cursor: pointer;
  }
`;
const TableBodyRow = styled.tr`
  :hover {
    background-color: rgba(0, 0, 0, 0.04);
  }
`;
const Table = styled.table`
  border-radius: 15px;
  width: 100%;
  background: #fff;
  border-spacing: unset;
`;
const LoginSpan = styled.span`
  width: 12px;
  height: 12px;

  border-radius: 50%;
  background: #bf6d02;
`;
const THead = styled.thead`
  box-shadow: 0 0 0 1px #c6c6c6;
  border-radius: 3px;
  background-color: black;
  color: white;
`;
const TableHeadRow = styled.tr``;
const TBody = styled.tbody``;
const TH = styled.th`
  padding: 5px 15px;
  font-weight: normal;
  text-align: left;
  font-size: 14px;
  @media (width: 1309.09px) {
    padding: 5px 14px;
  }
`;
