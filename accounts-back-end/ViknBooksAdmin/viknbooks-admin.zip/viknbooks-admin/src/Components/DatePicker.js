import React, { useState } from "react";

import styled from "styled-components/macro";

import CalendarTodayIcon from "@mui/icons-material/CalendarToday";

import DateRangePicker from "@wojtekmaj/react-daterange-picker";

import { IconButton } from "@mui/material";

export default function DatePicker() {
  //   const [value, setValue] = React.useState([null, null]);
  //   const [date, setDate] = useState([new Date(), new Date()]);
  const [date, setDate] = useState([new Date(), new Date()]);

  const onChange = (date) => setDate(date);

  //   const onChange = date => console.log(date);
  return (
    <Container>
      <DateRangePicker
        calendarIcon={
          <IconButton>
            <CalendarTodayIcon />
          </IconButton>
        }
        onChange={onChange}
        value={date}
        className={
          ("react-daterange-picker__wrapper",
          "react-daterange-picker__range-divider")
        }
        clearIcon
        format={"MM-dd-y"}
      />
    </Container>
  );
}
const Container = styled.div`
  && {
    font-size: 13px;
  }
  .jNgEnn .css-78trlr-MuiButtonBase-root-MuiIconButton-root {
    padding: 0px 0px 4px 7px !important;
  }
  .react-calendar__month-view__weekdays {
    color: rebeccapurple;
    font-family: unset !important;
    inset: unset !important;
    letter-spacing: 1px;
  }

  .react-daterange-picker__calendar {
    top: 43px !important;
  }
  .react-calendar__tile--active:enabled:hover,
  .react-calendar__tile--active:enabled:focus {
    background-color: rgb(248, 213, 213) !important  ;
  }

  .react-calendar__tile--now {
    background-color: rgb(241, 242, 252) !important;
  }
  .react-calendar__tile--active {
    background-color: rgb(248, 213, 213) !important ;
  }
  .react-calendar__tile--hasActive {
    background-color: rgb(248, 213, 213) !important ;
  }
  .react-calendar__tile--hasActive:enabled:hover,
  .react-calendar__tile--hasActive:enabled:focus {
    background-color: rgb(248, 213, 213) !important;
  }
  .react-daterange-picker__calendar .react-calendar {
    border: unset !important ;
    padding: 10px;
    box-shadow: 0px 2px 1px -1px rgb(0 0 0 / 20%),
      0px 1px 1px 0px rgb(0 0 0 / 14%), 0px 1px 3px 0px rgb(0 0 0 / 12%);
    border-radius: 4px;
  }
  abbr {
    text-decoration: none !important;
  }
  .react-daterange-picker {
    color: white !important;
  }
  svg {
    font-size: 1.3rem !important;
  }
  .react-calendar__navigation {
    margin-bottom: unset !important ;
  }
  .react-daterange-picker__button {
    padding: unset !important;
  }

  .css-78trlr-MuiButtonBase-root-MuiIconButton-root {
    color: white !important;
  }
  .react-daterange-picker__wrapper {
    background-color: black !important ;
    border: unset !important;
    border-radius: 4px;
    padding: 5px 8px;
  }
  .css-78trlr-MuiButtonBase-root-MuiIconButton-root {
    padding: 0px 4px 0px 0px !important;
  }
  .react-daterange-picker__wrapper {
    button:last-child {
      order: -1;
    }
  }
  input {
    color: white !important;
    outline: none !important ;
  }
  .css-1t8l2tu-MuiInputBase-input-MuiOutlinedInput-input {
    padding: 0px 10px !important;
  }

  label {
    display: none !important;
  }
  fieldset {
    border: none !important;
  }
`;
