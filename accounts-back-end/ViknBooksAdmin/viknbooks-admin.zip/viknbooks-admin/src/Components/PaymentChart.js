import React, { useState } from "react";
import styled from "styled-components/macro";
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend,
} from "chart.js";
import { Line, Bar } from "react-chartjs-2";
import InputLabel from "@mui/material/InputLabel";
import MenuItem from "@mui/material/MenuItem";
import FormHelperText from "@mui/material/FormHelperText";
import FormControl from "@mui/material/FormControl";
import Select from "@mui/material/Select";
import { CardActionArea } from "@mui/material";
import Typography from "@mui/material/Typography";
import CardContent from "@mui/material/CardContent";
import CardMedia from "@mui/material/CardMedia";
ChartJS.register(
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend
);

export const PaymentChart = () => {
  const [card, setCard] = useState([
    {
      name: "$ Lite",
      number: 12,
      color: ["#E6D009", "#E9B300"],
    },
    {
      name: "$ Essential",
      number: 13,
      color: ["#FF9C07", "#FC7B38"],
    },
    {
      name: "$ Standard",
      number: 23,
      color: ["#44B1E2", "#0860E4"],
    },
    {
      name: "$ Professional",
      number: "10",
      color: ["#07D459", "#049E7F"],
    },
  ]);
  const options = {
    scales: {
      y: {
        suggestedMin: 0,
        suggestedMax: 800,

        grid: {
          display: false,
        },
      },
    },
    responsive: true,

    plugins: {
      legend: {
        position: "bottom",
      },

      // title: {
      //   display: true,
      //   text: "Chart.js Line Chart",
      // },
    },
  };

  const labels = [
    "Jan",
    "Feb",
    "Mar",
    "Apr",
    "May",
    "Jun",
    "Jul",
    "Aug",
    "Sep",
    "Oct",
    "Nov",
    "Dec",
  ];

  const data = {
    labels,
    datasets: [
      {
        label: "unpaid",
        data: [400, 400, 400, 400],
        backgroundColor: "#FF8800",

        barThickness: 6,
      },
      {
        label: "Paid",
        data: [400, 400, 400, 400],
        backgroundColor: "#024FD4",

        barThickness: 10,
      },
    ],
  };

  return (
    <Container>
      <Header>
        <PaymentTxt>Payments</PaymentTxt>
        <EditionTxt>Edition Wise Payment</EditionTxt>
      </Header>
      <TopContainer>
        <BarChartContainer>
          <Bar options={options} data={data} />
        </BarChartContainer>
        <TopRight>
          <CardContainer>
            {card.map((i) => {
              return (
                <Card sx={{ maxWidth: 345 }} color={i.color}>
                  <CardActionArea>
                    <CardMedia />
                    <CardContent>
                      <Typography
                        variant="body2"
                        color="dark"
                        style={{
                          fontSize: "18px",
                          fontWeight: "bold",
                          paddingLeft: "10px",
                        }}
                      >
                        {i.name}
                      </Typography>
                      <Typography
                        variant="body2"
                        color="dark"
                        style={{
                          fontSize: "18px",

                          paddingLeft: "10px",
                        }}
                      >
                        34&nbsp;users
                      </Typography>
                      <DollarContainer>
                        <Typography
                          variant="h5"
                          component="div"
                          textAlign="right"
                          style={{
                            fontWeight: "bold",
                            fontSize: "41px",
                            color: "#E1E1E1",
                          }}
                        >
                          $
                        </Typography>
                        <Typography
                          variant="h5"
                          component="div"
                          textAlign="right"
                          style={{
                            fontSize: "19px",
                            textAlign: "center",
                          }}
                        >
                          INR&nbsp;123334.00
                        </Typography>
                      </DollarContainer>
                    </CardContent>
                  </CardActionArea>
                </Card>
              );
            })}
          </CardContainer>
        </TopRight>
      </TopContainer>
    </Container>
  );
};

const DollarContainer = styled.div`
  display: flex;
  justify-content: unset;
  padding-left: 10px;
  align-items: center;
  width: 100%;
  gap: 10px;
`;
const TopRight = styled.div`
  width: 50%;
  padding-left: 30px; ;
`;
const BarChartContainer = styled.div`
  width: 50%;
`;

const TopContainer = styled.div`
  display: flex;
`;
const Card = styled.div`
  border: 1px solid #c9c9c9;
  .css-46bh2p-MuiCardContent-root {
    padding: unset;
  }
  button {
    border-left: 8px solid transparent;
    border-image: ${({ color }) =>
      color ? ` linear-gradient(180deg,${color})1` : ""};

    /* border-left: 5px solid;
    border-image: linear-gradient(180deg, #e6d009, #e9b300) 1; */
  }
  padding: 5px;
`;
const CardContainer = styled.div`
  margin-top: 10px;
  display: grid;
  grid-template-columns: auto auto;
  grid-row-gap: 10px;
  grid-column-gap: 10px;
`;
const PaymentTxt = styled.h4`
  font-size: 18px;
  font-family: "Roboto", "Helvetica", "Arial", sans-serif;
  margin-bottom: 10px;
  width: 50%; ;
`;
const EditionTxt = styled(PaymentTxt)`
  margin-right: auto;
  padding-left: 30px;
`;

const Container = styled.div`
  @media (min-width: 1920px) {
    padding-top: 98px;
  }
`;

const Header = styled.div`
  display: flex;
  justify-content: space-between;
`;
