import * as React from "react";
import TextField from "@mui/material/TextField";
import { LocalizationProvider } from "@mui/x-date-pickers-pro";
import { DateRangePicker } from "@mui/x-date-pickers-pro/DateRangePicker";
import { AdapterDateFns } from "@mui/x-date-pickers-pro/AdapterDateFns";
import Box from "@mui/material/Box";
import styled from "styled-components/macro";
import CalendarTodayIcon from "@mui/icons-material/CalendarToday";
export default function DateRangePickes() {
  const [value, setValue] = React.useState([null, null]);

  return (
    <DateContainer>
      <LocalizationProvider dateAdapter={AdapterDateFns}>
        <Date
          value={value}
          onChange={(newValue) => {
            setValue(newValue);
          }}
          renderInput={(startProps, endProps) => (
            <React.Fragment>
              <BoxContainer>
                <TextField {...startProps} />

                <TextField {...endProps} />
              </BoxContainer>
            </React.Fragment>
          )}
        />
      </LocalizationProvider>
      <CalenderIcon1 />
      <CalenderIcon2 />
    </DateContainer>
  );
}
const CalenderIcon1 = styled(CalendarTodayIcon)`
  position: absolute;
  top: 8px;
  color: black;
  font-size: 1rem !important;
  left: 6px;
  z-index: -1;
`;
const CalenderIcon2 = styled(CalendarTodayIcon)`
  position: absolute;
  top: 49px;
  font-size: 1rem !important;
  left: 6px;
  z-index: -1;
`;
const BoxContainer = styled.div`
  display: flex;

  gap: 10px;
  flex-direction: column;
`;
const DateContainer = styled.div`
  position: relative;

  .css-1u3bzj6-MuiFormControl-root-MuiTextField-root {
    border-color: #d4d4d4 !important;
    border-width: 1px !important;
    border-radius: 2px;
    outline: none;
  }
  .css-9ddj71-MuiInputBase-root-MuiOutlinedInput-root {
    border-color: #d4d4d4 !important;
    border-width: 1px !important;

    border-radius: 2px;
    border: none;
  }
  .css-14s5rfu-MuiFormLabel-root-MuiInputLabel-root {
    font-size: 13px;
    top: -8px !important;
    left: 20px;
  }
  .css-1sumxir-MuiFormLabel-root-MuiInputLabel-root.Mui-focused {
    color: black;
  }
  .css-9ddj71-MuiInputBase-root-MuiOutlinedInput-root:hover
    .MuiOutlinedInput-notchedOutline {
    border-color: #d4d4d4;
  }
  .jIbeoK .css-1d3z3hw-MuiOutlinedInput-notchedOutline {
    border-color: #d4d4d4 !important;
    border-width: 1px !important;
    border-radius: 2px;
  }
  .css-9ddj71-MuiInputBase-root-MuiOutlinedInput-root.Mui-focused
    .MuiOutlinedInput-notchedOutline {
    border-color: #d4d4d4 !important;
    border-width: 1px !important;
    border-radius: 2px;
  }

  .css-1t8l2tu-MuiInputBase-input-MuiOutlinedInput-input {
    padding: 3.5px 18px 3.5px 38px !important;
  }

  .css-1tihz4g-MuiPaper-root {
    z-index: 100000000000000 !important;
    font-size: 1rem !important;
  }
  .css-i6bazn {
    z-index: 300000000 !important;
  }
  .gDUrVR {
    top: 48px !important;
  }
`;

const Date = styled(DateRangePicker)`
  .css-1tape97:not(:last-of-type) {
    z-index: 1000000000000000000000000000000;
    background: white;
  }
  .css-193bp28 {
    z-index: 1000000000000000000000000000000;
    background: white;
  }
`;
