import React from "react";
import styled from "styled-components/macro";
import NotificationsNoneIcon from "@mui/icons-material/NotificationsNone";
import { Avatar, Badge, IconButton, Menu, MenuItem } from "@mui/material";
import MoreVertIcon from "@mui/icons-material/MoreVert";
import { useNavigate } from "react-router-dom";
import { BellOutlined } from "@ant-design/icons";

function Header() {
  let navigate = useNavigate();
  ///Notification bell icon -- MUI
  function notificationsLabel(count) {
    if (count === 0) {
      return "no notifications";
    }
    if (count > 99) {
      return "more than 99 notifications";
    }
    return `${count} notifications`;
  }

  //Three dot menu icon --MUI
  const ITEM_HEIGHT = 48;
  const options = [
    {
      title: "Countries",
      urlLink: "/countries",
    },
    {
      title: "States",
      urlLink: "/states",
    },
    {
      title: "Users",
      urlLink: "/users",
    },

    {
      title: "UQC",
      urlLink: "/uqc",
    },
    {
      title: "BussinessTypes",
      urlLink: "/bussinesstypes",
    },

    {
      title: "Enquiry Questions",
      urlLink: "/enquiryquestions",
    },
    {
      title: "Activity Log",
      urlLink: "/activitylog",
    },
  ];

  const [anchorEl, setAnchorEl] = React.useState(null);
  const open = Boolean(anchorEl);
  const handleClick = (event) => {
    setAnchorEl(event.currentTarget);
  };
  const handleClose = (link) => {
    navigate(link);
    setAnchorEl(null);
  };

  return (
    <Container>
      <RightContainer>
        <Notification>
          <IconButton aria-label={notificationsLabel(100)} xs={4}>
            <Badge badgeContent={100} color="secondary">
              {/* <NotificationsNoneIcon /> */}
              <BellOutlined />
            </Badge>
          </IconButton>
        </Notification>

        <AdminContainer>
          <AdminTxt>Admin</AdminTxt>
          <Avatar
            alt="Remy Sharp"
            src="https://i.pinimg.com/originals/02/6c/da/026cdaf717ac7af4482aec84436709ab.jpg"
          />
        </AdminContainer>

        <MenuIconContainer>
          <IconButton
            aria-label="more"
            id="long-button"
            aria-controls={open ? "long-menu" : undefined}
            aria-expanded={open ? "true" : undefined}
            aria-haspopup="true"
            onClick={handleClick}
          >
            <MoreVertIcon />
          </IconButton>
          <MenuContainer
            disableScrollLock={true}
            id="long-menu"
            MenuListProps={{
              "aria-labelledby": "long-button",
            }}
            anchorEl={anchorEl}
            open={open}
            onClose={handleClose}
            PaperProps={{
              style: {
                maxHeight: ITEM_HEIGHT * 5.5,
                width: "20ch",
              },
            }}
          >
            {/* <DropMenuSelectList
              onClick={() => history.push("/dashboard/general-settings")}
            >
              {"General Settings"}
            </DropMenuSelectList> */}
            {options.map((option) => (
              <MenuItems
                key={option}
                selected={option === "Countries"}
                onClick={() => handleClose(option.urlLink)}
              >
                {option.title}
              </MenuItems>
            ))}
          </MenuContainer>
        </MenuIconContainer>
      </RightContainer>
    </Container>
  );
}

export default Header;

const MenuItems = styled(MenuItem)`
  font-size: 13px !important;
`;
const MenuContainer = styled(Menu)`
  .css-kk1bwy-MuiButtonBase-root-MuiMenuItem-root {
    font-family: "Poppins", sans-serif;
  }
  .css-1poimk-MuiPaper-root-MuiMenu-paper-MuiPaper-root-MuiPopover-paper {
    max-height: 194px !important;
    ::-webkit-scrollbar {
      display: none;
    }
  }
`;
const DropMenuSelectList = styled.div`
  margin: 5px;
  padding: 8px 35px 8px 8px;
  border-radius: 5px;
  &:hover {
    cursor: pointer;
    background: #e5e5e5;
  }
`;

const Notification = styled.div`
  display: flex;
  justify-content: center;
  align-items: center;

  .css-jcn4dz-MuiBadge-badge {
    background-color: #e20000 !important ;
  }
  svg {
    color: black;
  }
`;
const MenuIconContainer = styled.div`
  svg {
    font-size: 2rem !important ;
    color: black !important;
  }
`;
const AdminTxt = styled.span`
  font-size: 15px;
  font-weight: 600;
`;
const RightContainer = styled.div`
  display: flex;
  justify-content: space-around;
  min-width: 225px;
`;
const Container = styled.div`
  height: 60px;
  background-color: white;
  display: flex;
  align-items: center;
  border: 1px solid #dfdfdf;
  position: fixed;
  top: 0;
  z-index: 9;
  padding-right: 10px;
  width: 100%;

  justify-content: flex-end;
`;

const AdminContainer = styled.div`
  display: flex;
  gap: 10px;
  align-items: center;
`;
