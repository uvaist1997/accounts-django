import React from "react";
import styled from "styled-components/macro";
// import { useTranslation } from "react-i18next";

const CreateButton = ({ label }) => {
  //   const [t, i18n] = useTranslation("common");
  return (
    <Container>
      <CreateButtonContainer>
        <PlusIconPositionContainer>
          <PlusIconContainer>+</PlusIconContainer>
        </PlusIconPositionContainer>
        <CreateLabel>{label}</CreateLabel>
      </CreateButtonContainer>
    </Container>
  );
};

export default CreateButton;

const Container = styled.div``;

const CreateLabel = styled.div`
  color: #000;
  margin-left: 45px;
  position: absolute;
  top: 0;
  bottom: 0;
  left: 0;
  right: 0;
  z-index: 2;
  display: flex;
  align-items: center;
  transition: all ease-in-out 0.3s;
  font-weight: normal;
  font-size: 12px;
`;
const PlusIconPositionContainer = styled.div`
  width: 30px;
  height: 30px;
  margin-right: 25px;
  background: #0761b1;
  border-radius: 30px;
  padding: 5px;
  font-weight: 600 !important;
  position: absolute;
  transition: width ease-in-out 0.3s;
`;
const CreateButtonContainer = styled.div`
  cursor: pointer;
  background: #e2e2e2;
  border-radius: 20px;
  padding: 20px 5px;
  width: 145px;
  display: flex;
  align-items: center;
  position: relative;

  &:hover {
    ${CreateLabel} {
      color: #fff;
      transition: all ease-in-out 0.3s;
    }
    ${PlusIconPositionContainer} {
      width: 135px;
      transition: width ease-in-out 0.3s;
    }
  }
`;

const PlusIconContainer = styled.div`
  width: 30px;
  height: 30px;
  margin-right: 25px;
  border-radius: 30px;
  padding: 7px;
  position: absolute;
  top: -4px;
  left: 0;
  right: 0;
  bottom: 0;

  font-size: 23px;
  color: #fff;
  font-weight: lighter;
  line-height: 26px;
`;
