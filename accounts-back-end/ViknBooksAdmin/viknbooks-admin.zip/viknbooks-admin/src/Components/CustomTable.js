import React, { useState } from "react";
import styled from "styled-components/macro";
import AccessTimeFilledIcon from "@mui/icons-material/AccessTimeFilled";
import { Checkbox, IconButton, Menu, MenuItem } from "@mui/material";
import LocalPhoneIcon from "@mui/icons-material/LocalPhone";
import Pagination from "@mui/material/Pagination";
import MoreVertIcon from "@mui/icons-material/MoreVert";

function CustomTable() {
  const label = { inputProps: { "aria-label": "Checkbox demo" } };
  const [rotate, setRotate] = useState(false);
  const [td, setTd] = useState([1, 2, 3, 4, 5, 6, 7, 8, 9, 8, 7]);
  const options = ["Edit", "Delete"];
  const [anchorEl, setAnchorEl] = useState(null);
  const open = Boolean(anchorEl);
  const [currentIndex, setCurrentIndex] = useState();
  const handleClick = (index) => (event) => {
    setAnchorEl(event.currentTarget);
    setCurrentIndex(index);
  };
  const handleClose = () => {
    setAnchorEl(null);
  };

  const ITEM_HEIGHT = 48;
  const [leadList, setLeadList] = useState({
    selecte_ids: [],
    is_checked_all: false,
    data: [
      {
        id: "1",
        check: false,
        title: "1",
        organization: "fffffff",
        phone: "10010",
        email: "abcd",
        source: "symbol",
        createddate: "12-21-2022",
        value: "0.005",
      },
      {
        id: "2",
        title: "2",
        organization: "fffffff",
        check: false,
        phone: "10010",
        email: "abcd",
        source: "symbol",
        createddate: "12-21-2022",
        value: "0.005",
      },
      {
        id: "3",
        title: "3",
        organization: "fffffff",
        check: false,
        phone: "10010",
        email: "abcd",
        source: "symbol",
        createddate: "12-21-2022",
        value: "0.005",
      },
      {
        id: "4",
        title: "4",
        organization: "fffffff",
        check: false,
        phone: "10010",
        email: "abcd",
        source: "symbol",
        createddate: "12-21-2022",
        value: "0.005",
      },
      {
        id: "5",
        title: "5",
        organization: "fffffff",
        check: false,
        phone: "10010",
        email: "abcd",
        source: "symbol",
        createddate: "12-21-2022",
        value: "0.005",
      },
      {
        id: "6",
        title: "6",
        organization: "fffffff",
        check: false,
        phone: "10010",
        email: "abcd",
        source: "symbol",
        createddate: "12-21-2022",
        value: "0.005",
      },
      {
        id: "7",
        title: "7",
        organization: "fffffff",
        check: false,
        phone: "10010",
        email: "abcd",
        source: "symbol",
        createddate: "12-21-2022",
        value: "0.005",
      },
      {
        id: "8",
        title: "8",
        organization: "fffffff",
        check: false,
        phone: "10010",
        email: "abcd",
        source: "symbol",
        createddate: "12-21-2022",
        value: "0.005",
      },
      {
        id: "9",
        title: "9",
        organization: "fffffff",
        check: false,
        phone: "10010",
        email: "abcd",
        source: "symbol",
        createddate: "12-21-2022",
        value: "0.005",
      },
      {
        id: "10",
        title: "10",
        organization: "fffffff",
        check: false,
        phone: "10010",
        email: "abcd",
        source: "symbol",
        createddate: "12-21-2022",
        value: "0.005",
      },
      {
        id: "11",
        title: "11",
        organization: "fffffff",
        check: false,
        phone: "10010",
        email: "abcd",
        source: "symbol",
        createddate: "12-21-2022",
        value: "0.005",
      },
      {
        id: "12",
        title: "12",
        organization: "fffffff",
        check: false,
        phone: "10010",
        email: "abcd",
        source: "symbol",
        createddate: "12-21-2022",
        value: "0.005",
      },
      {
        id: "13",
        title: "13",
        organization: "fffffff",
        check: false,
        phone: "10010",
        email: "abcd",
        source: "symbol",
        createddate: "12-21-2022",
        value: "0.005",
      },
      {
        id: "14",
        title: "14",
        organization: "fffffff",
        check: false,
        phone: "10010",
        email: "abcd",
        source: "symbol",
        createddate: "12-21-2022",
        value: "0.005",
      },
      {
        id: "15",
        title: "15",
        organization: "fffffff",
        check: false,
        phone: "10010",
        email: "abcd",
        source: "symbol",
        createddate: "12-21-2022",
        value: "0.005",
      },
      {
        id: "16",
        title: "16",
        organization: "fffffff",
        check: false,
        phone: "10010",
        email: "abcd",
        source: "symbol",
        createddate: "12-21-2022",
        value: "0.005",
      },
      {
        id: "17",
        title: "17",
        organization: "fffffff",
        check: false,
        phone: "10010",
        email: "abcd",
        source: "symbol",
        createddate: "12-21-2022",
        value: "0.005",
      },
      {
        id: "17",
        title: "18",
        organization: "fffffff",
        check: false,
        phone: "10010",
        email: "abcd",
        source: "symbol",
        createddate: "12-21-2022",
        value: "0.005",
      },
      {
        id: "18",
        title: "19",
        organization: "fffffff",
        check: false,
        phone: "10010",
        email: "abcd",
        source: "symbol",
        createddate: "12-21-2022",
        value: "0.005",
      },
      {
        id: "18",
        title: "20",
        organization: "fffffff",
        check: false,
        phone: "10010",
        email: "abcd",
        source: "symbol",
        createddate: "12-21-2022",
        value: "0.005",
      },
      {
        id: "19",
        title: "21",
        organization: "fffffff",
        check: false,
        phone: "10010",
        email: "abcd",
        source: "symbol",
        createddate: "12-21-2022",
        value: "0.005",
      },
      {
        id: "20",
        title: "22",
        organization: "fffffff",
        check: false,
        phone: "10010",
        email: "abcd",
        source: "symbol",
        createddate: "12-21-2022",
        value: "0.005",
      },
      {
        id: "21",
        title: "23",
        organization: "fffffff",
        check: false,
        phone: "10010",
        email: "abcd",
        source: "symbol",
        createddate: "12-21-2022",
        value: "0.005",
      },
      {
        id: "22",
        title: "24",
        organization: "fffffff",
        check: false,
        phone: "10010",
        email: "abcd",
        source: "symbol",
        createddate: "12-21-2022",
        value: "0.005",
      },
      {
        id: "22",
        title: "25",
        organization: "fffffff",
        check: false,
        phone: "10010",
        email: "abcd",
        source: "symbol",
        createddate: "12-21-2022",
        value: "0.005",
      },
      {
        id: "22",
        title: "26",
        organization: "fffffff",
        check: false,
        phone: "10010",
        email: "abcd",
        source: "symbol",
        createddate: "12-21-2022",
        value: "0.005",
      },
      {
        id: "22",
        title: "27",
        organization: "fffffff",
        check: false,
        phone: "10010",
        email: "abcd",
        source: "symbol",
        createddate: "12-21-2022",
        value: "0.005",
      },
      {
        id: "22",
        title: "28",
        organization: "fffffff",
        check: false,
        phone: "10010",
        email: "abcd",
        source: "symbol",
        createddate: "12-21-2022",
        value: "0.005",
      },
      {
        id: "22",
        title: "29",
        organization: "fffffff",
        check: false,
        phone: "10010",
        email: "abcd",
        source: "symbol",
        createddate: "12-21-2022",
        value: "0.005",
      },
      {
        id: "22",
        title: "30",
        organization: "fffffff",
        check: false,
        phone: "10010",
        email: "abcd",
        source: "symbol",
        createddate: "12-21-2022",
        value: "0.005",
      },
      {
        id: "22",
        title: "31",
        organization: "fffffff",
        check: false,
        phone: "10010",
        email: "abcd",
        source: "symbol",
        createddate: "12-21-2022",
        value: "0.005",
      },
      {
        id: "22",
        title: "32",
        organization: "fffffff",
        check: false,
        phone: "10010",
        email: "abcd",
        source: "symbol",
        createddate: "12-21-2022",
        value: "0.005",
      },
    ],
  });

  //pagination=======================================

  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage, setItemsPerPage] = useState(22);

  const IndexofLastItem = currentPage * itemsPerPage;
  const indexOfFirstDish = IndexofLastItem - itemsPerPage;
  let PaginatedData = leadList.data.slice(indexOfFirstDish, IndexofLastItem);
  console.log("page", PaginatedData);

  const ChangePage = (event, value) => {
    setCurrentPage(value);
  };

  const NumOfpages = Math.ceil(leadList.data.length / itemsPerPage);

  const handleSelectItem = (e) => {
    let id = e.target.id;
    let name = e.target.name;
    if (name == "items") {
      let selecte_ids = [...leadList.selecte_ids];
      if (e.target.checked == true) {
        selecte_ids.push(id);
      } else {
        var index = selecte_ids.indexOf(id);
        if (index !== -1) {
          selecte_ids.splice(index, 1);
        }
      }
      setLeadList({
        ...leadList,
        selecte_ids,
      });
    } else {
      let check = false;
      let selecte_ids = [];
      let data = leadList.data;
      if (e.target.checked == true) {
        check = true;
        data.map((i) => {
          selecte_ids.push(i.id);
        });
      }
      setLeadList({
        ...leadList,
        is_checked_all: check,
        selecte_ids,
      });
    }
  };

  return (
    <TableContainer>
      <Table>
        <THead>
          <TableHeadRow>
            <TH>
              <Squareheckbox1
                checked={leadList.is_checked_all}
                name="select_all"
                onChange={handleSelectItem}
                id="1"
                {...label}
              />
            </TH>
            <TH> Title </TH>
            <TH> Organization </TH>
            <TH> Phone</TH>
            <TH> Email </TH>
            <TH> Source </TH>
            <TH> Created Date </TH>
            <TH> Value </TH>

            <TH></TH>
          </TableHeadRow>
        </THead>
        <TBody>
          {PaginatedData.map((i, index) => (
            <TableBodyRow>
              <TD>
                <Squareheckbox1
                  name="items"
                  checked={leadList.selecte_ids.includes(i.id) ? true : false}
                  onChange={handleSelectItem}
                  id={i.id}
                  {...label}
                />
              </TD>

              <TD>{i.title}</TD>

              <TD>{i.organization}</TD>
              <TD>{i.phone}</TD>
              <TD>{i.email}</TD>
              <TD>{i.source}</TD>
              <TD>{i.createddate}</TD>
              <TD>{i.value}</TD>

              <TD style={{ textAlign: "right" }}>
                <RightSide>
                  <IconButton
                    aria-label="more"
                    id={index}
                    aria-controls={open ? "long-menu" : undefined}
                    aria-expanded={open ? "true" : undefined}
                    aria-haspopup="true"
                    onClick={handleClick(index)}
                  >
                    <MoreVertIcon />
                  </IconButton>

                  {currentIndex === index ? (
                    <Menus
                      // id="long-menu"
                      MenuListProps={
                        {
                          // "aria-labelledby": ` ${index}`,
                        }
                      }
                      disableScrollLock={true}
                      anchorEl={anchorEl}
                      open={open}
                      onClose={handleClose}
                      PaperProps={{
                        style: {
                          maxHeight: ITEM_HEIGHT * 4.5,
                          width: "20ch",
                        },
                      }}
                    >
                      {options.map((option) => (
                        <MenuItem
                          key={option}
                          selected={option === "Edit"}
                          onClick={handleClose}
                        >
                          {option}
                        </MenuItem>
                      ))}
                    </Menus>
                  ) : null}
                </RightSide>
              </TD>
            </TableBodyRow>
          ))}
        </TBody>
      </Table>
      <PaginationContainer>
        <Pagination count={NumOfpages} onChange={ChangePage} />
      </PaginationContainer>
    </TableContainer>
  );
}

export default CustomTable;
const PaginationContainer = styled.div`
  width: 100%;
  display: flex;
  margin-top: 10px;
  justify-content: center;
`;
const Squareheckbox1 = styled(Checkbox)`
  && {
    padding: unset !important ;
    color: unset !important;
    svg {
      font-size: 1.1rem !important;
    }
  }
`;
const Menus = styled(Menu)`
  && {
    .css-1poimk-MuiPaper-root-MuiMenu-paper-MuiPaper-root-MuiPopover-paper {
      width: 17ch !important;
      left: 1212px !important;
      @media (width: 1309.09px) {
        left: 1083px !important;
      }
      @media (width: 1920px) {
        left: 1687px !important;
      }
      @media (width: 1600px) {
        left: 1371px !important;
      }
      @media (width: 1800px) {
        left: 98rem !important;
      }
      ::-webkit-scrollbar {
        display: none !important;
      }
    }
  }
`;
const RightSide = styled.div`
  height: 100%;
  svg {
    font-size: 1.1rem !important ;
    color: black !important;
  }
  .css-78trlr-MuiButtonBase-root-MuiIconButton-root {
    padding: unset !important;
  }
  .MuiPaper-root {
    box-shadow: none !important;
  }
`;

const TableContainer = styled.div`
  margin-top: 15px;
`;
const TD = styled.td`
  font-size: 12px;
  padding: 5px 15px !important;
  text-align: left;

  border-bottom: 1px solid #ababab;
  vertical-align: middle;

  &.cursor {
    cursor: pointer;
  }
`;
const TableBodyRow = styled.tr`
  :hover {
    background-color: rgba(0, 0, 0, 0.04);
  }
`;
const Table = styled.table`
  border-radius: 15px;
  width: 100%;
  background: #fff;
  border-spacing: unset;
`;

const THead = styled.thead`
  box-shadow: 0 0 0 1px #c6c6c6;
  border-radius: 3px;
  background-color: black;
  color: white;
`;
const TableHeadRow = styled.tr``;
const TBody = styled.tbody``;
const TH = styled.th`
  padding: 5px 15px;
  font-weight: normal;
  text-align: left;
  font-size: 14px;
`;
