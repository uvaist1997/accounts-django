import React from "react";
import styled from "styled-components/macro";
// import { useTranslation } from "react-i18next";
import DoneIcon from "@mui/icons-material/Done";
const SaveButton = () => {
  //   const [t, i18n] = useTranslation("common");
  return (
    <Container>
      <CreateButtonContainer>
        <PlusIconPositionContainer>
          <PlusIconContainer>
            <DoneIcon />
          </PlusIconContainer>
        </PlusIconPositionContainer>
        <SaveLabel>Save</SaveLabel>
      </CreateButtonContainer>
    </Container>
  );
};

export default SaveButton;

const Container = styled.div``;

const SaveLabel = styled.div`
  color: #000;
  font-weight: bold;
  margin-left: 45px;
  position: absolute;
  top: 0;
  bottom: 0;
  left: 0;
  right: 0;
  z-index: 2;
  display: flex;
  align-items: center;
  transition: all ease-in-out 0.3s;
  font-weight: normal;
  font-size: 12px;
`;
const PlusIconPositionContainer = styled.div`
  svg {
    width: 22px;
    height: 25px;
    font-size: 1.3rem !important ;
  }
  width: 30px;
  height: 30px;
  margin-right: 25px;
  background: #03b232;
  border-radius: 30px;
  padding: 5px;
  font-weight: 600 !important;
  position: absolute;
  transition: width ease-in-out 0.3s;
`;
const CreateButtonContainer = styled.div`
  cursor: pointer;
  background: #e2e2e2;
  border-radius: 20px;
  padding: 20px 5px;
  width: 118px;
  display: flex;
  align-items: center;
  position: relative;

  &:hover {
    ${SaveLabel} {
      color: #fff;
      transition: all ease-in-out 0.3s;
    }
    ${PlusIconPositionContainer} {
      width: 107px;
      transition: width ease-in-out 0.3s;
    }
  }
`;

const PlusIconContainer = styled.div`
  width: 30px;
  height: 30px;
  margin-right: 25px;
  border-radius: 30px;
  padding: 7px;
  position: absolute;
  top: -4px;
  left: -3px;
  right: 0;
  bottom: 0;

  font-size: 23px;
  color: #fff;
  font-weight: lighter;
  line-height: 26px;
`;
