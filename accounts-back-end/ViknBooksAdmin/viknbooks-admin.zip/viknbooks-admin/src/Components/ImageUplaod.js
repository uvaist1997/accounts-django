import AddIcon from "@mui/icons-material/Add";
import React, { useState } from "react";
import styled from "styled-components/macro";
export default function ImageUpload() {
  const [image, setImage] = useState({ preview: "", raw: "" });

  const handleChange = (e) => {
    if (e.target.files.length) {
      setImage({
        preview: URL.createObjectURL(e.target.files[0]),
        raw: e.target.files[0],
      });
    }
  };

  const handleUpload = async (e) => {
    e.preventDefault();
    const formData = new FormData();
    formData.append("image", image.raw);

    await fetch("YOUR_URL", {
      method: "POST",
      headers: {
        "Content-Type": "multipart/form-data",
      },
      body: formData,
    });
  };

  return (
    <ImgContainer>
      <Label htmlFor="upload-button">
        {image.preview ? (
          <IMG src={image.preview} alt="dummy" />
        ) : (
          <ImgContainer>
            <AddIcons />
          </ImgContainer>
        )}
      </Label>
      <input
        type="file"
        id="upload-button"
        style={{ display: "none" }}
        onChange={handleChange}
      />
      <br />
      {/* <button onClick={handleUpload}>Upload</button> */}
    </ImgContainer>
  );
}

const ImgContainer = styled.div`
  /* border: 1px dotted blue; */
  margin-top: 5px;
  height: 95px;
  width: 99px;
  display: flex;
  background-color: #e9e9e9;
  cursor: pointer;
  align-items: center;
  justify-content: center;
`;
const IMG = styled.img`
  width: 80px;
  height: 80px;
`;
const AddIcons = styled(AddIcon)`
  color: grey;
`;

const Label = styled.label`
  display: flex;
  align-items: center;
  justify-content: center;
`;
