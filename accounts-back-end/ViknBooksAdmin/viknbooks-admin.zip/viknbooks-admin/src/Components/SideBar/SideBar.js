import { ButtonBase } from "@mui/material";
import React from "react";
import styled from "styled-components/macro";
import { Button } from "@mui/material";
import { useLocation } from "react-router-dom";
import { NavLink } from "react-router-dom";
function SideBar() {
  const image_root = window.location.origin;
  console.log("image", image_root);
  const MenuList = [
    {
      label: "Dashboard",
      image: image_root + "/Images/Icons/dashboard.svg",
      linkList: "/",
      //   linkCreate: "",
    },
    {
      label: "Organization",
      image: image_root + "/Images/Icons/connected-people.svg",
      linkList: "/organization",
      //   linkCreate: () => setProject(true),
    },
    {
      label: "Applications",
      image: image_root + "/Images/Icons/Icon-ionic.svg",
      linkList: "/application",
      //   linkCreate: () => setTask(true),
    },

    {
      label: "Enquiry",
      image: image_root + "/Images/Icons/customer-care.svg",
      linkList: "/enquiry",
    },
    {
      label: "Blog",
      image: image_root + "/Images/Icons/feather.svg",
      linkList: "/blog",
    },
    {
      label: "Service Log",
      image: image_root + "/Images/Icons/iconFeather.svg",
      linkList: "/service-log",
    },
    {
      label: "Partners",
      image: image_root + "/Images/Icons/shakeHand.svg",
      linkList: "/partners",
    },
    {
      label: "Leads",
      image: image_root + "/Images/Icons/myLocation.svg",
      linkList: "/leads",
    },
    {
      label: "Activities",
      image: image_root + "/Images/Icons/calendar-check-fill.svg",
      linkList: "/activities",
    },
    {
      label: "Deals",
      image: image_root + "/Images/Icons/dollar.svg",
      linkList: "/deals",
    },
    {
      label: "Invoices",
      image: image_root + "/Images/Icons/bx-receipt.svg",
      linkList: "/invoice",
    },
  ];

  const { pathname } = useLocation();

  const GotCreate = (link) => {
    // console.log(link);
    // navigate(`${link}`, { state: { create: true } });
  };

  return (
    <Container>
      <Logos__Container>
        <LogoContainer>
          <Logo src="../../Images/Logo/GroupIcon.svg" alt="" />
        </LogoContainer>
      </Logos__Container>
      <SideBarMenus>
        {MenuList.map((i, index) => (
          <Menu key={index}>
            <ButtonBase>
              <MenuIconContainer>
                <StyledNavLink
                  to={i.linkList}
                  className={
                    [i.linkList, i.linkCreate].includes(pathname)
                      ? "active"
                      : ""
                  }
                >
                  <MenuIconImg src={i.image} alt="label" />
                  <MenuText>{i.label}</MenuText>
                </StyledNavLink>
              </MenuIconContainer>
            </ButtonBase>
          </Menu>
        ))}
      </SideBarMenus>
    </Container>
  );
}

export default SideBar;

const SideBarMenus = styled.div`
  display: flex;
  flex-direction: column;
`;
const CreateButton = styled(Button)`
  display: flex;
  margin-left: auto;
  padding: 0 10px;
  svg {
    transition: all 0.2s ease-in-out;
    color: #b8becb;
  }
  &&.active,
  &&:hover {
    svg {
      transition: all 0.2s ease-in-out;
      color: #000 !important;
    }
  }
`;
const MenuIconContainer = styled.div`
  background: #232323;

  /* padding: 7px; */
  margin: 0 auto;
  border-radius: 4px;
  text-align: left;
  display: flex;
  align-items: center;
  width: 150px;
  transition: all 0.1s ease-in-out;
  &&.active {
    background-color: white;
  }
`;

const MenuText = styled.p`
  white-space: nowrap;
  color: #f3f3f3;
  font-size: 13px;
  /* font-weight: bold; */

  margin-left: 10px;
  margin-bottom: unset !important;

  transition: all 0.1s ease-in-out;

  ${({ report }) =>
    report &&
    `
  margin-left:35px;

  `}/* @media (max-width: 460px) {
    margin-bottom: 0;
    display: none;
  } */
`;
const MenuIconImg = styled.img`
  width: 20px;
  height: 20px;
  transition: all 0.2s ease-in-out;
  &&.active {
    color: black;
  }

  && path {
    fill: #fff !important;
  }
`;

const StyledNavLink = styled(NavLink)`
  padding: 7px;
  width: 100%;
  display: flex;
  align-items: center;
  text-decoration: none;

  &&:hover,
  &&.active {
    ${MenuIconContainer} {
      background: #ffffff 0% 0% no-repeat padding-box;
      box-shadow: 0px 0px 3px 0px #0000004f;
      transition: all 0.2s ease-in-out;
      /* background-color: white; */
    }
    ${MenuIconImg} {
      transition: all 0.2s ease-in-out;
      filter: brightness(0);

      color: black;
    }
    ${MenuText} {
      transition: all 0.2s ease-in-out;
      color: #3b4a58;
    }
    ${CreateButton} {
      svg {
        transition: all 0.2s ease-in-out;
        color: #000 !important;
      }
      color: #000 !important;
    }
    background: #ffffff 0% 0% no-repeat padding-box;
    box-shadow: 0px 0px 3px 0px #0000004f;
    border-radius: 4px;
  }
`;

const Menu = styled.div`
  && {
    cursor: pointer;
    text-decoration: none;
    margin-bottom: 10px;
  }
  &&.active,
  &&:hover {
    ${MenuIconContainer} {
      background: #ffffff 0% 0% no-repeat padding-box;
      box-shadow: 0px 0px 3px 0px #0000004f;
      transition: all 0.2s ease-in-out;
    }
    ${MenuIconImg} {
      transition: all 0.2s ease-in-out;
      filter: brightness(0);
      /* filter: brightness(0) invert(1); */
    }
    ${MenuText} {
      transition: all 0.2s ease-in-out;
      color: #3b4a58;
    }
    ${CreateButton} {
      svg {
        transition: all 0.2s ease-in-out;
        color: #000 !important;
      }
    }
  }

  ${({ report, showMenu }) =>
    report &&
    !showMenu &&
    `

  `}
`;

const Logos__Container = styled.div`
  width: 100%;
  display: flex;
  justify-content: center;
  align-items: center;
`;

const Logo = styled.img`
  width: 100%;
  height: 100%;
  box-sizing: border-box;
  object-fit: contain;
`;
const LogoContainer = styled.div`
  display: flex;
  justify-content: center;
  width: 80px;
  height: 80px;
`;
const Container = styled.div`
  padding: 15px 10px 0px 10px;
  position: fixed;
  left: 0;
  top: 0;
  z-index: 10;
  border-radius: 0px 15px 15px 0px;
  width: 184px;
  height: 100vh;
  background-color: #101010;
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 15px;
`;
