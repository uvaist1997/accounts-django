import { TextField } from "@material-ui/core";
// import { Autocomplete } from "@material-ui/lab";
import React, { useState } from "react";
import styled from "styled-components/macro";

const RoundCheckbox = (props) => {
  //   const [state, setState] = useState(false);
  return (
    <Container class="container">
      <Round class="round">
        <Input
          type="checkbox"
          id={props.name}
          name={props.name}
          checked={props.value}
          onChange={props.onChange}
          disabled={props.disabled ? true : false}
        />
        <CustomTick for={props.name}></CustomTick>
      </Round>
    </Container>
  );
};

export default RoundCheckbox;

const Container = styled.div`
  /* label {
    border: 1px solid;
  } */
`;
const Round = styled.div`
  position: relative;
  display: flex;
`;
const Input = styled.input`
  width: 18px;
  height: 12px;
  visibility: hidden;

  &:checked + label {
    background-color: white;
  }
  &:checked + label:after {
    opacity: 1;
    left: 2px;

    top: 4px;
    animation: checkbox-check 250ms cubic-bezier(0.4, 0, 0.23, 1) forwards;
  }

  @keyframes checkbox-check {
    0% {
      height: 0px;
      border: none;
    }

    50% {
      height: 6px;
    }
    100% {
      height: 6px;
      width: 12px;
    }
  }
`;
const CustomTick = styled.label`
  background-color: #fff;

  border: 1px solid black;

  border-radius: 50%;
  cursor: pointer;
  left: 0;
  position: absolute;
  top: 0;
  width: 15px;
  height: 15px;

  &:after {
    border: 1.9px solid black;
    border-top: none;
    border-right: none;
    content: "";
    opacity: 0;
    width: 5px !important;
    height: 2px !important;
    position: absolute;
    visibility: visible;
    left: 3px !important;
    top: 4px !important;
    border-top: none;
    border-right: none;

    transform: rotate(-45deg);
  }
`;
const Label = styled.label`
  cursor: pointer;
  display: flex;
  align-items: center;
  margin-left: 5px;
  font-weight: bold;

  text-transform: capitalize;
`;
const StyledInput = styled(TextField)`
  .MuiAutocomplete-inputRoot[class*="MuiOutlinedInput-root"][class*="MuiOutlinedInput-marginDense"] {
    padding: 3px;
  }
  input {
    margin-left: 5px;
    color: #000;
    padding: 0;
    font-size: 14px;
  }
  /* Change the white to any color */
  input:-webkit-autofill,
  input:-webkit-autofill:hover,
  input:-webkit-autofill:focus,
  input:-webkit-autofill:active {
    box-shadow: 0 0 0 30px white inset !important;
  }
  /*Change text in autofill textbox*/
  /* input:-webkit-autofill {
    -webkit-text-fill-color: yellow !important;
  } */

  input[type="number"]::-webkit-inner-spin-button,
  input[type="number"]::-webkit-outer-spin-button {
    -webkit-appearance: none;
    margin: 0;
  }
  & textarea {
    min-height: 120px;
    max-height: 120px;
    color: #fff;
    font-weight: bold;
  }
  & .MuiOutlinedInput-root {
    /* border-radius: 25px; */
    /* border: 2px solid #e4e4e4; */
  }
  fieldset {
    border: 0;
  }
  &::-webkit-input-placeholder {
    color: #000;
  }
  & .MuiInputBase-input::-webkit-input-placeholder {
    color: #404040bb;
    opacity: 1;
    font-size: 12px;
    text-transform: capitalize;
    font-family: "poppinsregular";
    height: 15px;
  }
  & .MuiOutlinedInput-inputMarginDense {
    font-family: "poppinsregular";
    padding-top: 5.5px;
    padding-bottom: 5.5px;
    padding-right: 0px;
  }
  & .MuiInput-underline:before {
    border: 0 !important;
  }
  & .MuiInput-underline:after {
    border: 0;
  }
`;
const AutoCompleteContainer = styled.div`
  width: 100%;
  .MuiAutocomplete-inputRoot.MuiAutocomplete-input {
    padding: 0;
  }
  .MuiAutocomplete-inputRoot[class*="MuiOutlinedInput-root"] {
    padding: 0px;
  }

  .MuiInputBase-marginDense.MuiOutlinedInput-marginDense,
  div input {
    padding: 0 !important;
  }
`;
