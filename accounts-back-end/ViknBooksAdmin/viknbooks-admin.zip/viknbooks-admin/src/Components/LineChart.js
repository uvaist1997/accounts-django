import React, { useState } from "react";
import { Line } from "react-chartjs-2";
import { Chart as chartjs } from "chart.js/auto";
import { borderColor, borderRadius, fontSize } from "@mui/system";
function LineChart() {
  const data = {
    labels: [
      "Jan",
      "Feb",
      "Mar",
      "Apr",
      "May",
      "Jun",
      "Jul",
      "Aug",
      "Sep",
      "Octr",
      "Nov",
      "Dec",
    ],
    datasets: [
      {
        label: "First dataset",
        data: [33, 53, 85, 41, 44, 65],
        fill: false,
        // backgroundColor: "rgba(75,192,192,0.2)",
        borderColor: "#00e676",
        borderWidth: 2,
        pointBorderWidth: 0,
        pointRadius: 1,
      },
      {
        label: "Second dataset",

        data: [33, 25, 35, 51, 54, 76],
        fill: false,
        borderColor: "#ff1744",
        borderWidth: 2,
        pointBorderWidth: 0,
        pointRadius: 1,
      },
    ],
  };
  const options = {
    responsive: true,
    plugins: {
      legend: {
        display: true,

        position: "bottom",
      },
    },
  };

  return (
    <div>
      <Line data={data} options={options} />
    </div>
  );
}

export default LineChart;
