import "./App.css";
import {
  BrowserRouter as Router,
  Routes as Switch,
  Route,
} from "react-router-dom";
import React, { lazy, Suspense } from "react";
import Loader from "./api/Loader";
// import Navigation from "./Pages/Routes/Navigation";

function App() {
  const Navigation = lazy(() => import("./Pages/Routes/Navigation"));
  return (
    <div className="App">
      <Suspense fallback={<Loader />}>
        <Router>
          <Switch>
            <Route path="/*" element={<Navigation />} />
          </Switch>
        </Router>
      </Suspense>
    </div>
  );
}

export default App;
